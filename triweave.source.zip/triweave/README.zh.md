# Triweave 0.1.0

一个基于 Fabric 的模组加载器,面向 Minecraft Java **26.3**。
它叠加在 Fabric Loader (>=0.19.3) 之上,翻译运行 Quilt 模组,并通过有限的兼容层运行 NeoForge
模组和 Bukkit 系插件(plugin.yml 格式)。

语言: [日本語](README.md) / [English](README.en.md) / 中文(本文件)

## 它做了什么

启动时(在 Fabric 本体启动之前)会扫描 `mods/`,并为每个 jar 决定运行方式。

| jar 内容 | 运行方式 |
|---|---|
| 含有 `fabric.mod.json`(即使同时含有 Quilt/NeoForge 元数据) | **直接按 Fabric 运行,不做改动**(最高优先级) |
| 只有 `quilt.mod.json`(即使同时含有 NeoForge 元数据) | **翻译为 Fabric 格式后运行**(次优先级) |
| 只有 `neoforge.mods.toml` | 交给兼容层判定:接受则运行,拒绝则显示原因(见下文) |
| 只有 `mods.toml`(旧版 Forge) | 报告为不支持 |

- 已内置 Fabric API(模组版,0.166.0+26.3)。若 `mods/` 中没有,启动时会自动放入。
- 不会修改原始 jar。翻译结果存放在 `.triweave/cache/`,按 SHA-1 复用(第二次启动后更快)。
- 如果没有 Quilt 模组,翻译流程完全不会运行。

## triweave.mod.json(Triweave 专属格式)

Triweave 专属的元数据格式。读取优先级为 **`triweave.mod.json` > `fabric.mod.json` >
`quilt.mod.json` > `neoforge.mods.toml`**(同时含有 `fabric.mod.json` 的 jar,仍会被 Fabric
直接按 Fabric 模组加载——这是 Fabric 本身的行为,无法改变——但 `triweave.mod.json` 中的名称、
版本等信息仍会优先用于展示)。Fabric、Quilt、NeoForge 的 jar 依旧可以照常运行。
格式说明见 `docs/triweave.mod.json.md`,示例见 `examples/triweave.mod.json`。

## Triweave API(与加载器无关)

跨加载器获取模组信息、启用/禁用、重载钩子、服务注册、简易配置文件等。详见 `docs/API.md`。
面向模组开发者发布了独立的 `triweave-api-0.1.0.jar`(含类文件与源码)。

## Quilt 翻译范围

- `quilt.mod.json` → `fabric.mod.json`(元数据、依赖、provides、mixin、entrypoints、
  内嵌 jar、运行环境)
- 依赖名称转换: `quilt_loader` → `fabricloader`,`quilted_fabric_api` → `fabric-api`
- QSL 的模块依赖(如 `quilt_base`)会被丢弃(并显示警告)
- 入口点通过语言适配器 `triweave-quilt` 调用,会把 QSL 形式的
  `onInitialize(ModContainer)` / `onInitializeClient` / `onInitializeServer` / `onPreLaunch`
  当作 Fabric 类型来调用
- 内置了 Quilt API 的最小化模拟实现(`QuiltLoader`、`ModContainer`、`ModMetadata`、`Version`)
- 不支持: `Class::method` 形式的入口点、QSL 本体的大型 API(使用 Quilt 专属大型 API 的模组)、
  多个 access widener(只采用第一个)

## Mod Menu 中显示 NeoForge 模组

- Mod Menu(21.0.0)与 Fabric API 一样被内置,`mods/` 中没有时会在启动时自动放入。
- NeoForge 专属模组会生成一个**Fabric 格式的展示用占位模组**(id 为 `nf_<modid>`,名称后缀
  `[NeoForge]`),以便显示在 Mod Menu 中。占位模组只包含 `fabric.mod.json` 和图标,
  **模组本身的功能不会运行**。由于使用了 `nf_` 前缀,它不会误满足真正 Fabric 模组的依赖,
  也不会与同名的 Fabric 版本冲突(如果已存在同名的 Fabric/Quilt 模组,则不会生成占位模组)。
- 如果多个 jar 声明了相同的模组 id,Fabric 会拒绝启动,因此 Triweave 会提前在日志中输出
  `DUPLICATE mod id` 提示。

## NeoForge 模组的处理方式

启动时,会对每个 NeoForge 专属 jar 进行机械式判定,检查“Triweave 的兼容层能否运行它”。

**接受(可以运行)**: 只使用兼容层已实现的 NeoForge API 的模组(主要是 MCreator 生成的、
添加方块/物品/创造模式物品栏/配方/生物群系/维度等的模组)。Triweave 会补上
`fabric.mod.json`,并将 Fabric 的 main 入口点指向该模组的 `@Mod` 类(由于 26.x 版本中
Fabric 和 NeoForge 都使用 Mojang 映射名,因此不需要做任何代码转换)。

**拒绝(不会运行,并显示原因)**:
- 使用了网络通信(存在使用 `CustomPacketPayload` 的实际消息类)
- 使用了 Kotlin(`modLoader="klf"` / 依赖 KotlinForForge / 含有 Kotlin 字节码)
- 使用了 NeoForge 专属的 Mixin 或 AccessTransformer
- 使用了兼容层未提供的 NeoForge API(会显示缺失的具体 API 名称)

被拒绝的模组只会生成 Mod Menu 占位展示(`nf_<modid>`),不会运行任何功能。
可以运行 `java -jar triweave-0.1.0.jar check <jar...>` 提前查看判定结果与原因。

兼容层提供的内容: `@Mod` 注解及构造函数参数(IEventBus、ModContainer、Dist)、
`@EventBusSubscriber` / `@SubscribeEvent`、`DeferredRegister`(Items、Blocks、通用)、
`RegisterEvent`、`BuildCreativeModeTabContentsEvent`(对接 Fabric API 的创造模式物品栏事件)、
`ServerTickEvent`、`FMLCommonSetupEvent`、服务器启动/停止事件、玩家登录/登出事件、
`ClientTickEvent`,以及**`BlockEvent.BreakEvent`(方块破坏,可取消)、`LivingDeathEvent`
(死亡,可取消)**等。模组监听的其他任何事件,都会在日志中提示“该事件不会被触发”,
以便模组作者知道对应的处理器不会运行。

已知限制: `DeferredHolder` 没有实现 `Holder` 接口 / `SidedThreadGroups.SERVER` 的判定
始终为 false(因此 `queueServerWork` 的延迟执行无法运行)/ 图形界面(菜单)尚未实现 /
除上述列出的事件外,其他游戏内事件(如玩家交互、方块破坏之外的事件)尚未接入。
**在真实环境中的运行情况尚未验证。**

## Modrinth App 等无法替换启动主类的启动器

只需在 JVM 参数中加入以下内容,每次启动都会自动完成准备工作:

```
-javaagent:C:\Triweave\triweave-0.1.0.jar
```

创建一个 Fabric 26.3 实例并加入上述参数。Fabric 启动前,会把翻译后的 jar 和 Triweave
本体以 `__triweave_` 前缀写入 `mods/`(删除某个模组后,下次启动会自动清理对应的生成文件)。
手动执行: `java -jar triweave-0.1.0.jar prepare --gameDir <实例文件夹>`

## 游戏内命令

| 命令 | 内容 |
|---|---|
| `/mod` | 显示 Fabric / Quilt / NeoForge 全部模组列表 |
| `/mod <类型> [list]` | 按类型显示列表: `triweave` / `fabric` / `quilt` / `neoforge` / `bukkit` |
| `/mod <模组名> [info]` | 显示模组信息(id、版本、加载器、状态、文件名) |
| `/mod <模组名> on` / `off` | 启用/禁用模组(**下次启动时生效**;服务器上需要 OP 权限;Bukkit 系插件不支持此操作) |
| `/mod <模组名> reload` | 执行该模组注册的重载处理 + 重新读取配置 + 重新加载资源 |
| `/mod triweave [reload]` | 显示 Triweave 信息(Discord 链接)/ 重载全部 |

- 模组名可以用 id、显示名称或部分匹配来指定(包含空格的名称请用 `"..."` 包裹)。
- 禁用操作是在启动前把 jar 重命名为 `*.jar.triweave-off` 实现的(与 Modrinth 的
  `.disabled` 约定不同)。被其他模组依赖的模组、`fabric-api`、以及 `triweave` 本身,
  都无法被禁用。
- **无法热重载代码**(JVM 的限制)。添加/删除模组、启用/禁用模组都需要重启才能生效。
- 列表会在启动时写入 `.triweave/modlist.tsv`。该命令在客户端和服务器上都存在。

## 启动模式(Java 参数)

- 默认: 把翻译后的 jar 以 `__triweave_` 前缀写入 `mods/`(已在真实环境中验证可用)。
- `-Dtriweave.mode=addmods`: 不向 `mods/` 写入任何文件,而是通过 `fabric.addMods`
  把 jar 交给 Fabric(**尚未验证**)。

## 支持 / 问题反馈

Discord: https://discord.gg/ZqDd74CC8B (也可以从 Mod Menu 的“网站”/“反馈问题”链接打开)

> 注意: `/mod` 命令和 NeoForge 兼容层都依赖 Minecraft 的类,因此按当前的 Gradle 配置
> 无法直接执行 `gradle build`(需要类似 Loom 这样的工具把 Minecraft 加入依赖,这一点在
> 26.3 上尚未配置/验证)。`tools/stubs-and-compile.sh` 会使用仅用于编译的桩代码来构建
> `main`(API 列表可通过 `tools/GenApiList.java` 重新生成)。发布的 `triweave-0.1.0.jar`
> 是按照 26.3 版 Fabric API 真实的方法签名编译的。

## 发布文件(客户端版与服务器版分离)

| 文件 | 内容 |
|---|---|
| `triweave.cliant.26.3.0.1.0.jar` | 客户端启动器。只含 `TriweaveClient` 及客户端版 `/mod` 命令,内置 Mod Menu |
| `triweave.server.26.3.0.1.0.jar` | 服务器启动器。只含 `TriweaveServer` 及服务器版 `/mod` 命令,不内置 Mod Menu |
| `triweave.api.26.3.0.1.0.jar` | `dev.triweave.api` 独立包(类文件+源码),供模组开发者使用 |
| `triweave.core.mod.fabric.26.3.0.1.0.jar` | 不经启动器包装的纯 Fabric 模组本体(同时含有客户端与服务器两侧的入口点)。用于直接作为模组添加到已有的 Fabric 实例中。但 Quilt 翻译、NeoForge 检测、以及 `/mod` 的列表(`modlist.tsv`)都是由启动前处理流程(启动器本体或 `-javaagent`)生成的,因此单独把这个 jar 放入 `mods/` 并不会获得这些功能 |
| `triweave.source.zip` | 完整源码(`README.md`、`docs/`、`examples/`) |

## 构建方法

需要 JDK 21 及以上版本,以及 Gradle 8.x(运行时需要 Java 25)。

```
gradle build
```

`build/libs/triweave-0.1.0.jar` 即为发布产物(内含模组本体 jar 与 Fabric API)。
如需替换内置的 Fabric API,请更新 `src/launcher/resources/triweave/fabric-api.jar`
以及 `bundled.properties`。

### 关于内置的 Fabric API / Mod Menu

本构建内置的是 **Fabric API 0.166.0+26.3** 与 **Mod Menu 21.0.0**。经查,Mod Menu
21.0.0 目前仍是 Minecraft 26.3 的最新稳定版,但 Fabric API 已有更新的稳定版
**0.166.2+26.3**(截至本 README 编写时)。由于本开发环境的网络访问被限制在一份
允许域名列表内,无法直接从 Modrinth 或 GitHub 下载发布文件,因此目前仍内置
0.166.0+26.3 版本。如需自行升级: 请从 Modrinth 的 Fabric API 版本页面下载
`fabric-api-0.166.2+26.3.jar`,替换 `src/launcher/resources/triweave/fabric-api.jar`,
并将 `bundled.properties` 中的 `fabric_api_version` 改为 `0.166.2+26.3`。

## 服务器版(Fabric / Quilt / NeoForge + Bukkit 系插件检测)

专用服务器使用与客户端相同的 `triweave-0.1.0.jar`。

### 部署步骤

1. 使用 Fabric 官方安装器创建服务器:
   `java -jar fabric-installer.jar server -mcversion 26.3 -downloadMinecraft`
   (会生成 `fabric-server-launch.jar`)
2. 在同一文件夹内执行: `java -jar triweave-0.1.0.jar install-server`
   (可选参数: `--dir <文件夹>` / `--launch <launch jar 的文件名>` / `--mem <例如 6G>`)
3. 使用生成的 `start.bat` / `start.sh` 启动(它们只是在运行 `fabric-server-launch.jar`
   时加上了 `-javaagent:triweave-x.y.z.jar` 参数)。

模组放入 `mods/`,Bukkit 系插件放入 `plugins/`。与原版 Fabric 一样,仍需同意
`eula.txt`。`/mod` 命令**只能在服务器控制台,或拥有 OP 权限的玩家**使用(启用/禁用
与重载操作需要相当于 `COMMANDS_GAMEMASTER` 的权限,即 OP 等级 2 以上;查看列表与
信息则任何人都可以)。服务器上不会生成 Mod Menu 占位模组,也不会自动安装 `modmenu`。

### Bukkit / Spigot / Paper 支持(仅支持 plugin.yml 格式;Paper 的新格式
`paper-plugin.yml` 以及 Folia 均不支持)

采用与 NeoForge 相同的“判定 → 翻译 → 运行”流程,**plugin.yml 格式的插件会被实际运行**,
但支持范围有意限制在以下这些(因为只重新实现了 Bukkit API 的一小部分):

- 插件生命周期(`onLoad` / `onEnable` / `onDisable`)、`getLogger()`
- 配置文件(`getConfig()` / 仅支持基础的 YAML 子集,不支持列表和多行字符串)
- 通过 `Bukkit.getPluginManager().registerEvents(...)` 注册并触发事件(`@EventHandler`)
- 命令(`getCommand(name).setExecutor(...)`)
- 同步/异步任务(`BukkitScheduler`;同步任务会随服务器 tick 执行)
- `ChatColor`

**不支持的内容**: 与真实玩家、世界、方块、物品栏的联动(`getOnlinePlayers()` 始终为空)、
权限系统(`PermissionDefault` 等)、持久化存储(`NamespacedKey` 等)、把真正实现打包进
内部 jar 的插件(jarinjar/shadow 打包方式,因为静态分析无法确认内部代码的安全性,
会被直接拒绝)、以及 Kotlin。实际上,这主要面向“只使用配置、日志、简单事件和命令的
自制小型插件”。

判定机制与 NeoForge 相同(静态扫描所使用的 API,并与兼容层已提供的 API 对比)。
可运行 `java -jar triweave-0.1.0.jar check <plugin.jar>` 提前检查。测试过的四个
真实插件(Chunky、LuckPerms、voicechat、WorldEdit)全部被拒绝——LuckPerms 是因为
真正实现打包在内部 jar 中,其余三个则是因为使用了大量未支持的 API。一个手写的
最小化测试插件(仅使用配置、日志、事件、命令、调度器)已在模拟的 Fabric 环境中完整
验证通过(接受判定、翻译、启动、tick、配置保存),但尚未在真实环境中验证。

## 安装方法(官方启动器)

1. 使用 Fabric 官方安装器为 Minecraft 26.3 安装 Fabric Loader。
2. 执行:
   ```
   java -jar triweave-0.1.0.jar install
   ```
   (可选参数: `--mc <.minecraft 路径>` / `--base <Fabric 版本 id>`)
3. 在启动器中选择新增的 **Triweave 26.3** 配置文件启动。
4. 模组照常放入 `mods/`(可以混用 Fabric/Quilt/NeoForge)。

以上步骤面向客户端。专用服务器请参见“服务器版”一节。

## 尚未验证的事项
- 服务器版(`install-server`、通过 `-javaagent` 自动准备、服务器端 `/mod` 权限判定)尚未
  在真实的专用服务器上运行验证。
- Bukkit/Spigot/Paper 支持已在模拟 Fabric 环境中,使用手写的最小化插件完成了端到端验证
  (接受判定、翻译、启动、事件、命令、调度器、配置),但尚未在真实服务器上验证。测试过的
  四个真实插件(Chunky、LuckPerms、voicechat、WorldEdit)均被判定为超出支持范围而拒绝。
- 新增的 NeoForge 事件(`BlockEvent.BreakEvent`、`LivingDeathEvent`)已对照 Fabric API
  26.3 实际 jar 中的方法签名进行过验证,但尚未在真实环境中验证。
- 新增的 Triweave API(`bus()`、`players()`、`broadcast()`、`onServerReady`)已在模拟的
  服务器环境中验证。不过 `players()` 所依赖的具体方法名(`getUUID`、`getGameProfile`、
  `isOp` 等)未能对照 26.3 真实 jar 验证——这些都是 Mojang 映射中长期保持不变的名称,
  大概率没有问题,但这一点仍未验证。
- 由于本环境无法获取真实的 Minecraft 或 Fabric Loader,**在真实环境中的整体运行情况
  尚未验证**。已验证的内容包括: 编译、jar 判定、Quilt 翻译(含内嵌 jar)、缓存复用、
  Fabric API 自动安装,以及语言适配器(针对桩代码版本的 Fabric API)。
- 依赖 `fabric.addMods` 机制将模组交给 Loader。
- 日志以 `[Triweave]` 开头,出现问题时请优先查看这些日志行。

## 许可证

Triweave: MIT 许可证。内置的 Fabric API: Apache-2.0
(https://github.com/FabricMC/fabric)。安装器还内置了 Gson(Apache-2.0)。
