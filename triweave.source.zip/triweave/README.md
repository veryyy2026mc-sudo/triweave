# Triweave 0.1.0

Fabric ベースのローダーです。Minecraft Java **26.3** 向け。
Fabric Loader (>=0.19.3) の上に重ねて、Quilt MOD を翻訳し、NeoForge MOD・Bukkit系プラグイン
(plugin.yml形式)を限定的な互換層で動かします。

言語: 日本語(このファイル) / [English](README.en.md) / [中文](README.zh.md)

## 何をするか

起動時(Fabric 起動の直前)に `mods/` を走査し、jar ごとに実行方法を決めます。

| jar の中身 | 実行方法 |
|---|---|
| `fabric.mod.json` あり(Quilt/NeoForge併記でも) | **Fabric としてそのまま実行**(最優先) |
| `quilt.mod.json` のみ(NeoForge併記でも) | **Fabric 形式に翻訳して実行**(次点) |
| `neoforge.mods.toml` のみ | 検出して **スキップ**し、ログに報告(下記参照) |
| `mods.toml`(旧Forge)のみ | 非対応として警告 |

- Fabric API(MOD版 0.166.0+26.3)は同梱。`mods/` に無ければ起動時に自動設置します。
- 元のjarは書き換えません。翻訳結果は `.triweave/cache/` に作り、SHA-1 が同じなら再利用します(2回目以降は軽い)。
- Quilt MODが無ければ翻訳処理は何も実行しません。

## triweave.mod.json(Triweave 独自形式)

Triweave 専用のメタデータ。**`triweave.mod.json` > `fabric.mod.json` > `quilt.mod.json` > `neoforge.mods.toml`**
の順で読み込みます(`fabric.mod.json` 併記の jar は Fabric が直接読むため、動作は Fabric 形式のままで、
triweave.mod.json は表示情報に使われます)。fabric / quilt / neoforge の jar はこれまでどおり実行できます。
書式: `docs/triweave.mod.json.md` / サンプル: `examples/triweave.mod.json`

## Triweave API(ローダー非依存)

MOD情報の横断取得・ON/OFF・再読み込みフック・サービス登録・簡易設定。詳細は `docs/API.md`。
開発者向けに `triweave-api-0.1.0.jar`(クラス+ソース)を配布しています。

## Quilt 翻訳の範囲

- `quilt.mod.json` → `fabric.mod.json`(メタデータ・依存・provides・mixin・entrypoints・JiJ・環境)
- 依存の読み替え: `quilt_loader` → `fabricloader`、`quilted_fabric_api` → `fabric-api`
- QSL のモジュール依存(`quilt_base` 等)は破棄(警告表示)
- エントリポイントは言語アダプタ `triweave-quilt` 経由。QSL 形式の
  `onInitialize(ModContainer)` / `onInitializeClient` / `onInitializeServer` / `onPreLaunch` を
  Fabric の型として呼び出します
- Quilt API の最小 shim(`QuiltLoader`、`ModContainer`、`ModMetadata`、`Version`)を同梱
- 未対応: `Class::method` 形式のエントリポイント、QSL 本体のAPI(Quilt専用の大型APIを使うMOD)、
  複数の access widener(最初の1つだけ採用)

## Mod Menu / NeoForge MOD の一覧表示

- Mod Menu(21.0.0)も Fabric API と同様に同梱。`mods/` に無ければ起動時に自動設置します。
- NeoForge 専用 MOD は、Mod Menu に出るよう **Fabric 形式の一覧用スタブ**(`nf_<modid>`、
  名前に `[NeoForge]` 付き)を生成します。スタブは `fabric.mod.json` とアイコンだけで、
  **MOD の機能は動きません**。`nf_` 接頭辞なので、Fabric MOD の依存関係を誤って満たすことも、
  同名の Fabric 版と衝突することもありません(同名の Fabric/Quilt MOD があるときはスタブ自体を作りません)。
- 同じ MOD id の jar が複数あると Fabric が起動を拒否するため、ログに `DUPLICATE mod id` を出します。

## NeoForge MOD の扱い

起動時に、NeoForge 専用 jar ごとに「Triweave の互換層で動かせるか」を機械的に判定します。

**受け入れ(動かす)**: 互換層が提供する NeoForge API だけを使っている MOD(主に MCreator 製の
ブロック / アイテム / クリエイティブタブ / レシピ / バイオーム / ディメンション等)。
`fabric.mod.json` を足して `@Mod` クラスを Fabric の main エントリポイントにします
(26.x は Fabric も NeoForge も Mojang 名なので、コードの変換はしません)。

**拒否(動かさない・理由を表示)**:
- ネットワーク通信(`CustomPacketPayload` を使う実際のメッセージクラスがある)
- Kotlin(`modLoader="klf"` / KotlinForForge 依存 / Kotlin コード)
- NeoForge 用の Mixin・AccessTransformer
- 互換層が提供していない NeoForge API の使用(不足している API 名を表示)

拒否された MOD は Mod Menu 用の一覧スタブ(`nf_<modid>`)だけ作られ、機能は動きません。
`java -jar triweave-0.1.0.jar check <jar...>` で、判定と理由を事前に確認できます。

互換層が提供するもの: `@Mod` / コンストラクタ引数(IEventBus, ModContainer, Dist)、
`@EventBusSubscriber` / `@SubscribeEvent`、`DeferredRegister`(Items, Blocks, 汎用)、`RegisterEvent`、
`BuildCreativeModeTabContentsEvent`(Fabric API の creativetab に接続)、`ServerTickEvent`、
`FMLCommonSetupEvent`、サーバーの起動/停止イベント、プレイヤーのログイン/ログアウト、`ClientTickEvent`、
**`BlockEvent.BreakEvent`(ブロック破壊、キャンセル可)、`LivingDeathEvent`(死亡、キャンセル可)** など。
これら以外のイベントのハンドラは「発火しない」旨をログに出します。

既知の制限: `DeferredHolder` は `Holder` を実装しない / `SidedThreadGroups.SERVER` 判定が常に false
(`queueServerWork` の遅延実行が動かない) / GUI(メニュー)は未実装 / ゲーム内イベント
(プレイヤー・ブロック破壊など)は未接続。**実機での動作は未確認**です。


## Modrinth App など(起動クラスを差し替えられないランチャー)

JVM 引数に次を追加するだけで、起動のたびに自動で準備されます。

```
-javaagent:C:\Triweave\triweave-0.1.0.jar
```

Fabric 26.3 のインスタンスを作り、上の引数を入れて起動します。Fabric 起動前に、翻訳済みjarと
Triweave 本体を `mods/` に `__triweave_` 付きで書き出します(MOD を消せば次回起動で自動掃除)。
手動実行: `java -jar triweave-0.1.0.jar prepare --gameDir <インスタンスのフォルダ>`

## ゲーム内コマンド

| コマンド | 内容 |
|---|---|
| `/mod` | Fabric / Quilt / NeoForge の全MOD一覧 |
| `/mod <種別> [list]` | `triweave` / `fabric` / `quilt` / `neoforge` / `bukkit` ごとの一覧 |
| `/mod <MOD名> [info]` | MODの情報(id・版・ローダー・状態・ファイル) |
| `/mod <MOD名> on` / `off` | MODのON/OFF(**次回起動で反映**。サーバーはOP権限が必要、Bukkit系は未対応) |
| `/mod <MOD名> reload` | MODが登録した再読み込み処理 + 設定の読み直し + リソース再読み込み |
| `/mod triweave [reload]` | Triweave の情報(Discord)/ リロード |

- MOD名は id・表示名・部分一致で指定できます(空白を含む名前は `"..."` で囲む)。
- OFF は、起動前に jar を `*.jar.triweave-off` に改名して行います(Modrinth の `.disabled` とは別)。
  他のMODが必須としているMOD・`fabric-api`・`triweave` はOFFにできません。
- **コードの再読み込みはできません**(JVMの制約)。MODの追加・削除・ON/OFFは再起動で反映されます。
- 一覧は起動時に `.triweave/modlist.tsv` として書き出されます。コマンド自体はクライアント・サーバー両方にあります。

## 起動モード(Java引数)

- 既定: 翻訳済みjarを `mods/` に `__triweave_` 付きで書き出す(実機で動作確認済み)。
- `-Dtriweave.mode=addmods`: `mods/` に何も書き出さず、`fabric.addMods` でFabricに渡す(**未検証**)。

## サポート / バグ報告

Discord: https://discord.gg/ZqDd74CC8B (Mod Menu の「ウェブサイト」「バグ報告」からも開けます)

> 注意: `/mod` コマンドと NeoForge 互換層は Minecraft のクラスに依存するため、
> この Gradle 設定のままでは `gradle build` が通りません。`tools/stubs-and-compile.sh` が
> コンパイル専用スタブで main をビルドします(API一覧は `tools/GenApiList.java` で再生成)(Loom 等で Minecraft を依存に加える必要があり、
> 26.3 での設定は未検証)。配布している `triweave-0.1.0.jar` は、26.3 用 Fabric API の実物の
> シグネチャに合わせてコンパイル済みです。

## 配布ファイル(クライアント用・サーバー用で分離)

| ファイル | 中身 |
|---|---|
| `triweave.cliant.26.3.0.1.0.jar` | クライアント用ランチャー。`TriweaveClient`/クライアント側 `/mod` のみ、Mod Menu同梱 |
| `triweave.server.26.3.0.1.0.jar` | サーバー用ランチャー。`TriweaveServer`/サーバー側 `/mod` のみ、Mod Menuは同梱しない |
| `triweave.api.26.3.0.1.0.jar` | `dev.triweave.api` 単体(クラス+ソース)。MOD開発用 |
| `triweave.core.mod.fabric.26.3.0.1.0.jar` | ランチャーで包まない、素のFabric MOD本体(クライアント・サーバー両方のエントリポイントを含む)。既存のFabricインスタンスに直接MODとして追加する場合用。ただし、Quilt翻訳・NeoForge検出・`/mod`の一覧(`modlist.tsv`)は起動前処理(ランチャー本体か `-javaagent`)が作るため、これ単体で `mods/` に置いただけでは、それらの機能は動かない |
| `triweave.source.zip` | ソース一式(`README.md`、`docs/`、`examples/`) |

## ビルド

JDK 21 以上と Gradle 8.x が必要です(実行時は Java 25)。

```
gradle build
```

`build/libs/triweave-0.1.0.jar` が配布物です(MOD本体 jar と Fabric API を内包)。
Fabric API を差し替えたい場合は `src/launcher/resources/triweave/fabric-api.jar` と
`bundled.properties` を更新してください。

### 同梱の Fabric API / Mod Menu について

このビルドに同梱しているのは **Fabric API 0.166.0+26.3**、**Mod Menu 21.0.0** です。調べた限り、
Mod Menu 21.0.0 は Minecraft 26.3 向けの最新安定版のままですが、Fabric API は **0.166.2+26.3**
が最新安定版としてリリース済みでした(本READMEの作成時点)。この開発環境はネットワークが
許可ドメインに限定されており、Modrinth・GitHubの配布物を直接取得できなかったため、
0.166.0+26.3 のまま同梱しています。差し替えたい場合は、Modrinthの Fabric API のバージョン
ページから `fabric-api-0.166.2+26.3.jar` をダウンロードし、`src/launcher/resources/triweave/fabric-api.jar`
を置き換えたうえで `bundled.properties` の `fabric_api_version` を `0.166.2+26.3` に変更してください。

## サーバー版(Fabric / Quilt / NeoForge + Bukkit系の検出)

専用サーバーでも、クライアントと同じ `triweave-0.1.0.jar` を使います。

### 導入

1. Fabric公式インストーラでサーバーを作ります:
   `java -jar fabric-installer.jar server -mcversion 26.3 -downloadMinecraft`
   (`fabric-server-launch.jar` ができます)
2. 同じフォルダで: `java -jar triweave-0.1.0.jar install-server`
   (`--dir <フォルダ>` / `--launch <launch jarの名前>` / `--mem <例: 6G>` を指定可能)
3. できた `start.bat` / `start.sh` で起動します(`-javaagent:triweave-x.y.z.jar` 付きで
   `fabric-server-launch.jar` を実行するだけのスクリプトです)。

MODは `mods/`、Bukkit系プラグインは `plugins/` に置きます。`eula.txt` の同意はFabricと同じく必要です。
`/mod` コマンドは**サーバーのコンソールと、OP権限のプレイヤーのみ**使えます(ON/OFF・reloadは権限
`COMMANDS_GAMEMASTER` 相当=OPレベル2以上、一覧・infoは誰でも可)。サーバーではMod Menu用のスタブは作られず、
`modmenu` も自動設置されません。

### Bukkit / Spigot / Paper 対応(plugin.yml形式。Paperの新形式(paper-plugin.yml)・Foliaは未対応)

NeoForgeと同じ「受け入れ判定→翻訳→実行」の形で、**plugin.yml形式のプラグインを実際に動かします。**
対応範囲は次に限られます(Bukkit APIのごく一部の再実装のため)。

- プラグインのライフサイクル(`onLoad` / `onEnable` / `onDisable`)、`getLogger()`
- 設定ファイル(`getConfig()` / YAMLの基本的なサブセットのみ。リストや複数行文字列は非対応)
- `Bukkit.getPluginManager().registerEvents(...)` によるイベント登録・発火(`@EventHandler`)
- コマンド(`getCommand(name).setExecutor(...)`)
- 同期/非同期タスク(`BukkitScheduler`。同期タスクはサーバーのtickに合わせて実行)
- `ChatColor`

**対応しないもの**: 実際のプレイヤー・ワールド・ブロック・インベントリとの連動(`getOnlinePlayers()`は
常に空)、権限システム(`PermissionDefault`等)、永続化(`NamespacedKey`等)、本体をjarinjar/shadow化で
内部jarに格納するプラグイン(静的なAPI判定ができないため拒否)、Kotlin。実質的に「設定・ログ・簡単な
イベントとコマンドだけを使う、自作の小さなプラグイン」向けです。

受け入れ判定はNeoForgeと同じ仕組み(使用APIを静的スキャンし、互換層が提供するAPIと突き合わせる)。
`java -jar triweave-0.1.0.jar check <plugin.jar>` で事前確認できます。実物4本(Chunky, LuckPerms,
voicechat, WorldEdit)はいずれも拒否されます(LuckPermsは内部jar格納、他3本は未対応APIが多数)。
自作の最小プラグイン(設定・ログ・イベント・コマンド・スケジューラのみ使用)では、受け入れ・翻訳・
起動・tick・設定保存までを確認済みです(偽のFabric環境上。実機は未確認)。

## インストール(公式ランチャー)

1. Fabric 公式インストーラで Minecraft 26.3 用の Fabric Loader をインストール
2. 次を実行:
   ```
   java -jar triweave-0.1.0.jar install
   ```
   (`--mc <.minecraftのパス>` / `--base <Fabricのバージョン名>` で指定可能)
3. ランチャーに追加された **Triweave 26.3** プロファイルで起動
4. MOD は通常どおり `mods/` に入れる(Fabric/Quilt/NeoForge 混在可)

この手順はクライアント向けです。専用サーバーは「サーバー版」の節を参照してください。

## 未検証の点
- 専用サーバー版(`install-server` / `-javaagent` での自動準備 / サーバー側 `/mod` の権限判定)は、実機のサーバー起動では未確認です。
- Bukkit/Spigot/Paper対応は、偽のFabric環境上と自作の最小プラグインで一通りの動作(受け入れ・翻訳・起動・イベント・コマンド・スケジューラ・設定)を確認済みですが、実機のサーバーでは未確認です。実物の4本(Chunky, LuckPerms, voicechat, WorldEdit)は、いずれも対応範囲外として拒否されます。
- NeoForgeの新しいイベント(`BlockEvent.BreakEvent`、`LivingDeathEvent`)は、Fabric API 26.3の実物のメソッド名で検証済みですが、実機では未確認です。
- 新しいTriweave API(`bus()`、`players()`、`broadcast()`、`onServerReady`)は、偽のサーバー環境で動作確認済みです。ただし `players()` が使う `getUUID` / `getGameProfile` / `isOp` 等のメソッド名は、26.3の実物では確認できていません(Mojangマッピングで長年変わっていない名前のため、恐らく問題ありませんが未検証です)。

- この環境では Minecraft・Fabric Loader の実物が取得できないため、**実機起動は未確認**です。
  確認済み: コンパイル、jar判定、Quilt翻訳(入れ子jar含む)、キャッシュ再利用、
  Fabric API自動設置、言語アダプタ(スタブのFabric APIに対して)。
- `fabric.addMods` でLoaderにMODを渡す方式に依存しています。
- ログは `[Triweave]` で始まります。不具合時はこの行を確認してください。

## ライセンス

Triweave: MIT。同梱の Fabric API: Apache-2.0(https://github.com/FabricMC/fabric)。
インストーラ用に Gson(Apache-2.0)も同梱しています。
