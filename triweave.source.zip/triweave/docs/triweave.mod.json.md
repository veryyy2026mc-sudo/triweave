# triweave.mod.json 仕様 (schema_version 1)

Triweave 独自のMODメタデータです。jar のルートに置きます。

## 読み込みの優先順位

`triweave.mod.json` > `fabric.mod.json` > `quilt.mod.json` > `neoforge.mods.toml`

- **`triweave.mod.json` のみ(または quilt / neoforge と併記)**: Triweave 形式として読み込みます。
  併記された quilt / neoforge のメタデータは**無視**されます(= triweave.mod.json が優先)。
- **`fabric.mod.json` と併記**: Fabric 自身が `fabric.mod.json` から直接読み込むため、動作は
  Fabric 形式のままです(Fabric Loader の仕組み上、これは変えられません)。この場合
  `triweave.mod.json` は、`/mod` や Triweave API に出る**名前・版などの表示情報**として優先して使われます。
- fabric / quilt / neoforge の jar は、これまでどおりそのまま実行できます。

## 書式

```json
{
  "schema_version": 1,
  "id": "examplemod",
  "version": "1.0.0",
  "name": "Example Mod",
  "description": "説明",
  "authors": ["Alice"],
  "contact": { "homepage": "https://example.com", "issues": "https://example.com/issues" },
  "license": "MIT",
  "icon": "assets/examplemod/icon.png",
  "environment": "*",

  "depends":    { "minecraft": "~26.3-", "fabric-api": "*", "triweave": ">=0.1.0" },
  "suggests":   { },
  "breaks":     { },
  "provides":   [ ],

  "entrypoints": {
    "main":     ["com.example.ExampleMod"],
    "client":   ["com.example.ExampleClient"],
    "server":   ["com.example.ExampleServer"],
    "neoforge": ["com.example.NeoForgeStyleMod"]
  },

  "mixins": ["examplemod.mixins.json"],
  "access_widener": "examplemod.accesswidener",
  "jars": [ { "file": "META-INF/jars/lib.jar" } ]
}
```

- `id` と `version` は必須。`environment` は `*` / `client` / `server`。
- `entrypoints.main|client|server` のクラスは、次のどの形式でも書けます。
  - Triweave 形式: `TriweaveInitializer` / `TriweaveClientInitializer` / `TriweaveServerInitializer`
  - Fabric 形式: `ModInitializer` / `ClientModInitializer` / `DedicatedServerModInitializer`
  - Quilt(QSL)形式
- `entrypoints.neoforge` は NeoForge 形式(`@Mod` クラス)で、Triweave の互換層で起動します
  (互換層が提供する NeoForge API の範囲のみ)。
- `depends` に `triweave` が無ければ `">=0.1.0"` が自動で足されます。
