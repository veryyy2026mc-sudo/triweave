# Triweave API

`dev.triweave.api` は、Fabric / Quilt / NeoForge(互換層)/ Triweave のどの形式のMODからも、
同じ書き方で使えます。依存の追加: `triweave-api-<ver>.jar` を compileOnly で参照し、実行時は Triweave が提供します。

| API | 内容 |
|---|---|
| `Triweave.mods()` / `mod(idOrName)` | ローダーをまたいだMOD情報(`ModInfo`: id・名前・版・ローダー・状態・備考) |
| `Triweave.isModLoaded(id)` / `loaderOf(id)` | NeoForge 互換層で動作中のMODも含めて判定 |
| `Triweave.setModEnabled(idOrName, boolean)` | MODのON/OFF(次回起動で反映)。必須MODや他MODが必要とするMODは拒否され、理由が返る |
| `Triweave.registerReloadListener(modId, Runnable)` | `/mod <MOD名> reload` で呼ばれる処理を登録 |
| `Triweave.services()` | 型とidで実装を登録・検索する、ローダー横断のサービス登録 |
| `Triweave.config(modId)` | `config/<modid>.properties`。`reload` で自動的に読み直される |
| `Triweave.bus()` | トピック文字列によるローダー横断のpublish/subscribe。Fabric/NeoForgeどちらにも無い、疎結合な連携手段 |
| `Triweave.players()` | 接続中の全プレイヤー(`CrossPlayer`: 名前・UUID・OP)。どのローダーのMODから呼んでも同じ結果 |
| `Triweave.broadcast(msg)` | サーバー・クライアントどちらでも使える一斉送信(チャット/コンソール) |
| `Triweave.onServerReady(r)` / `onServerStopping(r)` | サーバー起動完了/停止開始のフック。Fabric自体にはMOD種別を問わない統一フックが無い |
| `TriweaveInitializer` ほか | `triweave.mod.json` のエントリポイント用インターフェース(`TriweaveContext` を受け取る) |

### なぜ必要か(FabricにもNeoForgeにも無いもの)

- Fabric/NeoForgeのイベントは「相手のMODが公開した具体的なイベントクラス」をコンパイル時に知って
  いないと聞けない。`Triweave.bus()` は文字列1つで発行・購読でき、MOD同士が互いのクラスを知らなくても
  連携できる。
- `Triweave.players()` は、Fabric MOD・Quilt MOD・NeoForge MOD(互換層)のどこから呼んでも同じ
  プレイヤー一覧が返る。各ローダーは本来、自分の仕組みでしかプレイヤーを列挙できない。
- `Triweave.isModLoaded(id)` / `loaderOf(id)` は、NeoForgeの互換層で動いているMODも「読み込み済み」
  として扱う。Fabric単体の `FabricLoader.isModLoaded` は互換層実行中のNeoForge MODを知らない。

```java
// サーバーが起動したら、ローダーを問わず他のMODの存在を確認して連携する例
Triweave.onServerReady(() -> {
    if (Triweave.isModLoaded("some-neoforge-mod")) {
        Triweave.bus().publish("myaddon:ready", Map.of("version", 1));
    }
});
Triweave.bus().subscribe("myaddon:ready", (topic, data) -> {
    Triweave.broadcast("連携MODの準備ができました: " + data.get("version"));
});
```

```java
public class ExampleMod implements TriweaveInitializer {
    @Override
    public void onInitialize(TriweaveContext ctx) {
        int speed = ctx.config().getInt("speed", 5);
        ctx.onReload(() -> System.out.println("設定を読み直しました: " + ctx.config().getInt("speed", 5)));
        Triweave.services().register(MyApi.class, ctx.modId(), new MyApiImpl());
        if (Triweave.isModLoaded("sodium")) { /* 連携 */ }
    }
}
```
