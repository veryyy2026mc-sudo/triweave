package org.bukkit;

/** Bukkit互換shim(Triweave提供)。本物のBukkitと同じ静的アクセサ。 */
public final class Bukkit {
    private static Server server;

    private Bukkit() {}

    public static void setServer(Server s) { server = s; }

    public static Server getServer() { return server; }

    public static org.bukkit.plugin.PluginManager getPluginManager() { return server.getPluginManager(); }

    public static org.bukkit.scheduler.BukkitScheduler getScheduler() { return server.getScheduler(); }

    public static java.util.logging.Logger getLogger() { return server.getLogger(); }

    public static java.util.Collection<? extends Player> getOnlinePlayers() { return server.getOnlinePlayers(); }

    public static String getName() { return server.getName(); }

    public static String getVersion() { return server.getVersion(); }

    public static String getBukkitVersion() { return server.getBukkitVersion(); }

    public static void broadcastMessage(String message) { server.broadcastMessage(message); }
}
