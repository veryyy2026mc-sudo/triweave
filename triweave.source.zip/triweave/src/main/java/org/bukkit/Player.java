package org.bukkit;

/**
 * Bukkit互換shim(Triweave提供)。
 * v0.1では実在のプレイヤーと紐付いていない(README参照)。名前・UUIDの取得とメッセージ送信のみ対応。
 */
public interface Player {
    String getName();

    java.util.UUID getUniqueId();

    void sendMessage(String message);

    boolean hasPermission(String permission);

    boolean isOp();
}
