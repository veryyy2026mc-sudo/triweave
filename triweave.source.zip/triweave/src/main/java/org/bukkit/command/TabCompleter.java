package org.bukkit.command;

import java.util.List;

/** Bukkit互換shim(Triweave提供)。 */
@FunctionalInterface
public interface TabCompleter {
    List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args);
}
