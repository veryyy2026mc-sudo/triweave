package org.bukkit.command;

/** Bukkit互換shim(Triweave提供)。 */
public interface CommandSender {
    void sendMessage(String message);

    boolean hasPermission(String permission);

    String getName();
}
