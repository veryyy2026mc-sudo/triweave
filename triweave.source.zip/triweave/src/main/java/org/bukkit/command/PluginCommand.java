package org.bukkit.command;

import org.bukkit.plugin.Plugin;

/** Bukkit互換shim(Triweave提供)。 */
public final class PluginCommand extends Command {
    private final Plugin owner;
    private CommandExecutor executor;
    private TabCompleter completer;
    private String usage = "", description = "";

    public PluginCommand(String name, Plugin owner) { super(name); this.owner = owner; }

    public Plugin getPlugin() { return owner; }

    public void setExecutor(CommandExecutor executor) { this.executor = executor; }

    public CommandExecutor getExecutor() { return executor; }

    public void setTabCompleter(TabCompleter completer) { this.completer = completer; }

    public void setUsage(String usage) { this.usage = usage; }

    public String getUsage() { return usage; }

    public void setDescription(String description) { this.description = description; }

    public String getDescription() { return description; }

    @Override
    public boolean execute(CommandSender sender, String label, String[] args) {
        CommandExecutor e = executor != null ? executor : (owner instanceof CommandExecutor ce ? ce : null);
        return e != null && e.onCommand(sender, this, label, args);
    }
}
