package org.bukkit.command;

/** Bukkit互換shim(Triweave提供)。 */
@FunctionalInterface
public interface CommandExecutor {
    boolean onCommand(CommandSender sender, Command command, String label, String[] args);
}
