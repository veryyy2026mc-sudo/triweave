package org.bukkit.command;

/** Bukkit互換shim(Triweave提供)。 */
public abstract class Command {
    private final String name;

    protected Command(String name) { this.name = name; }

    public String getName() { return name; }

    public abstract boolean execute(CommandSender sender, String label, String[] args);
}
