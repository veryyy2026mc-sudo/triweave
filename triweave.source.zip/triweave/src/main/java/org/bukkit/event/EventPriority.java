package org.bukkit.event;

/** Bukkit互換shim(Triweave提供)。 */
public enum EventPriority { LOWEST, LOW, NORMAL, HIGH, HIGHEST, MONITOR }
