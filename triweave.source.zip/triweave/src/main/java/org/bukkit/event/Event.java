package org.bukkit.event;

/** Bukkit互換shim(Triweave提供)。 */
public abstract class Event {
    private final boolean async;

    public Event() { this(false); }

    public Event(boolean isAsync) { this.async = isAsync; }

    public boolean isAsynchronous() { return async; }

    public abstract HandlerList getHandlers();
}
