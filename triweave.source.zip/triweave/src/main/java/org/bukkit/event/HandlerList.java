package org.bukkit.event;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/** Bukkit互換shim(Triweave提供)。簡易実装(優先度順は未対応)。 */
public final class HandlerList {
    private final List<RegisteredListener> listeners = new CopyOnWriteArrayList<>();

    /** executor は (listener, event) を受け取って実行する(reflectionでもラムダでもよい)。 */
    public record RegisteredListener(Listener listener, Executor executor, EventPriority priority) {}

    @FunctionalInterface
    public interface Executor {
        void execute(Listener listener, Event event) throws Exception;
    }

    public void register(RegisteredListener l) { listeners.add(l); }

    public void unregister(Listener listener) { listeners.removeIf(l -> l.listener() == listener); }

    public List<RegisteredListener> getRegisteredListeners() { return listeners; }
}
