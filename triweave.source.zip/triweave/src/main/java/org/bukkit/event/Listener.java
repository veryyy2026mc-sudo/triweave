package org.bukkit.event;

/** Bukkit互換shim(Triweave提供)。マーカーインターフェース。 */
public interface Listener {}
