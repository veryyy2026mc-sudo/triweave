package org.bukkit.event;

/** Bukkit互換shim(Triweave提供)。 */
public interface Cancellable {
    boolean isCancelled();

    void setCancelled(boolean cancel);
}
