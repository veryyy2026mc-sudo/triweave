package org.bukkit;

/** Bukkit互換shim(Triweave提供)。Minecraftのセクション記号(§)で表現する。 */
public enum ChatColor {
    BLACK('0'), DARK_BLUE('1'), DARK_GREEN('2'), DARK_AQUA('3'), DARK_RED('4'), DARK_PURPLE('5'),
    GOLD('6'), GRAY('7'), DARK_GRAY('8'), BLUE('9'), GREEN('a'), AQUA('b'), RED('c'), LIGHT_PURPLE('d'),
    YELLOW('e'), WHITE('f'), MAGIC('k'), BOLD('l'), STRIKETHROUGH('m'), UNDERLINE('n'), ITALIC('o'), RESET('r');

    public static final char COLOR_CHAR = '\u00A7';
    private final String code;

    ChatColor(char c) { this.code = "" + COLOR_CHAR + c; }

    @Override public String toString() { return code; }

    public static String stripColor(String input) {
        return input == null ? null : input.replaceAll(COLOR_CHAR + ".", "");
    }

    public static String translateAlternateColorCodes(char alt, String text) {
        char[] b = text.toCharArray();
        for (int i = 0; i < b.length - 1; i++) {
            if (b[i] == alt && "0123456789AaBbCcDdEeFfKkLlMmNnOoRr".indexOf(b[i + 1]) > -1) {
                b[i] = COLOR_CHAR;
                b[i + 1] = Character.toLowerCase(b[i + 1]);
            }
        }
        return new String(b);
    }
}
