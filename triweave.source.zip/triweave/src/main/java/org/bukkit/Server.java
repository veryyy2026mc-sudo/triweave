package org.bukkit;

import java.util.Collection;
import java.util.logging.Logger;

/** Bukkit互換shim(Triweave提供)。範囲は限定的(README参照)。 */
public interface Server {
    org.bukkit.plugin.PluginManager getPluginManager();

    org.bukkit.scheduler.BukkitScheduler getScheduler();

    Logger getLogger();

    Collection<? extends Player> getOnlinePlayers();

    String getName();

    String getVersion();

    String getBukkitVersion();

    void broadcastMessage(String message);
}
