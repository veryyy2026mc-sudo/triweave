package org.bukkit.scheduler;

/** Bukkit互換shim(Triweave提供)。 */
public interface BukkitTask {
    int getTaskId();

    void cancel();
}
