package org.bukkit.scheduler;

import org.bukkit.plugin.Plugin;

/**
 * Bukkit互換shim(Triweave提供)。
 * 同期タスクはサーバーの毎tick(SimpleEventBus経由のServerTickEvent)に合わせて実行する。
 * 非同期タスクは専用スレッドで実行する。繰り返し間隔はtick数(1/20秒)。
 */
public interface BukkitScheduler {
    BukkitTask runTask(Plugin plugin, Runnable task);

    BukkitTask runTaskLater(Plugin plugin, Runnable task, long delayTicks);

    BukkitTask runTaskTimer(Plugin plugin, Runnable task, long delayTicks, long periodTicks);

    BukkitTask runTaskAsynchronously(Plugin plugin, Runnable task);

    void cancelTasks(Plugin plugin);
}
