package org.bukkit.configuration.file;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayDeque;
import java.util.Deque;

/**
 * Bukkit互換shim(Triweave提供)。
 * YAMLの小さなサブセット(キー: 値、インデントによるネスト、# コメント)だけを読み書きする。
 * リスト・複数行文字列・アンカー等、本格的なYAML機能は未対応。
 */
public final class YamlConfiguration extends FileConfiguration {
    public static YamlConfiguration loadConfiguration(File file) {
        YamlConfiguration y = new YamlConfiguration();
        try {
            if (file.isFile()) y.load(file);
        } catch (IOException ignored) {
            // 読めなければ空の設定として扱う
        }
        return y;
    }

    @Override
    public void load(File file) throws IOException {
        loadFromString(Files.readString(file.toPath(), StandardCharsets.UTF_8));
    }

    @Override
    public void loadFromString(String contents) {
        values.clear();
        Deque<int[]> stack = new ArrayDeque<>();          // [indent] -> 現在のパスの深さ管理
        Deque<String> path = new ArrayDeque<>();
        for (String raw : contents.split("\n", -1)) {
            String line = raw.replace("\r", "");
            String trimmed = line.strip();
            if (trimmed.isEmpty() || trimmed.startsWith("#")) continue;
            int indent = line.length() - line.stripLeading().length();
            int colon = trimmed.indexOf(':');
            if (colon < 0) continue;
            String key = trimmed.substring(0, colon).strip();
            String value = trimmed.substring(colon + 1).strip();

            while (!stack.isEmpty() && stack.peek()[0] >= indent) { stack.pop(); path.pop(); }
            StringBuilder full = new StringBuilder();
            for (String p : reversedCopy(path)) full.append(p).append('.');
            full.append(key);

            if (value.isEmpty()) {
                stack.push(new int[] {indent});
                path.push(key);
                createSection(full.toString());
            } else {
                set(full.toString(), unquote(value));
            }
        }
    }

    private static Iterable<String> reversedCopy(Deque<String> d) {
        var l = new java.util.ArrayList<>(d);
        java.util.Collections.reverse(l);
        return l;
    }

    private static Object unquote(String v) {
        if ((v.startsWith("\"") && v.endsWith("\"")) || (v.startsWith("'") && v.endsWith("'"))) {
            return v.substring(1, v.length() - 1);
        }
        if (v.equals("true") || v.equals("false")) return Boolean.parseBoolean(v);
        try { return Integer.parseInt(v); } catch (NumberFormatException ignored) { /* 数値ではない */ }
        try { return Double.parseDouble(v); } catch (NumberFormatException ignored) { /* 数値ではない */ }
        return v;
    }

    @Override
    public void save(File file) throws IOException {
        Files.createDirectories(file.getParentFile().toPath());
        Files.writeString(file.toPath(), saveToString(), StandardCharsets.UTF_8);
    }

    @Override
    public String saveToString() {
        StringBuilder sb = new StringBuilder();
        write(sb, this, 0);
        return sb.toString();
    }

    private void write(StringBuilder sb, org.bukkit.configuration.MemorySection s, int indent) {
        String pad = "  ".repeat(indent);
        for (var e : s.values.entrySet()) {
            if (e.getValue() instanceof org.bukkit.configuration.MemorySection child) {
                sb.append(pad).append(e.getKey()).append(":\n");
                write(sb, child, indent + 1);
            } else {
                sb.append(pad).append(e.getKey()).append(": ").append(e.getValue()).append('\n');
            }
        }
    }
}
