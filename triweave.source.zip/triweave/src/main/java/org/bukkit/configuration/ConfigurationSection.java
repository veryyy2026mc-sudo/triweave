package org.bukkit.configuration;

import java.util.Set;

/** Bukkit互換shim(Triweave提供)。ネスト("a.b.c")に対応した最小実装。 */
public interface ConfigurationSection {
    Object get(String path);

    Object get(String path, Object def);

    String getString(String path);

    String getString(String path, String def);

    int getInt(String path);

    int getInt(String path, int def);

    double getDouble(String path);

    double getDouble(String path, double def);

    boolean getBoolean(String path);

    boolean getBoolean(String path, boolean def);

    void set(String path, Object value);

    boolean contains(String path);

    boolean isSet(String path);

    Set<String> getKeys(boolean deep);

    ConfigurationSection getConfigurationSection(String path);

    ConfigurationSection createSection(String path);
}
