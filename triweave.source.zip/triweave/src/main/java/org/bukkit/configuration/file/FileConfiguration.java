package org.bukkit.configuration.file;

import java.io.File;
import java.io.IOException;

import org.bukkit.configuration.MemorySection;

/** Bukkit互換shim(Triweave提供)。 */
public abstract class FileConfiguration extends MemorySection {
    public abstract void save(File file) throws IOException;

    public abstract void load(File file) throws IOException;

    public abstract String saveToString();

    public abstract void loadFromString(String contents);
}
