package org.bukkit.configuration;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

/** Bukkit互換shim(Triweave提供)。本物同様、値はメモリ上のMapで持つ(ドット区切りでネスト)。 */
public class MemorySection implements ConfigurationSection {
    public final Map<String, Object> values = new LinkedHashMap<>();

    @Override
    public Object get(String path) { return get(path, null); }

    @Override
    public Object get(String path, Object def) {
        int dot = path.indexOf('.');
        if (dot < 0) return values.containsKey(path) ? values.get(path) : def;
        Object child = values.get(path.substring(0, dot));
        return child instanceof MemorySection s ? s.get(path.substring(dot + 1), def) : def;
    }

    @Override
    public String getString(String path) { return getString(path, null); }

    @Override
    public String getString(String path, String def) {
        Object v = get(path);
        return v == null ? def : String.valueOf(v);
    }

    @Override
    public int getInt(String path) { return getInt(path, 0); }

    @Override
    public int getInt(String path, int def) {
        try { return Integer.parseInt(String.valueOf(get(path, def))); } catch (NumberFormatException e) { return def; }
    }

    @Override
    public double getDouble(String path) { return getDouble(path, 0); }

    @Override
    public double getDouble(String path, double def) {
        try { return Double.parseDouble(String.valueOf(get(path, def))); } catch (NumberFormatException e) { return def; }
    }

    @Override
    public boolean getBoolean(String path) { return getBoolean(path, false); }

    @Override
    public boolean getBoolean(String path, boolean def) {
        Object v = get(path);
        return v == null ? def : Boolean.parseBoolean(String.valueOf(v));
    }

    @Override
    public void set(String path, Object value) {
        int dot = path.indexOf('.');
        if (dot < 0) { values.put(path, value); return; }
        String head = path.substring(0, dot);
        Object child = values.get(head);
        MemorySection section = child instanceof MemorySection s ? s : new MemorySection();
        values.put(head, section);
        section.set(path.substring(dot + 1), value);
    }

    @Override
    public boolean contains(String path) { return get(path) != null; }

    @Override
    public boolean isSet(String path) { return contains(path); }

    @Override
    public Set<String> getKeys(boolean deep) {
        Set<String> out = new TreeSet<>();
        for (var e : values.entrySet()) {
            out.add(e.getKey());
            if (deep && e.getValue() instanceof MemorySection s) {
                for (String k : s.getKeys(true)) out.add(e.getKey() + "." + k);
            }
        }
        return out;
    }

    @Override
    public ConfigurationSection getConfigurationSection(String path) {
        Object v = get(path);
        return v instanceof ConfigurationSection s ? s : null;
    }

    @Override
    public ConfigurationSection createSection(String path) {
        MemorySection s = new MemorySection();
        set(path, s);
        return s;
    }
}
