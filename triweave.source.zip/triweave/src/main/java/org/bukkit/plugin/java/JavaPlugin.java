package org.bukkit.plugin.java;

import java.io.File;
import java.io.IOException;
import java.util.logging.Logger;

import org.bukkit.Server;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.PluginDescriptionFile;

/**
 * Bukkit互換shim(Triweave提供)。本物のBukkitと同じく、プラグインは普通これを継承する。
 * フィールドは、本物同様 {@link #init} 経由でランタイム(dev.triweave.bukkit.BukkitRuntime)が設定する。
 */
public abstract class JavaPlugin implements Plugin {
    private Server server;
    private PluginDescriptionFile description;
    private File dataFolder;
    private File file;
    private Logger logger;
    private FileConfiguration config;
    private File configFile;
    private boolean enabled;

    protected JavaPlugin() {}

    /** Triweaveのランタイムが、無引数コンストラクタ呼び出し直後に1回だけ呼ぶ。 */
    public final void init(Server server, PluginDescriptionFile description, File dataFolder, File file) {
        this.server = server;
        this.description = description;
        this.dataFolder = dataFolder;
        this.file = file;
        this.logger = Logger.getLogger(description.getName());
        this.configFile = new File(dataFolder, "config.yml");
    }

    final void setEnabled(boolean enabled) { this.enabled = enabled; }

    @Override public String getName() { return description.getName(); }

    @Override public PluginDescriptionFile getDescription() { return description; }

    @Override public Server getServer() { return server; }

    @Override public Logger getLogger() { return logger; }

    @Override public File getDataFolder() { return dataFolder; }

    public File getFile() { return file; }

    @Override public boolean isEnabled() { return enabled; }

    @Override
    public FileConfiguration getConfig() {
        if (config == null) reloadConfig();
        return config;
    }

    @Override
    public void reloadConfig() {
        config = YamlConfiguration.loadConfiguration(configFile);
    }

    @Override
    public void saveConfig() {
        try {
            if (config != null) config.save(configFile);
        } catch (IOException e) {
            getLogger().warning("could not save config.yml: " + e);
        }
    }

    @Override
    public void saveDefaultConfig() {
        if (!configFile.exists()) saveConfig();
    }

    @Override public void onLoad() {}

    @Override public void onEnable() {}

    @Override public void onDisable() {}
}
