package org.bukkit.plugin;

import org.bukkit.event.Event;
import org.bukkit.event.Listener;

/** Bukkit互換shim(Triweave提供)。 */
@FunctionalInterface
public interface EventExecutor {
    void execute(Listener listener, Event event) throws Exception;
}
