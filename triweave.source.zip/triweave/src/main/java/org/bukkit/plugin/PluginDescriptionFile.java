package org.bukkit.plugin;

/** Bukkit互換shim(Triweave提供)。plugin.yml の内容を最低限保持する。 */
public final class PluginDescriptionFile {
    private final String name, version, main, description;

    public PluginDescriptionFile(String name, String version, String main) {
        this(name, version, main, "");
    }

    public PluginDescriptionFile(String name, String version, String main, String description) {
        this.name = name; this.version = version; this.main = main; this.description = description;
    }

    public String getName() { return name; }

    public String getVersion() { return version; }

    public String getMain() { return main; }

    public String getDescription() { return description; }

    public String getFullName() { return name + " v" + version; }
}
