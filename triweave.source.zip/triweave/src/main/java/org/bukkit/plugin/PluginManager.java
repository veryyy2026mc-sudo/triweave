package org.bukkit.plugin;

import org.bukkit.event.Event;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;

/** Bukkit互換shim(Triweave提供)。簡易実装: 優先度順の呼び出し順は保証しない。 */
public interface PluginManager {
    void registerEvents(Listener listener, Plugin plugin);

    void callEvent(Event event);

    Plugin getPlugin(String name);

    Plugin[] getPlugins();

    boolean isPluginEnabled(String name);

    /** 直接ハンドラを足す低レベルAPI(通常は registerEvents を使う)。 */
    void registerEvent(Class<? extends Event> event, Listener listener, EventPriority priority,
            org.bukkit.plugin.EventExecutor executor, Plugin plugin);
}
