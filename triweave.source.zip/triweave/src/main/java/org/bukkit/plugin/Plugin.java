package org.bukkit.plugin;

import java.io.File;
import java.util.logging.Logger;

import org.bukkit.Server;
import org.bukkit.configuration.file.FileConfiguration;

/** Bukkit互換shim(Triweave提供)。 */
public interface Plugin {
    String getName();

    PluginDescriptionFile getDescription();

    Server getServer();

    Logger getLogger();

    File getDataFolder();

    FileConfiguration getConfig();

    void saveConfig();

    void saveDefaultConfig();

    void reloadConfig();

    boolean isEnabled();

    void onLoad();

    void onEnable();

    void onDisable();
}
