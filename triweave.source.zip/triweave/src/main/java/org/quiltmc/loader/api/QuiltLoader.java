package org.quiltmc.loader.api;

import java.nio.file.Path;
import java.util.Optional;

import dev.triweave.quilt.TriweaveModContainer;
import net.fabricmc.loader.api.FabricLoader;

/** Quilt Loader API の最小互換shim。呼び出しはFabric Loaderへ委譲する。 */
public final class QuiltLoader {
    private QuiltLoader() {}

    public static boolean isModLoaded(String id) {
        return FabricLoader.getInstance().isModLoaded(id);
    }

    public static boolean isDevelopmentEnvironment() {
        return FabricLoader.getInstance().isDevelopmentEnvironment();
    }

    public static Path getConfigDir() {
        return FabricLoader.getInstance().getConfigDir();
    }

    public static Path getGameDir() {
        return FabricLoader.getInstance().getGameDir();
    }

    public static Optional<ModContainer> getModContainer(String id) {
        return FabricLoader.getInstance().getModContainer(id).map(TriweaveModContainer::new);
    }
}
