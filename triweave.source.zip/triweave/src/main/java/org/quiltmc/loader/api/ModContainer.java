package org.quiltmc.loader.api;

import java.nio.file.Path;

/** Quilt Loader API の最小互換shim(Triweave提供)。 */
public interface ModContainer {
    ModMetadata metadata();
    Path rootPath();
}
