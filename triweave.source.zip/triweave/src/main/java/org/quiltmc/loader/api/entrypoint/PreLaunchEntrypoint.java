package org.quiltmc.loader.api.entrypoint;

import org.quiltmc.loader.api.ModContainer;

/** Quilt Loader API の最小互換shim(Triweave提供)。 */
public interface PreLaunchEntrypoint {
    void onPreLaunch(ModContainer mod);
}
