package org.quiltmc.loader.api;

/** Quilt Loader API の最小互換shim(Triweave提供)。 */
public interface Version {
    String raw();
}
