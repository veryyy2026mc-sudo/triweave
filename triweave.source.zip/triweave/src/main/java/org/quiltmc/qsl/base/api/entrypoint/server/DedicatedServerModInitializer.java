package org.quiltmc.qsl.base.api.entrypoint.server;

import org.quiltmc.loader.api.ModContainer;

/** QSL の最小互換shim(Triweave提供)。 */
public interface DedicatedServerModInitializer {
    void onInitializeServer(ModContainer mod);
}
