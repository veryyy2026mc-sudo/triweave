package org.quiltmc.qsl.base.api.entrypoint.client;

import org.quiltmc.loader.api.ModContainer;

/** QSL の最小互換shim(Triweave提供)。 */
public interface ClientModInitializer {
    void onInitializeClient(ModContainer mod);
}
