package org.quiltmc.qsl.base.api.entrypoint;

import org.quiltmc.loader.api.ModContainer;

/** QSL の最小互換shim(Triweave提供)。 */
public interface ModInitializer {
    void onInitialize(ModContainer mod);
}
