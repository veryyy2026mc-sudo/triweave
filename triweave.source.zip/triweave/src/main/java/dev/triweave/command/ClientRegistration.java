package dev.triweave.command;

import dev.triweave.neoforge.Mc;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.minecraft.network.chat.Component;

/** クライアント用の登録(専用サーバーでは読み込まれない)。 */
public final class ClientRegistration {
    private ClientRegistration() {}

    public static void register() {
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, buildContext) -> {
            try {
                dispatcher.register(ModListCommand.<FabricClientCommandSource>build(ClientSink::new));
            } catch (Throwable t) {
                System.err.println("[Triweave] /mod registration failed: " + t);   // ゲームは落とさない
            }
        });
    }

    private record ClientSink(FabricClientCommandSource src) implements ModListCommand.Sink {
        @Override public void say(String m) { src.sendFeedback(Component.literal(m)); }
        @Override public void error(String m) { src.sendError(Component.literal(m)); }
        @Override public boolean canAdmin() { return true; }
        @Override public boolean isServer() { return false; }
        @Override public boolean reloadResources() {
            try {
                Mc.invoke(Mc.invokeStatic("net.minecraft.client.Minecraft", "getInstance"), "reloadResourcePacks");
                return true;
            } catch (Throwable t) {
                return false;
            }
        }
    }
}
