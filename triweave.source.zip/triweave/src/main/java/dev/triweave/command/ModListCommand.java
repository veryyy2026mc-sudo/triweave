package dev.triweave.command;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.builder.RequiredArgumentBuilder;

import dev.triweave.api.Loader;
import dev.triweave.api.ModInfo;
import dev.triweave.api.State;
import dev.triweave.api.ToggleResult;
import dev.triweave.api.Triweave;

/**
 * /mod コマンド本体(クライアント・サーバー共通)。
 *
 * /mod                          全MODの一覧
 * /mod <ローダー名> [list]      triweave / fabric / quilt / neoforge / bukkit ごとの一覧
 * /mod <MOD名> [info]           MODの情報
 * /mod <MOD名> on|off           MODのON/OFF(次回起動で反映。サーバーはOP権限が必要)
 * /mod <MOD名> reload           再読み込み(MODが登録した処理 + クライアントはリソース)
 * /mod triweave [reload]        Triweave の情報 / 全体リロード
 */
public final class ModListCommand {
    static final String DISCORD = "https://discord.gg/ZqDd74CC8B";

    private ModListCommand() {}

    /** コマンド実行元の違い(クライアント / サーバー)を吸収する出力先。 */
    public interface Sink {
        void say(String message);
        void error(String message);
        /** ON/OFF・リロードを実行してよいか(サーバーでは権限レベル2以上)。 */
        boolean canAdmin();
        /** 専用サーバーなら true。 */
        boolean isServer();
        /** クライアントのリソース再読み込み。できなければ false。サーバーは常に false。 */
        boolean reloadResources();
    }

    // ------------------------------------------------------------------ コマンド木

    public static <S> LiteralArgumentBuilder<S> build(Function<S, Sink> sinkOf) {
        LiteralArgumentBuilder<S> root = LiteralArgumentBuilder.<S>literal("mod")
                .executes(c -> safe(() -> list(sinkOf.apply(c.getSource()), null)));

        for (Loader loader : new Loader[] {Loader.FABRIC, Loader.QUILT, Loader.NEOFORGE, Loader.BUKKIT}) {
            String n = loader.name().toLowerCase();
            root.then(LiteralArgumentBuilder.<S>literal(n)
                    .executes(c -> safe(() -> list(sinkOf.apply(c.getSource()), loader)))
                    .then(LiteralArgumentBuilder.<S>literal("list")
                            .executes(c -> safe(() -> list(sinkOf.apply(c.getSource()), loader)))));
        }

        root.then(LiteralArgumentBuilder.<S>literal("triweave")
                .executes(c -> safe(() -> triweaveInfo(sinkOf.apply(c.getSource()))))
                .then(LiteralArgumentBuilder.<S>literal("list")
                        .executes(c -> safe(() -> list(sinkOf.apply(c.getSource()), Loader.TRIWEAVE))))
                .then(LiteralArgumentBuilder.<S>literal("reload")
                        .requires(s -> sinkOf.apply(s).canAdmin())
                        .executes(c -> safe(() -> reload(sinkOf.apply(c.getSource()), null)))));

        root.then(RequiredArgumentBuilder.<S, String>argument("name", StringArgumentType.string())
                .executes(c -> safe(() -> info(sinkOf.apply(c.getSource()), StringArgumentType.getString(c, "name"))))
                .then(LiteralArgumentBuilder.<S>literal("info")
                        .executes(c -> safe(() -> info(sinkOf.apply(c.getSource()), StringArgumentType.getString(c, "name")))))
                .then(LiteralArgumentBuilder.<S>literal("on")
                        .requires(s -> sinkOf.apply(s).canAdmin())
                        .executes(c -> safe(() -> setState(sinkOf.apply(c.getSource()), StringArgumentType.getString(c, "name"), true))))
                .then(LiteralArgumentBuilder.<S>literal("off")
                        .requires(s -> sinkOf.apply(s).canAdmin())
                        .executes(c -> safe(() -> setState(sinkOf.apply(c.getSource()), StringArgumentType.getString(c, "name"), false))))
                .then(LiteralArgumentBuilder.<S>literal("reload")
                        .requires(s -> sinkOf.apply(s).canAdmin())
                        .executes(c -> safe(() -> reload(sinkOf.apply(c.getSource()), StringArgumentType.getString(c, "name"))))));
        return root;
    }

    private interface Action { int run() throws Exception; }

    /** どんなエラーでもゲーム/サーバーを落とさない。 */
    private static int safe(Action a) {
        try {
            return a.run();
        } catch (Throwable t) {
            System.err.println("[Triweave] /mod failed: " + t);
            return 0;
        }
    }

    // ------------------------------------------------------------------ 一覧 / 情報

    static int list(Sink out, Loader only) {
        Loader[] loaders = only == null ? Loader.values() : new Loader[] {only};
        Map<Loader, List<ModInfo>> by = new EnumMap<>(Loader.class);
        for (ModInfo m : Triweave.mods()) by.computeIfAbsent(m.loader(), k -> new ArrayList<>()).add(m);
        for (Loader l : loaders) {
            List<ModInfo> items = by.getOrDefault(l, List.of());
            if (only == null && l == Loader.BUKKIT && items.isEmpty()) continue;     // プラグインが無ければ出さない
            out.say("§6== " + title(l) + " (" + items.size() + ") ==");
            for (ModInfo m : items) out.say(line(m));
            if (items.isEmpty()) out.say("§7  (なし)");
        }
        return 1;
    }

    static String title(Loader l) {
        return switch (l) {
            case TRIWEAVE -> "Triweave MOD (triweave.mod.json)";
            case FABRIC -> "Fabric MOD";
            case QUILT -> "Quilt MOD (Fabricに翻訳)";
            case NEOFORGE -> "NeoForge MOD";
            case BUKKIT -> "Bukkit/Spigot/Paper プラグイン";
        };
    }

    static String status(ModInfo m) {
        if (m.state() == State.DISABLED) return m.pendingOff() ? "§7[OFF]" : "§e[次回起動でON]";
        if (m.pendingOff() && m.state() == State.RUNNING) return "§e[次回起動でOFF]";
        return switch (m.state()) {
            case RUNNING -> m.loader() == Loader.NEOFORGE ? "§b[互換実行]" : "§a[読込済]";
            case REJECTED -> "§c[未対応]";
            default -> "§e[未読込]";
        };
    }

    static String line(ModInfo m) {
        String ver = m.version().isEmpty() ? "" : " " + m.version();
        String why = m.state() == State.REJECTED && m.note().startsWith("rejected: ")
                ? " §8(" + m.note().substring("rejected: ".length()) + ")" : "";
        return "§f  " + status(m) + " §f" + m.name() + "§7" + ver + why;
    }

    static int info(Sink out, String name) {
        Optional<ModInfo> o = Triweave.mod(name);
        if (o.isEmpty()) { out.error("[Triweave] MODが見つかりません: " + name); return 0; }
        ModInfo m = o.get();
        out.say("§6== " + m.name() + " ==");
        out.say("§7  id: §f" + m.id() + "§7  版: §f" + (m.version().isEmpty() ? "?" : m.version()));
        out.say("§7  種別: §f" + title(m.loader()) + "§7  状態: " + status(m));
        out.say("§7  ファイル: §f" + m.file());
        if (!m.note().isEmpty()) out.say("§7  備考: §f" + m.note());
        return 1;
    }

    static int triweaveInfo(Sink out) {
        out.say("§6== Triweave " + Triweave.version() + (out.isServer() ? " (サーバー)" : "") + " ==");
        out.say("§7  Triweave / Fabric / Quilt(翻訳) / NeoForge(互換層) のMODを1つのローダーで動かします");
        out.say("§7  使い方: §f/mod§7  /mod <種別> [list]  /mod <MOD名> on|off|reload");
        out.say("§b  Discord(ウェブサイト・バグ報告): §f" + DISCORD);
        return 1;
    }

    // ------------------------------------------------------------------ ON / OFF

    static int setState(Sink out, String name, boolean on) {
        if (!out.canAdmin()) { out.error("[Triweave] この操作にはOP権限が必要です"); return 0; }
        ToggleResult r = Triweave.setModEnabled(name, on);
        switch (r.status()) {
            case OK -> {
                out.say("§a[Triweave] " + r.mod().name() + " を " + (on ? "ON" : "OFF")
                        + " にしました。§7" + (out.isServer() ? "サーバー" : "ゲーム") + "を再起動すると反映されます。");
                return 1;
            }
            case UNSUPPORTED -> out.error("[Triweave] " + r.mod().name() + " はこの種別では切り替えられません");
            case NOT_FOUND -> out.error("[Triweave] MODが見つかりません: " + name);
            case PROTECTED -> out.error("[Triweave] " + r.mod().name() + " は Triweave の動作に必要なため OFF にできません");
            case REQUIRED_BY_OTHERS -> out.error("[Triweave] " + r.mod().name() + " は " + String.join(", ", r.blockers())
                    + " が必要としているため OFF にできません(先にそちらをOFFにしてください)");
        }
        return 0;
    }

    // ------------------------------------------------------------------ リロード

    static int reload(Sink out, String name) {
        if (!out.canAdmin()) { out.error("[Triweave] この操作にはOP権限が必要です"); return 0; }
        String modId = null;
        if (name != null) {
            Optional<ModInfo> o = Triweave.mod(name);
            if (o.isEmpty()) { out.error("[Triweave] MODが見つかりません: " + name); return 0; }
            modId = o.get().id();
        }
        int n = Triweave.reload(modId);                         // MODが登録した処理 + 設定の読み直し
        out.say("§a[Triweave] リロード: MODの再読み込み処理を " + n + " 件実行しました");
        if (out.isServer()) {
            out.say("§7  データパック等の再読み込みは §f/reload §7を使ってください");
        } else if (out.reloadResources()) {
            out.say("§a  リソース(アセット/データ)も再読み込みしました");
        } else {
            out.say("§e  リソースは自動で再読み込みできませんでした。F3+T を押してください");
        }
        out.say("§7  ※ MODのコードの入れ替え・追加/削除/ON/OFFは、再起動で反映されます");
        return 1;
    }
}
