package dev.triweave.command;

import java.util.function.Supplier;

import dev.triweave.neoforge.Mc;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.network.chat.Component;

/**
 * 専用サーバー用の登録。権限は 26.3 の仕組み(source.permissions() / Permissions.COMMANDS_GAMEMASTER)で判定する。
 * 名前はすべて Fabric API 26.3 のバイトコードで実在を確認済み。
 */
public final class ServerRegistration {
    private ServerRegistration() {}

    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, buildContext, selection) -> {
            try {
                dispatcher.register(ModListCommand.<CommandSourceStack>build(ServerSink::new));
            } catch (Throwable t) {
                System.err.println("[Triweave] /mod registration failed: " + t);   // サーバーは落とさない
            }
        });
    }

    private record ServerSink(CommandSourceStack src) implements ModListCommand.Sink {
        @Override public void say(String m) {
            Supplier<Object> msg = () -> Component.literal(m);
            Mc.invoke(src, "sendSuccess", msg, Boolean.FALSE);
        }

        @Override public void error(String m) {
            try {
                Mc.invoke(src, "sendFailure", Component.literal(m));
            } catch (RuntimeException e) {
                say("§c" + m);                                           // sendFailure が無い場合の代替
            }
        }

        @Override public boolean canAdmin() {
            try {
                Object perms = Mc.invoke(src, "permissions");
                Object need = Mc.staticField("net.minecraft.server.permissions.Permissions", "COMMANDS_GAMEMASTER");
                return Boolean.TRUE.equals(Mc.invoke(perms, "hasPermission", need));
            } catch (Throwable t) {
                return false;                                            // 判定できなければ拒否(安全側)
            }
        }

        @Override public boolean isServer() { return true; }

        @Override public boolean reloadResources() { return false; }
    }
}
