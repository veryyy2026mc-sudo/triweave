package dev.triweave;

import net.fabricmc.api.DedicatedServerModInitializer;

/** 専用サーバー側の入口。/mod コマンドを登録する(失敗してもサーバーは止めない)。 */
public final class TriweaveServer implements DedicatedServerModInitializer {
    @Override
    public void onInitializeServer() {
        try {
            dev.triweave.command.ServerRegistration.register();
        } catch (Throwable t) {
            System.err.println("[Triweave] /mod command could not be registered: " + t);
        }
    }
}
