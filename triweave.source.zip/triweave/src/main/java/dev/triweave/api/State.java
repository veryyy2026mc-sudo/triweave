package dev.triweave.api;

/** MODの状態。 */
public enum State {
    /** 読み込まれて動作中 */
    RUNNING,
    /** 読み込まれていない(追加直後で未再起動など) */
    NOT_LOADED,
    /** Triweave がOFFにしている(次回起動で反映) */
    DISABLED,
    /** 互換層で動かせないため拒否された(NeoForge MOD) */
    REJECTED
}
