package dev.triweave.api;

/** MODがどのローダー形式で読み込まれたか。 */
public enum Loader { TRIWEAVE, FABRIC, QUILT, NEOFORGE, BUKKIT }
