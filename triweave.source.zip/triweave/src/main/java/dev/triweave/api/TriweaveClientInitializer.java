package dev.triweave.api;

/** triweave.mod.json の entrypoints.client に書くクラスが実装する(クライアントのみ)。 */
public interface TriweaveClientInitializer {
    void onInitializeClient(TriweaveContext ctx);
}
