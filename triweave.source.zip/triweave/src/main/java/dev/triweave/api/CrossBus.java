package dev.triweave.api;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.function.BiConsumer;

/**
 * トピック文字列によるpublish/subscribe(発行/購読)。
 *
 * <p>Fabric・NeoForge双方とも、イベントは「事前に決まったイベントクラス」単位でしか配れない
 * (相手のMODの具体的な型をコンパイル時に知る必要がある)。CrossBusは、文字列1つとMapのデータだけで
 * ローダーをまたいでMOD同士が疎結合に連携できる仕組みで、FabricにもNeoForgeにも存在しない。
 */
public final class CrossBus {
    private final Map<String, List<BiConsumer<String, Map<String, Object>>>> subs = new ConcurrentHashMap<>();

    public CrossBus() {}

    /** topic にメッセージを発行する。購読者がいなくても例外にはならない。 */
    public void publish(String topic, Map<String, Object> data) {
        for (var s : subs.getOrDefault(topic, List.of())) {
            try {
                s.accept(topic, data);
            } catch (Throwable t) {
                System.err.println("[Triweave] CrossBus subscriber failed for '" + topic + "': " + t);
            }
        }
    }

    /** topic を購読する。handler は (topic, data) を受け取る。 */
    public void subscribe(String topic, BiConsumer<String, Map<String, Object>> handler) {
        subs.computeIfAbsent(topic, k -> new CopyOnWriteArrayList<>()).add(handler);
    }

    public void unsubscribe(String topic, BiConsumer<String, Map<String, Object>> handler) {
        subs.getOrDefault(topic, List.of()).remove(handler);
    }
}
