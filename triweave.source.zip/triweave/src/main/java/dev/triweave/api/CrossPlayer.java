package dev.triweave.api;

import java.util.UUID;

/** {@link Triweave#players()} が返す、ローダーに依存しないプレイヤー情報。 */
public record CrossPlayer(String name, UUID uuid, boolean op) {}
