package dev.triweave.api;

public enum ToggleStatus {
    OK,
    NOT_FOUND,
    /** Triweaveの動作に必要なMODのため切り替えられない */
    PROTECTED,
    /** 他のMODが必須としているためOFFにできない */
    REQUIRED_BY_OTHERS,
    /** このローダー形式(Bukkitプラグイン等)は、Triweaveでは切り替えられない */
    UNSUPPORTED
}
