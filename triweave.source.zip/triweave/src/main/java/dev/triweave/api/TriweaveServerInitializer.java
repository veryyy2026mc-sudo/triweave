package dev.triweave.api;

/** triweave.mod.json の entrypoints.server に書くクラスが実装する(専用サーバーのみ)。 */
public interface TriweaveServerInitializer {
    void onInitializeServer(TriweaveContext ctx);
}
