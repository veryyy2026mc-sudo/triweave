package dev.triweave.api;

/**
 * ローダーをまたいだMOD情報。
 *
 * @param pendingOff OFFが指定されているが、まだ起動中(次回起動でOFFになる)
 * @param note       補足(拒否理由など)。なければ空文字
 */
public record ModInfo(String id, String name, String version, Loader loader, State state,
                      boolean pendingOff, String file, String note) {}
