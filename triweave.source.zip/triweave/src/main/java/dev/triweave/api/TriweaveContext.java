package dev.triweave.api;

import java.nio.file.Path;

/** Triweave形式のエントリポイントに渡される、そのMOD用の情報と機能。 */
public interface TriweaveContext {
    String modId();

    Path configDir();

    /** このMODの設定(config/&lt;modid&gt;.properties)。 */
    ModConfig config();

    Services services();

    /** {@code /mod <このMOD> reload} で呼ばれる処理を登録する。 */
    void onReload(Runnable listener);
}
