package dev.triweave.api;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

import dev.triweave.core.TriweaveCore;

/**
 * Triweave 独自API(ローダー非依存)。
 *
 * <ul>
 *   <li>{@link #mods()} / {@link #mod(String)} : Fabric・Quilt・NeoForge・Triweave を横断したMOD情報</li>
 *   <li>{@link #setModEnabled(String, boolean)} : MODのON/OFF(次回起動で反映)</li>
 *   <li>{@link #registerReloadListener(String, Runnable)} : /mod &lt;MOD名&gt; reload で呼ばれる処理</li>
 *   <li>{@link #services()} : ローダーをまたぐサービス登録</li>
 *   <li>{@link #config(String)} : 簡易設定ファイル</li>
 * </ul>
 */
public final class Triweave {
    private Triweave() {}

    public static String version() { return TriweaveCore.version(); }

    /** Triweaveが把握している全MOD(OFFのもの・拒否されたものを含む)。 */
    public static Collection<ModInfo> mods() { return TriweaveCore.mods(); }

    /** idまたは表示名(大文字小文字無視・部分一致)でMODを探す。 */
    public static Optional<ModInfo> mod(String idOrName) { return Optional.ofNullable(TriweaveCore.find(idOrName)); }

    /** どのローダー形式でも、実際に動作中ならtrue。 */
    public static boolean isModLoaded(String id) { return TriweaveCore.isRunning(id); }

    public static Optional<Loader> loaderOf(String id) { return mod(id).map(ModInfo::loader); }

    /** MODをON/OFFにする。OFFにできない場合は status に理由が入る。反映は次回起動時。 */
    public static ToggleResult setModEnabled(String idOrName, boolean enabled) {
        return TriweaveCore.setEnabled(idOrName, enabled);
    }

    public static Services services() { return TriweaveCore.services(); }

    /** トピック文字列によるローダー横断のpublish/subscribe。FabricにもNeoForgeにも無い仕組み。 */
    public static CrossBus bus() { return TriweaveCore.bus(); }

    /**
     * 現在接続中の全プレイヤー。Fabric/Quilt/NeoForge(互換層)どのMODから呼んでも同じ結果になる
     * (各ローダーは本来、自分の仕組みでしかプレイヤーを列挙できない)。クライアント単体では空。
     */
    public static List<CrossPlayer> players() { return TriweaveCore.players(); }

    /** サーバー・クライアントどちらでも使える、チャット/コンソールへの一斉送信。 */
    public static void broadcast(String message) { TriweaveCore.broadcast(message); }

    /**
     * サーバーが起動を終えたとき(クライアントなら統合サーバー起動時)に呼ばれる。
     * 既にサーバーが起動済みなら、登録時点ですぐ呼ばれる。
     */
    public static void onServerReady(Runnable listener) { TriweaveCore.onServerReady(listener); }

    /** サーバーが停止を始めるときに呼ばれる。 */
    public static void onServerStopping(Runnable listener) { TriweaveCore.onServerStopping(listener); }

    /** MOD用の設定。同じ modId なら同じインスタンスが返る。 */
    public static ModConfig config(String modId) { return TriweaveCore.config(modId); }

    /** /mod <MOD名> reload(modId が null の場合は /mod triweave reload)で呼ばれる処理を登録する。 */
    public static void registerReloadListener(String modId, Runnable listener) {
        TriweaveCore.registerReload(modId, listener);
    }

    /**
     * 登録済みの再読み込み処理を実行する(設定ファイルの読み直しを含む)。
     *
     * @param modId null なら全MOD
     * @return 実行した処理の数
     */
    public static int reload(String modId) { return TriweaveCore.reload(modId); }
}
