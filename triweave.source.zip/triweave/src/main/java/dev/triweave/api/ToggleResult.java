package dev.triweave.api;

import java.util.List;

/** @param blockers REQUIRED_BY_OTHERS のとき、そのMODを必要としているMODの名前 */
public record ToggleResult(ToggleStatus status, ModInfo mod, List<String> blockers) {
    public boolean ok() { return status == ToggleStatus.OK; }
}
