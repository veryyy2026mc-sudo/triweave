package dev.triweave.api;

/** triweave.mod.json の entrypoints.main に書くクラスが実装する(両側で実行)。 */
public interface TriweaveInitializer {
    void onInitialize(TriweaveContext ctx);
}
