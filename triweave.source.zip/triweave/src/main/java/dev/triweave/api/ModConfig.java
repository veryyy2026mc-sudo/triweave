package dev.triweave.api;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/**
 * 簡易な設定ファイル(config/&lt;modid&gt;.properties)。どのローダーのMODからも同じ書き方で使える。
 * {@code /mod <MOD名> reload} で自動的に {@link #reload()} される。
 */
public final class ModConfig {
    private final Path file;
    private final Properties props = new Properties();

    public ModConfig(Path file) {
        this.file = file;
        reload();
    }

    /** ファイルから読み直す(無ければ空)。 */
    public synchronized void reload() {
        props.clear();
        if (!Files.isRegularFile(file)) return;
        try (InputStream in = Files.newInputStream(file)) {
            props.load(in);
        } catch (IOException e) {
            System.err.println("[Triweave] could not read config " + file + ": " + e);
        }
    }

    public synchronized void save() {
        try {
            Files.createDirectories(file.getParent());
            try (OutputStream out = Files.newOutputStream(file)) {
                props.store(out, "Triweave config");
            }
        } catch (IOException e) {
            System.err.println("[Triweave] could not write config " + file + ": " + e);
        }
    }

    public synchronized String getString(String key, String def) { return props.getProperty(key, def); }

    public synchronized int getInt(String key, int def) {
        try { return Integer.parseInt(props.getProperty(key, "").trim()); } catch (NumberFormatException e) { return def; }
    }

    public synchronized double getDouble(String key, double def) {
        try { return Double.parseDouble(props.getProperty(key, "").trim()); } catch (NumberFormatException e) { return def; }
    }

    public synchronized boolean getBoolean(String key, boolean def) {
        String v = props.getProperty(key);
        return v == null ? def : v.trim().equalsIgnoreCase("true");
    }

    public synchronized void set(String key, Object value) { props.setProperty(key, String.valueOf(value)); }

    public Path file() { return file; }
}
