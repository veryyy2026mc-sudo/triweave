package dev.triweave.api;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * ローダーをまたぐサービス登録。Fabric MOD・Quilt MOD・NeoForge MOD(互換層)・Triweave MOD が、
 * 互いのAPI実装を型とidで見つけられる。
 */
public final class Services {
    private record Key(Class<?> type, String id) {}

    private final Map<Key, Object> byKey = new ConcurrentHashMap<>();
    private final Map<Class<?>, List<Object>> byType = new ConcurrentHashMap<>();

    public Services() {}

    /** 同じ型・idを再登録すると置き換わる。 */
    public <T> void register(Class<T> type, String id, T impl) {
        Object old = byKey.put(new Key(type, id), impl);
        List<Object> list = byType.computeIfAbsent(type, k -> new CopyOnWriteArrayList<>());
        if (old != null) list.remove(old);
        list.add(impl);
    }

    public <T> Optional<T> get(Class<T> type, String id) {
        return Optional.ofNullable(type.cast(byKey.get(new Key(type, id))));
    }

    /** その型で登録された全実装(登録順)。 */
    public <T> List<T> getAll(Class<T> type) {
        List<T> out = new ArrayList<>();
        for (Object o : byType.getOrDefault(type, List.of())) out.add(type.cast(o));
        return out;
    }

    public <T> void unregister(Class<T> type, String id) {
        Object old = byKey.remove(new Key(type, id));
        if (old != null) byType.getOrDefault(type, new CopyOnWriteArrayList<>()).remove(old);
    }
}
