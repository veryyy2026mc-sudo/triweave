package dev.triweave.neoforge;

import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.stream.Stream;

import net.fabricmc.loader.api.ModContainer;
import net.minecraft.resources.ResourceKey;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.event.IModBusEvent;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;
import net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent;
import net.neoforged.fml.event.lifecycle.FMLDedicatedServerSetupEvent;
import net.neoforged.fml.event.lifecycle.FMLLoadCompleteEvent;
import net.neoforged.fml.loading.FMLEnvironment;
import net.neoforged.neoforge.registries.RegisterEvent;

/**
 * NeoForge MOD(@Mod クラス)を起動する。Fabricの main エントリポイントから呼ばれる。
 * 失敗してもゲームは止めず、ログに理由を出してそのMODだけ無効のままにする。
 */
public final class NeoForgeRuntime {
    private NeoForgeRuntime() {}

    /** Triweave が実際に発火するイベント(これ以外の @SubscribeEvent は警告対象)。 */
    private static final Set<String> FIRED = Set.of(
            "net.neoforged.neoforge.registries.RegisterEvent",
            "net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent",
            "net.neoforged.neoforge.event.tick.ServerTickEvent",
            "net.neoforged.neoforge.event.tick.ServerTickEvent$Pre",
            "net.neoforged.neoforge.event.tick.ServerTickEvent$Post",
            "net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent",
            "net.neoforged.fml.event.lifecycle.FMLClientSetupEvent",
            "net.neoforged.fml.event.lifecycle.FMLDedicatedServerSetupEvent",
            "net.neoforged.fml.event.lifecycle.FMLLoadCompleteEvent",
            "net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent",
            "net.neoforged.neoforge.event.server.ServerStartingEvent",
            "net.neoforged.neoforge.event.server.ServerStartedEvent",
            "net.neoforged.neoforge.event.server.ServerStoppingEvent",
            "net.neoforged.neoforge.event.server.ServerStoppedEvent",
            "net.neoforged.neoforge.event.entity.player.PlayerEvent$PlayerLoggedInEvent",
            "net.neoforged.neoforge.event.entity.player.PlayerEvent$PlayerLoggedOutEvent",
            "net.neoforged.neoforge.client.event.ClientTickEvent$Pre",
            "net.neoforged.neoforge.client.event.ClientTickEvent$Post",
            "net.neoforged.neoforge.event.level.BlockEvent$BreakEvent",
            "net.neoforged.neoforge.event.entity.living.LivingDeathEvent");

    static boolean isFiredEvent(Class<?> c) { return FIRED.contains(c.getName()); }

    record Loaded(String modId, SimpleEventBus bus) {}

    private static final List<Loaded> LOADED = new CopyOnWriteArrayList<>();
    private static boolean hooked;

    static List<Loaded> loaded() { return LOADED; }

    /** Fabricの main エントリポイントから呼ばれる。 */
    public static void loadMod(ModContainer fabricMod, String className) {
        String id = fabricMod.getMetadata().getId();
        try {
            doLoad(fabricMod, className);
        } catch (Throwable t) {
            System.err.println("[Triweave] NeoForge mod '" + id + "' failed to start and stays disabled: " + t);
            t.printStackTrace();
        }
    }

    private static void doLoad(ModContainer fabricMod, String className) throws Exception {
        ClassLoader cl = NeoForgeRuntime.class.getClassLoader();
        Class<?> cls = Class.forName(className, false, cl);
        Mod ann = cls.getAnnotation(Mod.class);
        String modId = ann != null ? ann.value() : fabricMod.getMetadata().getId();
        Dist dist = FMLEnvironment.getDist();
        if (ann != null && !contains(ann.dist(), dist)) {
            System.out.println("[Triweave] NeoForge mod class " + cls.getSimpleName() + " is not for " + dist + "; skipped");
            return;
        }

        installFabricHooksOnce();

        SimpleEventBus modBus = new SimpleEventBus("mod:" + modId);
        LOADED.add(new Loaded(modId, modBus));

        construct(cls, modBus, new NfModContainer(modId), dist);
        registerSubscribers(fabricMod, modId, dist, modBus);

        fireRegistries(modBus);
        modBus.post(new FMLCommonSetupEvent());
        modBus.post(dist.isClient() ? new FMLClientSetupEvent() : new FMLDedicatedServerSetupEvent());
        modBus.post(new FMLLoadCompleteEvent());
        System.out.println("[Triweave] NeoForge mod '" + modId + "' started (compat layer)");
    }

    private static boolean contains(Dist[] dists, Dist d) {
        for (Dist x : dists) if (x == d) return true;
        return false;
    }

    private static Object construct(Class<?> cls, IEventBus modBus, NfModContainer container, Dist dist) throws Exception {
        Constructor<?>[] ctors = cls.getConstructors();
        if (ctors.length == 0) throw new IllegalStateException(cls.getName() + " has no public constructor");
        Constructor<?> ctor = ctors[0];
        Class<?>[] types = ctor.getParameterTypes();
        Object[] args = new Object[types.length];
        for (int i = 0; i < types.length; i++) {
            if (types[i] == IEventBus.class) args[i] = modBus;
            else if (types[i] == net.neoforged.fml.ModContainer.class) args[i] = container;
            else if (types[i] == Dist.class) args[i] = dist;
            else throw new IllegalStateException("Unsupported @Mod constructor parameter: " + types[i].getName());
        }
        try {
            return ctor.newInstance(args);
        } catch (InvocationTargetException e) {
            throw e.getCause() instanceof Exception ex ? ex : e;
        }
    }

    // ------------------------------------------------------------------ @EventBusSubscriber

    private static void registerSubscribers(ModContainer fabricMod, String modId, Dist dist, SimpleEventBus modBus) {
        ClassLoader cl = NeoForgeRuntime.class.getClassLoader();
        byte[] marker = "net/neoforged/fml/common/EventBusSubscriber".getBytes(StandardCharsets.UTF_8);
        for (Path root : fabricMod.getRootPaths()) {
            List<Path> classes = new ArrayList<>();
            try (Stream<Path> s = Files.walk(root)) {
                s.filter(p -> p.toString().endsWith(".class")).forEach(classes::add);
            } catch (IOException e) {
                System.err.println("[Triweave] could not scan " + root + ": " + e);
                continue;
            }
            for (Path p : classes) {
                try {
                    if (indexOf(Files.readAllBytes(p), marker) < 0) continue;
                    String rel = root.relativize(p).toString().replace('\\', '/');
                    String name = rel.substring(0, rel.length() - ".class".length()).replace('/', '.');
                    registerSubscriber(Class.forName(name, false, cl), modId, dist, modBus);
                } catch (Throwable t) {
                    System.err.println("[Triweave] could not register subscriber " + p + ": " + t);
                }
            }
        }
    }

    private static void registerSubscriber(Class<?> c, String modId, Dist dist, SimpleEventBus modBus) {
        EventBusSubscriber ann;
        try {
            ann = c.getAnnotation(EventBusSubscriber.class);
            if (ann == null) return;
            if (!ann.modid().isEmpty() && !ann.modid().equals(modId)) return;
            if (!contains(ann.value(), dist)) return;
        } catch (RuntimeException e) {
            System.err.println("[Triweave] unreadable @EventBusSubscriber on " + c.getName() + ": " + e);
            return;
        }
        for (Method m : c.getDeclaredMethods()) {
            SubscribeEvent se = m.getAnnotation(SubscribeEvent.class);
            if (se == null || !Modifier.isStatic(m.getModifiers()) || m.getParameterCount() != 1) continue;
            Class<?> type = m.getParameterTypes()[0];
            m.setAccessible(true);
            SimpleEventBus.warnIfUnsupported(type, c);
            SimpleEventBus bus = IModBusEvent.class.isAssignableFrom(type) ? modBus : SimpleEventBus.GAME;
            bus.addHandler(type, se.priority(), e -> SimpleEventBus.invokeHandler(m, null, e));
        }
    }

    private static int indexOf(byte[] hay, byte[] needle) {
        outer:
        for (int i = 0; i + needle.length <= hay.length; i++) {
            for (int j = 0; j < needle.length; j++) if (hay[i + j] != needle[j]) continue outer;
            return i;
        }
        return -1;
    }

    // ------------------------------------------------------------------ レジストリ

    @SuppressWarnings({"rawtypes", "unchecked"})
    private static void fireRegistries(SimpleEventBus modBus) {
        List<Object> regs = new ArrayList<>(Mc.allRegistries());
        regs.sort((a, b) -> rank(a) - rank(b));            // ブロック → アイテム → その他
        for (Object reg : regs) {
            try {
                modBus.post(new RegisterEvent((ResourceKey) Mc.registryKeyOf(reg), reg));
            } catch (Throwable t) {
                System.err.println("[Triweave] registry event failed for " + Mc.registryPath(Mc.registryKeyOf(reg)) + ": " + t);
                t.printStackTrace();
            }
        }
    }

    private static int rank(Object registry) {
        String p = Mc.registryPath(Mc.registryKeyOf(registry));
        if (p.equals("block")) return 0;
        if (p.equals("item")) return 1;
        return 2;
    }

    // ------------------------------------------------------------------ Fabric へのつなぎ込み

    private static void installFabricHooksOnce() {
        if (hooked) return;
        hooked = true;
        try {
            FabricHooks.install();
        } catch (Throwable t) {
            System.err.println("[Triweave] Fabric API hooks unavailable (tick / creative-tab events disabled): " + t);
        }
        if (FMLEnvironment.getDist().isClient()) {
            try {
                FabricClientHooks.install();
            } catch (Throwable t) {
                System.err.println("[Triweave] client tick hook unavailable: " + t);
            }
        }
    }
}
