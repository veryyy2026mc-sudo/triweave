package dev.triweave.neoforge;

import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.function.Consumer;

import net.neoforged.bus.api.Event;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.bus.api.SubscribeEvent;

/** NeoForgeのイベントバスの簡易実装。リスナーの例外は握りつぶさずログに出し、他のリスナーは続行する。 */
public final class SimpleEventBus implements IEventBus {
    /** NeoForge.EVENT_BUS に相当するゲームバス。 */
    public static final SimpleEventBus GAME = new SimpleEventBus("game");

    private record Listener(EventPriority priority, Class<?> type, Consumer<Object> action) {}

    private final String name;
    private final List<Listener> listeners = new CopyOnWriteArrayList<>();

    public SimpleEventBus(String name) { this.name = name; }

    public String name() { return name; }

    @Override
    public void register(Object target) {
        boolean isClass = target instanceof Class<?>;
        Class<?> c = isClass ? (Class<?>) target : target.getClass();
        for (Class<?> k = c; k != null && k != Object.class; k = k.getSuperclass()) {
            for (Method m : k.getDeclaredMethods()) {
                SubscribeEvent ann = m.getAnnotation(SubscribeEvent.class);
                if (ann == null || m.getParameterCount() != 1) continue;
                boolean isStatic = Modifier.isStatic(m.getModifiers());
                if (isClass && !isStatic) continue;
                Class<?> eventType = m.getParameterTypes()[0];
                if (!Event.class.isAssignableFrom(eventType)) continue;
                m.setAccessible(true);
                Object receiver = isStatic ? null : target;
                warnIfUnsupported(eventType, c);
                addHandler(eventType, ann.priority(), e -> invokeHandler(m, receiver, e));
            }
        }
    }

    /** 型付きハンドラを追加する(@SubscribeEvent メソッドの登録に使う)。 */
    public void addHandler(Class<?> eventType, EventPriority priority, Consumer<Object> action) {
        listeners.add(new Listener(priority, eventType, action));
    }

    static void invokeHandler(Method m, Object receiver, Object event) {
        try {
            m.invoke(receiver, event);
        } catch (java.lang.reflect.InvocationTargetException ex) {
            throw new ListenerFailure(ex.getCause() != null ? ex.getCause() : ex);
        } catch (IllegalAccessException ex) {
            throw new ListenerFailure(ex);
        }
    }

    @Override
    public void unregister(Object target) {
        // 簡易実装: 未対応(MODが解除を必要とすることは稀)
    }

    @Override
    @SuppressWarnings("unchecked")
    public <T extends Event> void addListener(Consumer<T> listener) {
        listeners.add(new Listener(EventPriority.NORMAL, null, (Consumer<Object>) (Consumer<?>) listener));
    }

    @Override
    @SuppressWarnings("unchecked")
    public <T extends Event> void addListener(EventPriority priority, Consumer<T> listener) {
        listeners.add(new Listener(priority, null, (Consumer<Object>) (Consumer<?>) listener));
    }

    @Override
    @SuppressWarnings("unchecked")
    public <T extends Event> void addListener(Class<T> eventType, Consumer<T> listener) {
        listeners.add(new Listener(EventPriority.NORMAL, eventType, (Consumer<Object>) (Consumer<?>) listener));
    }

    @Override
    public <T extends Event> T post(T event) {
        List<Listener> sorted = new ArrayList<>(listeners);
        sorted.sort(Comparator.comparingInt(l -> l.priority().ordinal()));
        for (Listener l : sorted) {
            if (l.type() != null && !l.type().isInstance(event)) continue;
            try {
                l.action().accept(event);
            } catch (ClassCastException e) {
                // 型を明示しないラムダは、型が合わないと自身のキャストで失敗する。それは「対象外」として無視する。
                if (isLambdaBridgeMismatch(e)) continue;
                report(event, e);
            } catch (ListenerFailure f) {
                report(event, f.getCause());
            } catch (Throwable t) {
                report(event, t);
            }
        }
        return event;
    }

    private static boolean isLambdaBridgeMismatch(ClassCastException e) {
        StackTraceElement[] st = e.getStackTrace();
        if (st.length == 0) return true;
        String top = st[0].getClassName();
        return top.equals(SimpleEventBus.class.getName()) || top.contains("$$Lambda");
    }

    private void report(Event event, Throwable t) {
        System.err.println("[Triweave] NeoForge listener failed on bus '" + name + "' for "
                + event.getClass().getSimpleName() + ": " + t);
        t.printStackTrace();
    }

    private static final class ListenerFailure extends RuntimeException {
        ListenerFailure(Throwable cause) { super(cause); }
    }

    // ------------------------------------------------------------------ 未対応イベントの通知

    private static final Set<String> WARNED = new HashSet<>();

    static void warnIfUnsupported(Class<?> eventType, Class<?> owner) {
        if (!eventType.getName().startsWith("net.neoforged.")) return;
        if (NeoForgeRuntime.isFiredEvent(eventType)) return;
        if (WARNED.add(eventType.getName())) {
            System.out.println("[Triweave] WARN: " + owner.getSimpleName() + " listens to "
                    + eventType.getSimpleName() + ", which Triweave never fires (that handler will not run)");
        }
    }
}
