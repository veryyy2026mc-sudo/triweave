package dev.triweave.neoforge;

import net.fabricmc.fabric.api.creativetab.v1.CreativeModeTabEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.entity.player.Player;
import net.neoforged.neoforge.event.entity.living.LivingDeathEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.level.BlockEvent;
import net.neoforged.neoforge.event.server.ServerStartedEvent;
import net.neoforged.neoforge.event.server.ServerStartingEvent;
import net.neoforged.neoforge.event.server.ServerStoppedEvent;
import net.neoforged.neoforge.event.server.ServerStoppingEvent;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;

/** Fabric API のイベントを、NeoForge のイベントとして流し直す。 */
final class FabricHooks {
    private FabricHooks() {}

    static void install() {
        ServerTickEvents.START_SERVER_TICK.register(server -> SimpleEventBus.GAME.post(new ServerTickEvent.Pre(server)));
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            SimpleEventBus.GAME.post(new ServerTickEvent.Post(server));
            try {
                dev.triweave.bukkit.BukkitRuntime.onServerTick();
            } catch (Throwable t) {
                System.err.println("[Triweave] Bukkit scheduler tick failed: " + t);
            }
        });
        CreativeModeTabEvents.MODIFY_OUTPUT_ALL.register(FabricHooks::onTab);

        ServerLifecycleEvents.SERVER_STARTING.register(s -> SimpleEventBus.GAME.post(new ServerStartingEvent(s)));
        ServerLifecycleEvents.SERVER_STARTED.register(s -> {
            SimpleEventBus.GAME.post(new ServerStartedEvent(s));
            dev.triweave.core.TriweaveCore.onServerStarted(s);
        });
        ServerLifecycleEvents.SERVER_STOPPING.register(s -> {
            SimpleEventBus.GAME.post(new ServerStoppingEvent(s));
            dev.triweave.core.TriweaveCore.onServerStopping(s);
        });
        ServerLifecycleEvents.SERVER_STOPPED.register(s -> SimpleEventBus.GAME.post(new ServerStoppedEvent(s)));
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> postPlayer(handler, true));
        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> postPlayer(handler, false));

        PlayerBlockBreakEvents.BEFORE.register((level, player, pos, state, blockEntity) -> {
            BlockEvent.BreakEvent e = new BlockEvent.BreakEvent(level, pos, state, player);
            SimpleEventBus.GAME.post(e);
            return !e.isCanceled();
        });
        ServerLivingEntityEvents.ALLOW_DEATH.register((entity, source, amount) -> {
            LivingDeathEvent e = new LivingDeathEvent(entity, source);
            SimpleEventBus.GAME.post(e);
            return !e.isCanceled();
        });
    }

    private static void postPlayer(Object handler, boolean login) {
        try {
            Player player = (Player) Mc.invoke(handler, "getPlayer");
            SimpleEventBus.GAME.post(login ? new PlayerEvent.PlayerLoggedInEvent(player)
                                           : new PlayerEvent.PlayerLoggedOutEvent(player));
        } catch (Throwable t) {
            System.err.println("[Triweave] player event failed: " + t);
        }
    }

    @SuppressWarnings("rawtypes")
    private static void onTab(Object tab, Object output) {
        try {
            Object registry = Mc.staticField("net.minecraft.core.registries.BuiltInRegistries", "CREATIVE_MODE_TAB");
            Object key = Mc.keyOf(registry, tab);
            if (key == null) return;
            for (NeoForgeRuntime.Loaded l : NeoForgeRuntime.loaded()) {
                try {
                    l.bus().post(new BuildCreativeModeTabContentsEvent((ResourceKey) key, output));
                } catch (Throwable t) {
                    System.err.println("[Triweave] creative tab event failed for " + l.modId() + ": " + t);
                }
            }
        } catch (Throwable t) {
            System.err.println("[Triweave] creative tab hook failed: " + t);
        }
    }
}
