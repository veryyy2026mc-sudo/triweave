package dev.triweave.neoforge;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.loader.api.LanguageAdapter;
import net.fabricmc.loader.api.LanguageAdapterException;
import net.fabricmc.loader.api.ModContainer;

/** 翻訳済みNeoForge MODの @Mod クラスを、Fabricの main エントリポイントとして起動する。 */
public final class NeoForgeLanguageAdapter implements LanguageAdapter {
    @Override
    public <T> T create(ModContainer mod, String value, Class<T> type) throws LanguageAdapterException {
        if (type == ModInitializer.class) {
            ModInitializer init = () -> NeoForgeRuntime.loadMod(mod, value);
            return type.cast(init);
        }
        throw new LanguageAdapterException("Triweave NeoForge adapter only supports 'main' entrypoints, got "
                + type.getName());
    }
}
