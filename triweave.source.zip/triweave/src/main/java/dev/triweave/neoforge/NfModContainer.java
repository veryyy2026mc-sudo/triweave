package dev.triweave.neoforge;

import net.neoforged.fml.ModContainer;

public final class NfModContainer implements ModContainer {
    private final String modId;

    public NfModContainer(String modId) { this.modId = modId; }

    @Override
    public String getModId() { return modId; }
}
