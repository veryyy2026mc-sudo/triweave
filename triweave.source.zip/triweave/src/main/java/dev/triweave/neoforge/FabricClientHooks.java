package dev.triweave.neoforge;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.neoforged.neoforge.client.event.ClientTickEvent;

/** クライアント専用のフック(専用サーバーでは読み込まれない)。 */
final class FabricClientHooks {
    private FabricClientHooks() {}

    static void install() {
        ClientTickEvents.START_CLIENT_TICK.register(c -> SimpleEventBus.GAME.post(new ClientTickEvent.Pre()));
        ClientTickEvents.END_CLIENT_TICK.register(c -> SimpleEventBus.GAME.post(new ClientTickEvent.Post()));
    }
}
