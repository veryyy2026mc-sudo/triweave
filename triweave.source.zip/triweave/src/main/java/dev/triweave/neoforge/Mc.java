package dev.triweave.neoforge;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;

/**
 * Minecraft本体へのリフレクション窓口。
 * 26.3の実物にコンパイル時リンクしないことで、メソッド記述子のずれによるクラッシュを避ける
 * (名前と引数で探すので、戻り値の型が違っても動く)。
 */
public final class Mc {
    private Mc() {}

    private static ClassLoader loader() { return Mc.class.getClassLoader(); }

    public static Class<?> cls(String name) {
        try {
            return Class.forName(name, true, loader());
        } catch (ClassNotFoundException e) {
            throw new IllegalStateException("Minecraft class not found: " + name, e);
        }
    }

    /** 名前と引数の数・型が合うメソッドを探して呼ぶ(インスタンスまたはstatic)。 */
    public static Object invoke(Object target, String name, Object... args) {
        return call(target.getClass(), target, name, args);
    }

    public static Object invokeStatic(String className, String name, Object... args) {
        return call(cls(className), null, name, args);
    }

    private static Object call(Class<?> c, Object target, String name, Object[] args) {
        Method best = null;
        for (Method m : allMethods(c)) {
            if (!m.getName().equals(name) || m.getParameterCount() != args.length) continue;
            if (target == null && !Modifier.isStatic(m.getModifiers())) continue;
            if (matches(m.getParameterTypes(), args)) { best = m; break; }
        }
        if (best == null) {
            throw new IllegalStateException("No method " + c.getName() + "." + name + "/" + args.length);
        }
        try {
            best.setAccessible(true);
            return best.invoke(target, args);
        } catch (InvocationTargetException e) {
            Throwable t = e.getCause() != null ? e.getCause() : e;
            if (t instanceof RuntimeException re) throw re;
            if (t instanceof Error er) throw er;
            throw new IllegalStateException(t);
        } catch (IllegalAccessException e) {
            throw new IllegalStateException(e);
        }
    }

    private static List<Method> allMethods(Class<?> c) {
        List<Method> out = new ArrayList<>();
        for (Class<?> k = c; k != null; k = k.getSuperclass()) {
            for (Method m : k.getDeclaredMethods()) out.add(m);
            for (Class<?> i : k.getInterfaces()) for (Method m : i.getMethods()) out.add(m);
        }
        return out;
    }

    private static boolean matches(Class<?>[] params, Object[] args) {
        for (int i = 0; i < params.length; i++) {
            if (args[i] == null) { if (params[i].isPrimitive()) return false; continue; }
            Class<?> p = params[i].isPrimitive() ? box(params[i]) : params[i];
            if (!p.isInstance(args[i])) return false;
        }
        return true;
    }

    private static Class<?> box(Class<?> p) {
        if (p == int.class) return Integer.class;
        if (p == boolean.class) return Boolean.class;
        if (p == float.class) return Float.class;
        if (p == double.class) return Double.class;
        if (p == long.class) return Long.class;
        if (p == short.class) return Short.class;
        if (p == byte.class) return Byte.class;
        if (p == char.class) return Character.class;
        return p;
    }

    public static Object newInstance(String className, Object... args) {
        Class<?> c = cls(className);
        for (Constructor<?> k : c.getDeclaredConstructors()) {
            if (k.getParameterCount() == args.length && matches(k.getParameterTypes(), args)) {
                try {
                    k.setAccessible(true);
                    return k.newInstance(args);
                } catch (InvocationTargetException e) {
                    Throwable t = e.getCause() != null ? e.getCause() : e;
                    if (t instanceof RuntimeException re) throw re;
                    if (t instanceof Error er) throw er;
                    throw new IllegalStateException(t);
                } catch (ReflectiveOperationException e) {
                    throw new IllegalStateException(e);
                }
            }
        }
        throw new IllegalStateException("No constructor " + className + "/" + args.length);
    }

    public static Object staticField(String className, String field) {
        try {
            Field f = cls(className).getField(field);
            return f.get(null);
        } catch (ReflectiveOperationException e) {
            throw new IllegalStateException("No static field " + className + "." + field, e);
        }
    }

    // ------------------------------------------------------------------ Minecraft固有の操作

    public static Identifier identifier(String namespace, String path) {
        return (Identifier) invokeStatic("net.minecraft.resources.Identifier", "fromNamespaceAndPath", namespace, path);
    }

    /** net.minecraft.core.registries.Registries.<NAME> (レジストリのキー) */
    @SuppressWarnings({"rawtypes"})
    public static ResourceKey registryKey(String registriesFieldName) {
        return (ResourceKey) staticField("net.minecraft.core.registries.Registries", registriesFieldName);
    }

    @SuppressWarnings({"rawtypes"})
    public static ResourceKey resourceKey(Object registryKey, Object id) {
        return (ResourceKey) invokeStatic("net.minecraft.resources.ResourceKey", "create", registryKey, id);
    }

    /** props.setId(ResourceKey) を呼んで、Properties を返す(26.xでは必須)。 */
    public static Object withId(Object props, String registriesFieldName, Object id) {
        Object key = resourceKey(registryKey(registriesFieldName), id);
        Object r = invoke(props, "setId", key);
        return r != null ? r : props;
    }

    public static Object register(Object registry, Object id, Object value) {
        return invokeStatic("net.minecraft.core.Registry", "register", registry, id, value);
    }

    /** BuiltInRegistries にある全レジストリ。 */
    public static List<Object> allRegistries() {
        List<Object> out = new ArrayList<>();
        Class<?> reg = cls("net.minecraft.core.Registry");
        for (Field f : cls("net.minecraft.core.registries.BuiltInRegistries").getFields()) {
            if (!Modifier.isStatic(f.getModifiers()) || !reg.isAssignableFrom(f.getType())) continue;
            try {
                Object r = f.get(null);
                if (r != null) out.add(r);
            } catch (ReflectiveOperationException | LinkageError ignored) {
                // 読めないレジストリは飛ばす
            }
        }
        return out;
    }

    public static Object registryKeyOf(Object registry) {
        return invoke(registry, "key");
    }

    /** レジストリキーのパス部分(例: "block", "item")。 */
    public static String registryPath(Object registryKey) {
        for (String m : new String[] {"identifier", "location"}) {
            try {
                Object id = invoke(registryKey, m);
                return String.valueOf(invoke(id, "getPath"));
            } catch (RuntimeException ignored) {
                // 次の候補
            }
        }
        return String.valueOf(registryKey);
    }

    /** レジストリから値のキーを引く。見つからなければ null。 */
    public static Object keyOf(Object registry, Object value) {
        try {
            Object r = invoke(registry, "getResourceKey", value);
            if (r instanceof Optional<?> o) return o.orElse(null);
            return r;
        } catch (RuntimeException e) {
            return null;
        }
    }
}
