package dev.triweave.quilt;

import java.nio.file.Path;

import org.quiltmc.loader.api.ModContainer;
import org.quiltmc.loader.api.ModMetadata;
import org.quiltmc.loader.api.Version;

/** FabricのModContainerをQuilt形式のModContainerに見せる薄いラッパー。 */
public final class TriweaveModContainer implements ModContainer {
    private final net.fabricmc.loader.api.ModContainer delegate;
    private final ModMetadata metadata;

    public TriweaveModContainer(net.fabricmc.loader.api.ModContainer delegate) {
        this.delegate = delegate;
        net.fabricmc.loader.api.metadata.ModMetadata fm = delegate.getMetadata();
        this.metadata = new ModMetadata() {
            @Override public String id() { return fm.getId(); }
            @Override public String name() { return fm.getName(); }
            @Override public String description() { return fm.getDescription(); }
            @Override public Version version() {
                String raw = fm.getVersion().getFriendlyString();
                return () -> raw;
            }
        };
    }

    @Override public ModMetadata metadata() { return metadata; }

    @Override public Path rootPath() { return delegate.getRootPaths().get(0); }
}
