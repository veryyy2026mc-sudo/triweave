package dev.triweave.quilt;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.Map;

import net.fabricmc.loader.api.LanguageAdapter;
import net.fabricmc.loader.api.LanguageAdapterException;
import net.fabricmc.loader.api.ModContainer;

/**
 * Quilt形式のエントリポイントをFabricのエントリポイントとして呼び出すアダプタ。
 *
 * <ul>
 *   <li>クラスがFabric側の型(ModInitializer等)を実装 → そのまま生成</li>
 *   <li>クラスがQuilt(QSL)側の型を実装 → Fabricの型のProxyで包み、
 *       {@code onInitialize(ModContainer)} などをQuilt形式で呼ぶ</li>
 * </ul>
 */
public final class QuiltLanguageAdapter implements LanguageAdapter {

    /** Fabric側エントリポイント型 → Quilt側で呼ぶメソッド名 */
    private static final Map<String, String> BRIDGES = Map.of(
            "net.fabricmc.api.ModInitializer", "onInitialize",
            "net.fabricmc.api.ClientModInitializer", "onInitializeClient",
            "net.fabricmc.api.DedicatedServerModInitializer", "onInitializeServer",
            "net.fabricmc.loader.api.entrypoint.PreLaunchEntrypoint", "onPreLaunch");

    @Override
    public <T> T create(ModContainer mod, String value, Class<T> type) throws LanguageAdapterException {
        if (value.contains("::")) {
            throw new LanguageAdapterException(
                    "Triweave: method/field entrypoints ('::') are not supported yet: " + value);
        }

        final Class<?> cls;
        try {
            cls = Class.forName(value, true, QuiltLanguageAdapter.class.getClassLoader());
        } catch (ClassNotFoundException | LinkageError e) {
            throw new LanguageAdapterException(e);
        }

        final Object instance;
        try {
            Constructor<?> ctor = cls.getDeclaredConstructor();
            ctor.setAccessible(true);
            instance = ctor.newInstance();
        } catch (InvocationTargetException e) {
            throw new LanguageAdapterException(e.getCause() != null ? e.getCause() : e);
        } catch (ReflectiveOperationException | LinkageError e) {
            throw new LanguageAdapterException(e);
        }

        if (type.isInstance(instance)) {
            return type.cast(instance);
        }

        String methodName = BRIDGES.get(type.getName());
        if (methodName == null) {
            throw new LanguageAdapterException("Triweave: class " + value + " does not implement "
                    + type.getName() + " and no Quilt bridge exists for that type");
        }

        final TriweaveModContainer container = new TriweaveModContainer(mod);
        Method target = null;
        for (Method m : cls.getMethods()) {
            if (m.getName().equals(methodName) && m.getParameterCount() == 1
                    && m.getParameterTypes()[0].isInstance(container)) {
                target = m;
                break;
            }
        }
        if (target == null) {
            throw new LanguageAdapterException("Triweave: " + value + " has no usable " + methodName
                    + "(ModContainer) method");
        }
        try {
            target.setAccessible(true);
        } catch (RuntimeException ignored) {
            // public method of a public class: fine without it
        }

        final Method finalTarget = target;
        InvocationHandler handler = (proxy, method, args) -> {
            if (method.getDeclaringClass() == Object.class) {
                return switch (method.getName()) {
                    case "toString" -> "TriweaveQuiltBridge(" + value + ")";
                    case "hashCode" -> System.identityHashCode(proxy);
                    case "equals" -> proxy == args[0];
                    default -> null;
                };
            }
            try {
                return finalTarget.invoke(instance, container);
            } catch (InvocationTargetException e) {
                throw e.getCause() != null ? e.getCause() : e;
            }
        };

        Object proxy = Proxy.newProxyInstance(QuiltLanguageAdapter.class.getClassLoader(),
                new Class<?>[] {type}, handler);
        return type.cast(proxy);
    }
}
