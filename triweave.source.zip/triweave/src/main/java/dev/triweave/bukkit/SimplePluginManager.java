package dev.triweave.bukkit;

import java.lang.reflect.Method;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;

import org.bukkit.event.Event;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.HandlerList;
import org.bukkit.event.Listener;
import org.bukkit.plugin.EventExecutor;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.PluginManager;

/** {@link PluginManager} の実装。イベントはクラスごとに登録済みリスナーへ素朴に配送する。 */
final class SimplePluginManager implements PluginManager {
    private final Map<Class<? extends Event>, HandlerList> handlers = new ConcurrentHashMap<>();
    private final List<BukkitPlugin> plugins = new CopyOnWriteArrayList<>();

    void add(BukkitPlugin p) { plugins.add(p); }

    @Override
    public void registerEvents(Listener listener, Plugin plugin) {
        for (Method m : listener.getClass().getMethods()) {
            EventHandler ann = m.getAnnotation(EventHandler.class);
            if (ann == null || m.getParameterCount() != 1 || !Event.class.isAssignableFrom(m.getParameterTypes()[0])) continue;
            @SuppressWarnings("unchecked")
            Class<? extends Event> type = (Class<? extends Event>) m.getParameterTypes()[0];
            m.setAccessible(true);
            registerEvent(type, listener, ann.priority(), (l, e) -> m.invoke(l, e), plugin);
        }
    }

    @Override
    public void registerEvent(Class<? extends Event> event, Listener listener, EventPriority priority,
            EventExecutor executor, Plugin plugin) {
        HandlerList list = handlers.computeIfAbsent(event, k -> new HandlerList());
        list.register(new HandlerList.RegisteredListener(listener, executor::execute, priority));
    }

    @Override
    public void callEvent(Event event) {
        HandlerList list = handlers.get(event.getClass());
        if (list == null) return;
        for (HandlerList.RegisteredListener rl : List.copyOf(list.getRegisteredListeners())) {
            try {
                rl.executor().execute(rl.listener(), event);
            } catch (Throwable t) {
                System.err.println("[Triweave] Bukkit event handler failed: " + t);
            }
        }
    }

    @Override
    public Plugin getPlugin(String name) {
        for (BukkitPlugin p : plugins) if (p.getName().equalsIgnoreCase(name)) return p;
        return null;
    }

    @Override
    public Plugin[] getPlugins() { return plugins.toArray(new Plugin[0]); }

    @Override
    public boolean isPluginEnabled(String name) {
        Plugin p = getPlugin(name);
        return p != null && p.isEnabled();
    }
}
