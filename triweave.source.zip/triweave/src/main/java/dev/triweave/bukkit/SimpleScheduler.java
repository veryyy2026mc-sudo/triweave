package dev.triweave.bukkit;

import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitScheduler;
import org.bukkit.scheduler.BukkitTask;

/** {@link BukkitScheduler} の実装。同期タスクはサーバーのtickに乗せ、非同期タスクは別スレッドで動かす。 */
final class SimpleScheduler implements BukkitScheduler {
    private record Sync(int id, Plugin plugin, Runnable task, long dueAtTick, long periodTicks, boolean[] cancelled) {}

    private final List<Sync> syncTasks = new CopyOnWriteArrayList<>();
    private final ConcurrentHashMap<Integer, java.util.concurrent.ScheduledFuture<?>> asyncTasks = new ConcurrentHashMap<>();
    private final AtomicInteger nextId = new AtomicInteger(1);
    private final ScheduledExecutorService async = Executors.newScheduledThreadPool(2,
            r -> { Thread t = new Thread(r, "Triweave-Bukkit-Async"); t.setDaemon(true); return t; });
    private volatile long tick;

    /** サーバーの毎tickに呼ばれる(SimpleEventBus経由)。 */
    void onServerTick() {
        tick++;
        for (Sync s : syncTasks) {
            if (s.cancelled()[0]) { syncTasks.remove(s); continue; }
            if (tick < s.dueAtTick()) continue;
            try {
                s.task().run();
            } catch (Throwable t) {
                System.err.println("[Triweave] Bukkit task failed (" + s.plugin().getName() + "): " + t);
            }
            if (s.periodTicks() > 0) {
                syncTasks.remove(s);
                syncTasks.add(new Sync(s.id(), s.plugin(), s.task(), tick + s.periodTicks(), s.periodTicks(), s.cancelled()));
            } else {
                syncTasks.remove(s);
            }
        }
    }

    @Override
    public BukkitTask runTask(Plugin plugin, Runnable task) { return runTaskLater(plugin, task, 0); }

    @Override
    public BukkitTask runTaskLater(Plugin plugin, Runnable task, long delayTicks) {
        return add(plugin, task, Math.max(0, delayTicks), 0);
    }

    @Override
    public BukkitTask runTaskTimer(Plugin plugin, Runnable task, long delayTicks, long periodTicks) {
        return add(plugin, task, Math.max(0, delayTicks), Math.max(1, periodTicks));
    }

    private BukkitTask add(Plugin plugin, Runnable task, long delayTicks, long periodTicks) {
        int id = nextId.getAndIncrement();
        boolean[] cancelled = {false};
        syncTasks.add(new Sync(id, plugin, task, tick + delayTicks, periodTicks, cancelled));
        return task(id, () -> cancelled[0] = true);
    }

    @Override
    public BukkitTask runTaskAsynchronously(Plugin plugin, Runnable task) {
        int id = nextId.getAndIncrement();
        var future = async.schedule(() -> {
            try {
                task.run();
            } catch (Throwable t) {
                System.err.println("[Triweave] Bukkit async task failed (" + plugin.getName() + "): " + t);
            }
        }, 0, TimeUnit.MILLISECONDS);
        asyncTasks.put(id, future);
        return task(id, () -> { var f = asyncTasks.remove(id); if (f != null) f.cancel(false); });
    }

    @Override
    public void cancelTasks(Plugin plugin) {
        syncTasks.removeIf(s -> s.plugin() == plugin);
    }

    private BukkitTask task(int id, Runnable onCancel) {
        return new BukkitTask() {
            @Override public int getTaskId() { return id; }
            @Override public void cancel() { onCancel.run(); }
        };
    }
}
