package dev.triweave.bukkit;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.loader.api.FabricLoader;
import net.fabricmc.loader.api.LanguageAdapter;
import net.fabricmc.loader.api.LanguageAdapterException;
import net.fabricmc.loader.api.ModContainer;

/**
 * Triweaveが翻訳したBukkitプラグインjarのエントリポイント用アダプタ。
 * {@code value} はBukkit側のメインクラス名(plugin.ymlのmain)。
 */
public final class BukkitLanguageAdapter implements LanguageAdapter {
    @Override
    public <T> T create(ModContainer mod, String value, Class<T> type) throws LanguageAdapterException {
        if (type != ModInitializer.class) {
            throw new LanguageAdapterException("Triweave Bukkit adapter only supports 'main' entrypoints, got "
                    + type.getName());
        }
        String yml = readPluginYml(mod);
        String name = mod.getMetadata().getName();
        Path dataFolder = FabricLoader.getInstance().getGameDir().resolve("plugins").resolve(name);
        Path jarFile = mod.getRootPaths().isEmpty() ? dataFolder : mod.getRootPaths().get(0);
        ClassLoader cl = BukkitLanguageAdapter.class.getClassLoader();
        ModInitializer init = () -> BukkitRuntime.load(cl, yml, value, dataFolder, jarFile);
        return type.cast(init);
    }

    private static String readPluginYml(ModContainer mod) throws LanguageAdapterException {
        for (Path root : mod.getRootPaths()) {
            Path y = root.resolve("plugin.yml");
            if (java.nio.file.Files.isRegularFile(y)) {
                try (InputStream in = java.nio.file.Files.newInputStream(y)) {
                    return new String(in.readAllBytes(), StandardCharsets.UTF_8);
                } catch (IOException e) {
                    throw new LanguageAdapterException(e);
                }
            }
        }
        throw new LanguageAdapterException("plugin.yml not found in " + mod.getMetadata().getId());
    }
}
