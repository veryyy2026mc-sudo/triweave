package dev.triweave.bukkit;

import java.io.File;
import java.io.InputStream;
import java.lang.reflect.Constructor;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.bukkit.Bukkit;
import org.bukkit.plugin.PluginDescriptionFile;
import org.bukkit.plugin.java.JavaPlugin;

/**
 * Bukkit互換層の入口。Fabricの main エントリポイントから、プラグインごとに1回呼ばれる。
 * 失敗してもサーバーは止めず、そのプラグインだけ無効のままにする。
 *
 * <p>対応範囲(README参照): コンフィグ・ロガー・ライフサイクル(onLoad/onEnable/onDisable)・
 * 簡単なイベント(registerEvents)・コマンド(getCommand().setExecutor)・同期/非同期タスク。
 * 実際のプレイヤー・ワールド・ブロックとは連動しない。
 */
public final class BukkitRuntime {
    private static final SimpleServer SERVER = new SimpleServer();
    private static final Pattern NAME = Pattern.compile("(?m)^name:\\s*['\"]?([^'\"\\s]+)['\"]?\\s*$");
    private static final Pattern VERSION = Pattern.compile("(?m)^version:\\s*['\"]?([^'\"\\s]+)['\"]?\\s*$");
    private static final Pattern MAIN = Pattern.compile("(?m)^main:\\s*['\"]?([^'\"\\s]+)['\"]?\\s*$");

    private BukkitRuntime() {}

    static { Bukkit.setServer(SERVER); }

    /** @param classLoader プラグインjarのクラスをロードできるクラスローダ(Fabricが使う物と同じでよい) */
    public static void load(ClassLoader classLoader, String pluginYml, String mainClassName, Path dataFolder,
            Path jarFile) {
        String name = find(NAME, pluginYml, mainClassName);
        try {
            doLoad(classLoader, pluginYml, mainClassName, dataFolder, jarFile);
        } catch (Throwable t) {
            System.err.println("[Triweave] Bukkit plugin '" + name + "' failed to start and stays disabled: " + t);
            t.printStackTrace();
        }
    }

    private static void doLoad(ClassLoader cl, String yml, String mainClassName, Path dataFolder, Path jarFile)
            throws Exception {
        String name = find(NAME, yml, mainClassName);
        String version = find(VERSION, yml, "0.0.0");
        String description = extractDescription(yml);

        Class<?> cls = Class.forName(mainClassName, false, cl);
        if (!JavaPlugin.class.isAssignableFrom(cls)) {
            throw new IllegalStateException(mainClassName + " does not extend org.bukkit.plugin.java.JavaPlugin");
        }
        Constructor<?> ctor = cls.getDeclaredConstructor();
        ctor.setAccessible(true);
        JavaPlugin plugin = (JavaPlugin) ctor.newInstance();

        Files.createDirectories(dataFolder);
        PluginDescriptionFile desc = new PluginDescriptionFile(name, version, mainClassName, description);
        plugin.init(SERVER, desc, dataFolder.toFile(), jarFile.toFile());
        SERVER.pluginManager().add(wrap(plugin));

        plugin.onLoad();
        setEnabled(plugin, true);
        plugin.onEnable();
        System.out.println("[Triweave] Bukkit plugin '" + name + "' started (compat layer, scope limited; see README)");
    }

    private static void setEnabled(JavaPlugin plugin, boolean enabled) {
        try {
            var m = JavaPlugin.class.getDeclaredMethod("setEnabled", boolean.class);
            m.setAccessible(true);
            m.invoke(plugin, enabled);
        } catch (ReflectiveOperationException e) {
            throw new IllegalStateException(e);
        }
    }

    private static BukkitPlugin wrap(JavaPlugin plugin) {
        return new BukkitPlugin() {
            @Override public String getName() { return plugin.getName(); }
            @Override public org.bukkit.plugin.PluginDescriptionFile getDescription() { return plugin.getDescription(); }
            @Override public org.bukkit.Server getServer() { return plugin.getServer(); }
            @Override public java.util.logging.Logger getLogger() { return plugin.getLogger(); }
            @Override public File getDataFolder() { return plugin.getDataFolder(); }
            @Override public org.bukkit.configuration.file.FileConfiguration getConfig() { return plugin.getConfig(); }
            @Override public void saveConfig() { plugin.saveConfig(); }
            @Override public void saveDefaultConfig() { plugin.saveDefaultConfig(); }
            @Override public void reloadConfig() { plugin.reloadConfig(); }
            @Override public boolean isEnabled() { return plugin.isEnabled(); }
            @Override public void onLoad() { plugin.onLoad(); }
            @Override public void onEnable() { plugin.onEnable(); }
            @Override public void onDisable() { plugin.onDisable(); }
        };
    }

    /** サーバーの毎tickに呼ばれる(FabricHooks経由)。 */
    public static void onServerTick() { SERVER.schedulerImpl().onServerTick(); }

    private static String find(Pattern p, String text, String def) {
        Matcher m = p.matcher(text);
        return m.find() ? m.group(1) : def;
    }

    private static String extractDescription(String yml) {
        Matcher m = Pattern.compile("(?m)^description:\\s*['\"]?(.*?)['\"]?\\s*$").matcher(yml);
        return m.find() ? m.group(1) : "";
    }
}
