package dev.triweave.bukkit;

import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.logging.Logger;

import org.bukkit.Player;
import org.bukkit.Server;
import org.bukkit.plugin.PluginManager;
import org.bukkit.scheduler.BukkitScheduler;

/**
 * {@link Server} の実装。
 * 注意(README参照): getOnlinePlayers() は常に空。実際のMinecraftプレイヤーとは紐付いていない。
 */
final class SimpleServer implements Server {
    private final SimplePluginManager pm = new SimplePluginManager();
    private final SimpleScheduler scheduler = new SimpleScheduler();
    private final Logger logger = Logger.getLogger("Triweave-Bukkit");

    SimplePluginManager pluginManager() { return pm; }

    SimpleScheduler schedulerImpl() { return scheduler; }

    @Override public PluginManager getPluginManager() { return pm; }

    @Override public BukkitScheduler getScheduler() { return scheduler; }

    @Override public Logger getLogger() { return logger; }

    @Override public Collection<? extends Player> getOnlinePlayers() { return Collections.emptyList(); }

    @Override public String getName() { return "Triweave"; }

    @Override public String getVersion() { return "Triweave " + dev.triweave.api.Triweave.version(); }

    @Override public String getBukkitVersion() { return "triweave-bukkit-compat-0.1"; }

    @Override
    public void broadcastMessage(String message) {
        logger.info(message);                    // 実プレイヤーへの送信は未対応(README参照)
    }
}
