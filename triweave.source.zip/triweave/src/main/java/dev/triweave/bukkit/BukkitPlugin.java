package dev.triweave.bukkit;

/** JavaPlugin側から見える最小の橋渡しインターフェース(PluginManager.getPlugin等で使う)。 */
interface BukkitPlugin extends org.bukkit.plugin.Plugin {}
