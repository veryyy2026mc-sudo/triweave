package dev.triweave;

import net.fabricmc.api.ClientModInitializer;

/** クライアント側の入口。/mod コマンドを登録する(失敗してもゲームは止めない)。 */
public final class TriweaveClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        try {
            dev.triweave.command.ClientRegistration.register();
        } catch (Throwable t) {
            System.err.println("[Triweave] /mod command could not be registered: " + t);
        }
    }
}
