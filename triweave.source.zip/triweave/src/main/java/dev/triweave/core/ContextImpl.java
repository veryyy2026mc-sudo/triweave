package dev.triweave.core;

import java.nio.file.Path;

import dev.triweave.api.ModConfig;
import dev.triweave.api.Services;
import dev.triweave.api.TriweaveContext;
import net.fabricmc.loader.api.FabricLoader;

final class ContextImpl implements TriweaveContext {
    private final String modId;

    ContextImpl(String modId) { this.modId = modId; }

    @Override public String modId() { return modId; }

    @Override public Path configDir() { return FabricLoader.getInstance().getConfigDir(); }

    @Override public ModConfig config() { return TriweaveCore.config(modId); }

    @Override public Services services() { return TriweaveCore.services(); }

    @Override public void onReload(Runnable listener) { TriweaveCore.registerReload(modId, listener); }
}
