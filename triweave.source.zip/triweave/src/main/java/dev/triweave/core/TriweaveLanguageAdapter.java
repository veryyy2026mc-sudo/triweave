package dev.triweave.core;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

import dev.triweave.api.TriweaveClientInitializer;
import dev.triweave.api.TriweaveContext;
import dev.triweave.api.TriweaveInitializer;
import dev.triweave.api.TriweaveServerInitializer;
import dev.triweave.quilt.QuiltLanguageAdapter;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.DedicatedServerModInitializer;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.loader.api.LanguageAdapter;
import net.fabricmc.loader.api.LanguageAdapterException;
import net.fabricmc.loader.api.ModContainer;

/**
 * triweave.mod.json のエントリポイント用アダプタ。次の形式のクラスを受け付ける。
 * <ol>
 *   <li>Fabric形式(ModInitializer 等)  → そのまま</li>
 *   <li>Triweave形式(TriweaveInitializer 等) → TriweaveContext を渡して呼ぶ</li>
 *   <li>Quilt(QSL)形式 → Quiltアダプタに任せる</li>
 * </ol>
 */
public final class TriweaveLanguageAdapter implements LanguageAdapter {
    @Override
    public <T> T create(ModContainer mod, String value, Class<T> type) throws LanguageAdapterException {
        final Object instance;
        try {
            Class<?> cls = Class.forName(value, true, TriweaveLanguageAdapter.class.getClassLoader());
            Constructor<?> ctor = cls.getDeclaredConstructor();
            ctor.setAccessible(true);
            instance = ctor.newInstance();
        } catch (InvocationTargetException e) {
            throw new LanguageAdapterException(e.getCause() != null ? e.getCause() : e);
        } catch (ReflectiveOperationException | LinkageError e) {
            throw new LanguageAdapterException(e);
        }

        if (type.isInstance(instance)) return type.cast(instance);

        TriweaveContext ctx = new ContextImpl(mod.getMetadata().getId());
        if (type == ModInitializer.class && instance instanceof TriweaveInitializer t) {
            return type.cast((ModInitializer) () -> t.onInitialize(ctx));
        }
        if (type == ClientModInitializer.class && instance instanceof TriweaveClientInitializer t) {
            return type.cast((ClientModInitializer) () -> t.onInitializeClient(ctx));
        }
        if (type == DedicatedServerModInitializer.class && instance instanceof TriweaveServerInitializer t) {
            return type.cast((DedicatedServerModInitializer) () -> t.onInitializeServer(ctx));
        }
        return new QuiltLanguageAdapter().create(mod, value, type);     // QSL形式など
    }
}
