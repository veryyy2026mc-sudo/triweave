package dev.triweave.core;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.CopyOnWriteArrayList;

import dev.triweave.api.CrossBus;
import dev.triweave.api.CrossPlayer;
import dev.triweave.api.Loader;
import dev.triweave.api.ModConfig;
import dev.triweave.api.ModInfo;
import dev.triweave.api.Services;
import dev.triweave.api.State;
import dev.triweave.api.ToggleResult;
import dev.triweave.api.ToggleStatus;
import dev.triweave.neoforge.Mc;
import net.fabricmc.loader.api.FabricLoader;
import net.fabricmc.loader.api.ModContainer;

/** Triweave API の実装。一覧(.triweave/modlist.tsv)と状態(.triweave/mod-state.properties)を扱う。 */
public final class TriweaveCore {
    private TriweaveCore() {}

    private static final Services SERVICES = new Services();
    private static final CrossBus BUS = new CrossBus();
    private static final Map<String, ModConfig> CONFIGS = new ConcurrentHashMap<>();
    private static final Map<String, List<Runnable>> RELOAD = new ConcurrentHashMap<>();
    private static final List<Runnable> ON_SERVER_READY = new CopyOnWriteArrayList<>();
    private static final List<Runnable> ON_SERVER_STOPPING = new CopyOnWriteArrayList<>();
    private static volatile Object server;        // MinecraftServer(クライアント単体では null)

    public static Services services() { return SERVICES; }

    public static CrossBus bus() { return BUS; }

    public static String version() {
        return FabricLoader.getInstance().getModContainer("triweave")
                .map(m -> m.getMetadata().getVersion().getFriendlyString()).orElse("?");
    }

    static Path work() { return FabricLoader.getInstance().getGameDir().resolve(".triweave"); }

    // ------------------------------------------------------------------ MOD情報

    public static Collection<ModInfo> mods() {
        List<ModInfo> out = new ArrayList<>();
        Set<String> off = loadOff();
        Path f = work().resolve("modlist.tsv");
        if (!Files.isRegularFile(f)) return out;
        try {
            for (String l : Files.readAllLines(f, StandardCharsets.UTF_8)) {
                String[] p = l.split("\t", -1);
                if (p.length < 6) continue;
                out.add(toInfo(p[0], p[1], p[2], p[3], p[4], p[5], off));
            }
        } catch (IOException e) {
            System.err.println("[Triweave] could not read modlist.tsv: " + e);
        }
        return out;
    }

    private static ModInfo toInfo(String kind, String id, String name, String version, String file, String note,
            Set<String> off) {
        Loader loader = switch (kind) {
            case "triweave" -> Loader.TRIWEAVE;
            case "quilt" -> Loader.QUILT;
            case "neoforge" -> Loader.NEOFORGE;
            case "bukkit" -> Loader.BUKKIT;
            default -> Loader.FABRIC;
        };
        boolean loaded = !id.isEmpty() && FabricLoader.getInstance().isModLoaded(id);
        State state;
        if (note.startsWith("disabled")) state = State.DISABLED;
        else if (note.startsWith("rejected") && !loaded) state = State.REJECTED;
        else state = loaded ? State.RUNNING : State.NOT_LOADED;
        return new ModInfo(id, name, version, loader, state, off.contains(id), file, note);
    }

    public static ModInfo find(String idOrName) {
        String n = idOrName.toLowerCase(Locale.ROOT);
        Collection<ModInfo> all = mods();
        for (ModInfo m : all) if (m.id().toLowerCase(Locale.ROOT).equals(n)) return m;
        for (ModInfo m : all) if (m.name().toLowerCase(Locale.ROOT).equals(n)) return m;
        for (ModInfo m : all) if (m.name().toLowerCase(Locale.ROOT).contains(n)) return m;
        return null;
    }

    public static boolean isRunning(String id) { return FabricLoader.getInstance().isModLoaded(id); }

    // ------------------------------------------------------------------ ON / OFF

    public static boolean isProtected(String id) {
        return id.equals("triweave") || id.equals("fabric-api") || id.equals("fabricloader")
                || id.equals("minecraft") || id.equals("java");
    }

    public static ToggleResult setEnabled(String idOrName, boolean enabled) {
        ModInfo m = find(idOrName);
        if (m == null || m.id().isEmpty()) return new ToggleResult(ToggleStatus.NOT_FOUND, m, List.of());
        if (m.loader() == Loader.BUKKIT) return new ToggleResult(ToggleStatus.UNSUPPORTED, m, List.of());
        if (!enabled) {
            if (isProtected(m.id())) return new ToggleResult(ToggleStatus.PROTECTED, m, List.of());
            List<String> blockers = dependents(m.id());
            if (!blockers.isEmpty()) return new ToggleResult(ToggleStatus.REQUIRED_BY_OTHERS, m, blockers);
        }
        Set<String> off = loadOff();
        if (enabled) off.remove(m.id()); else off.add(m.id());
        saveOff(off);
        return new ToggleResult(ToggleStatus.OK, m, List.of());
    }

    /** このMODを必須(depends)にしている、他のロード済みMODの名前。 */
    static List<String> dependents(String id) {
        List<String> out = new ArrayList<>();
        Set<String> off = loadOff();
        try {
            for (ModContainer mc : FabricLoader.getInstance().getAllMods()) {
                String otherId = mc.getMetadata().getId();
                if (otherId.equals(id) || off.contains(otherId)) continue;
                Object deps = Mc.invoke(mc.getMetadata(), "getDependencies");
                if (!(deps instanceof Collection<?> c)) continue;
                for (Object dep : c) {
                    String kind = String.valueOf(Mc.invoke(dep, "getKind"));
                    String depId = String.valueOf(Mc.invoke(dep, "getModId"));
                    if (kind.equals("DEPENDS") && depId.equals(id)) { out.add(mc.getMetadata().getName()); break; }
                }
            }
        } catch (Throwable t) {
            // 調べられなくても、起動前処理(Bootstrap)側が同じ検査をして守る
        }
        return out;
    }

    static Set<String> loadOff() {
        Set<String> off = new HashSet<>();
        Path f = work().resolve("mod-state.properties");
        if (!Files.isRegularFile(f)) return off;
        Properties p = new Properties();
        try (InputStream in = Files.newInputStream(f)) {
            p.load(in);
        } catch (IOException e) {
            return off;
        }
        for (String id : p.stringPropertyNames()) if ("off".equalsIgnoreCase(p.getProperty(id).trim())) off.add(id);
        return off;
    }

    static void saveOff(Set<String> off) {
        try {
            Files.createDirectories(work());
            Properties p = new Properties();
            for (String id : off) p.setProperty(id, "off");
            try (OutputStream out = Files.newOutputStream(work().resolve("mod-state.properties"))) {
                p.store(out, "Triweave mod state (applied at next launch)");
            }
        } catch (IOException e) {
            System.err.println("[Triweave] could not write mod-state.properties: " + e);
        }
    }

    // ------------------------------------------------------------------ サーバー / プレイヤー

    /** FabricHooks(ServerLifecycleEvents)から呼ばれる。 */
    public static void onServerStarted(Object minecraftServer) {
        server = minecraftServer;
        for (Runnable r : ON_SERVER_READY) safeRun(r);
    }

    public static void onServerStopping(Object minecraftServer) {
        for (Runnable r : ON_SERVER_STOPPING) safeRun(r);
        server = null;
    }

    public static void onServerReady(Runnable r) { ON_SERVER_READY.add(r); if (server != null) safeRun(r); }

    public static void onServerStopping(Runnable r) { ON_SERVER_STOPPING.add(r); }

    private static void safeRun(Runnable r) {
        try {
            r.run();
        } catch (Throwable t) {
            System.err.println("[Triweave] server lifecycle listener failed: " + t);
        }
    }

    /** 現在接続中の全プレイヤー。Fabric/Quilt/NeoForge(互換層)いずれのMODから見ても同じ結果になる。 */
    public static List<CrossPlayer> players() {
        List<CrossPlayer> out = new ArrayList<>();
        Object s = server;
        if (s == null) return out;
        try {
            Object list = Mc.invoke(s, "getPlayerList");
            Object players = Mc.invoke(list, "getPlayers");
            for (Object p : (Iterable<?>) players) {
                Object nameComponent = Mc.invoke(p, "getName");
                String name = String.valueOf(Mc.invoke(nameComponent, "getString"));
                java.util.UUID id = (java.util.UUID) Mc.invoke(p, "getUUID");
                boolean op = Boolean.TRUE.equals(tryOp(s, p));
                out.add(new CrossPlayer(name, id, op));
            }
        } catch (Throwable t) {
            System.err.println("[Triweave] could not list players: " + t);
        }
        return out;
    }

    private static Boolean tryOp(Object server, Object player) {
        try {
            Object list = Mc.invoke(server, "getPlayerList");
            Object gameProfile = Mc.invoke(player, "getGameProfile");
            return (Boolean) Mc.invoke(list, "isOp", gameProfile);
        } catch (RuntimeException e) {
            return null;
        }
    }


    /** サーバー・クライアント問わず、見えるチャットに1行送る(コンソールにも出る)。 */
    public static void broadcast(String message) {
        Object s = server;
        if (s == null) { System.out.println("[Triweave] " + message); return; }
        try {
            Object list = Mc.invoke(s, "getPlayerList");
            Object component = Mc.invokeStatic("net.minecraft.network.chat.Component", "literal", message);
            Mc.invoke(list, "broadcastSystemMessage", component, Boolean.FALSE);
        } catch (Throwable t) {
            System.out.println("[Triweave] " + message);
        }
    }

    // ------------------------------------------------------------------ 設定 / リロード

    public static ModConfig config(String modId) {
        return CONFIGS.computeIfAbsent(modId,
                id -> new ModConfig(FabricLoader.getInstance().getConfigDir().resolve(id + ".properties")));
    }

    public static void registerReload(String modId, Runnable r) {
        RELOAD.computeIfAbsent(modId == null ? "" : modId, k -> new CopyOnWriteArrayList<>()).add(r);
    }

    public static int reload(String modId) {
        int count = 0;
        if (modId == null) {
            for (ModConfig c : CONFIGS.values()) { c.reload(); count++; }
            for (List<Runnable> l : RELOAD.values()) count += run(l);
        } else {
            ModConfig c = CONFIGS.get(modId);
            if (c != null) { c.reload(); count++; }
            count += run(RELOAD.getOrDefault(modId, List.of()));
        }
        return count;
    }

    private static int run(List<Runnable> list) {
        int n = 0;
        for (Runnable r : list) {
            try {
                r.run();
                n++;
            } catch (Throwable t) {
                System.err.println("[Triweave] reload listener failed: " + t);
            }
        }
        return n;
    }
}
