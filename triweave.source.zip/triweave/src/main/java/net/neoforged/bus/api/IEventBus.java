package net.neoforged.bus.api;

import java.util.function.Consumer;

/** NeoForge互換shim。実装は dev.triweave.neoforge.SimpleEventBus。 */
public interface IEventBus {
    void register(Object target);
    void unregister(Object target);
    <T extends Event> void addListener(Consumer<T> listener);
    <T extends Event> void addListener(EventPriority priority, Consumer<T> listener);
    /** Triweave拡張: イベント型を明示して登録する(ラムダの型推定が不要)。 */
    <T extends Event> void addListener(Class<T> eventType, Consumer<T> listener);
    <T extends Event> T post(T event);
}
