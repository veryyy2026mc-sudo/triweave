package net.neoforged.bus.api;

/** NeoForge互換shim(Triweave提供)。本物同様 isCanceled/setCanceled(1つのl)。 */
public interface ICancellableEvent {
    boolean isCanceled();

    void setCanceled(boolean canceled);
}
