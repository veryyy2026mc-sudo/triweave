package net.neoforged.bus.api;

/** NeoForge互換shim(Triweave提供): イベントの基底クラス。 */
public abstract class Event {}
