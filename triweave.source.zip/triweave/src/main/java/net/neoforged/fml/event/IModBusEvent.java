package net.neoforged.fml.event;

/** MODバスに流れるイベントの目印。 */
public interface IModBusEvent {}
