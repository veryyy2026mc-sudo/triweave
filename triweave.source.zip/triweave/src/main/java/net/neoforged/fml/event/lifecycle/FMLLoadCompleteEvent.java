package net.neoforged.fml.event.lifecycle;

public class FMLLoadCompleteEvent extends ParallelDispatchEvent {}
