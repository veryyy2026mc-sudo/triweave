package net.neoforged.fml.event.lifecycle;

import java.util.concurrent.CompletableFuture;
import java.util.function.Supplier;

import net.neoforged.bus.api.Event;
import net.neoforged.fml.event.IModBusEvent;

/** enqueueWork は即時実行する(Triweaveでは並列ディスパッチをしない)。 */
public abstract class ParallelDispatchEvent extends Event implements IModBusEvent {
    public CompletableFuture<Void> enqueueWork(Runnable work) {
        try {
            work.run();
            return CompletableFuture.completedFuture(null);
        } catch (Throwable t) {
            return CompletableFuture.failedFuture(t);
        }
    }

    public <T> CompletableFuture<T> enqueueWork(Supplier<T> work) {
        try {
            return CompletableFuture.completedFuture(work.get());
        } catch (Throwable t) {
            return CompletableFuture.failedFuture(t);
        }
    }
}
