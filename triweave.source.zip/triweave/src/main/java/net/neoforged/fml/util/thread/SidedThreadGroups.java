package net.neoforged.fml.util.thread;

/**
 * 注意: Triweave では本物のサーバースレッドをこのグループに入れられないため、
 * 「現在のスレッドがSERVERグループか」の判定は常に false になる(遅延実行の一部が動かない)。
 */
public final class SidedThreadGroups {
    public static final SidedThreadGroup CLIENT = new SidedThreadGroup("CLIENT");
    public static final SidedThreadGroup SERVER = new SidedThreadGroup("SERVER");

    private SidedThreadGroups() {}
}
