package net.neoforged.fml.util.thread;

public class SidedThreadGroup extends ThreadGroup {
    public SidedThreadGroup(String name) { super(name); }
}
