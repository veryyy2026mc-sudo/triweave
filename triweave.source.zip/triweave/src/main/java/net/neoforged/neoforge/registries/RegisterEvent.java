package net.neoforged.neoforge.registries;

import java.util.function.Consumer;
import java.util.function.Supplier;

import dev.triweave.neoforge.Mc;
import net.minecraft.core.Registry;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.neoforged.bus.api.Event;
import net.neoforged.fml.event.IModBusEvent;

/** レジストリごとに1回、MODバスへ流れる登録イベント。 */
public class RegisterEvent extends Event implements IModBusEvent {
    private final ResourceKey<?> registryKey;
    private final Object registry;

    public RegisterEvent(ResourceKey<?> registryKey, Object registry) {
        this.registryKey = registryKey;
        this.registry = registry;
    }

    public ResourceKey getRegistryKey() { return registryKey; }

    public Registry getRegistry() { return (Registry) registry; }

    public <T> void register(ResourceKey<? extends Registry<T>> key, Consumer<RegisterHelper<T>> consumer) {
        if (registryKey.equals(key)) {
            consumer.accept((name, value) -> Mc.register(registry, name, value));
        }
    }

    public <T> void register(ResourceKey<? extends Registry<T>> key, Identifier name, Supplier<T> value) {
        if (registryKey.equals(key)) {
            Mc.register(registry, name, value.get());
        }
    }

    @FunctionalInterface
    public interface RegisterHelper<T> {
        void register(Identifier name, T value);
    }
}
