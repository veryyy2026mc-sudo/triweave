package net.neoforged.neoforge.event.entity.living;

import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.LivingEntity;
import net.neoforged.bus.api.ICancellableEvent;
import net.neoforged.bus.api.Event;

/**
 * NeoForge互換shim(Triweave提供)。
 * Fabric APIの {@code ServerLivingEntityEvents.ALLOW_DEATH} に橋渡しする
 * (キャンセルすると死亡を取り消せる)。
 */
public final class LivingDeathEvent extends Event implements ICancellableEvent {
    private final LivingEntity entity;
    private final DamageSource source;
    private boolean canceled;

    public LivingDeathEvent(LivingEntity entity, DamageSource source) {
        this.entity = entity; this.source = source;
    }

    public LivingEntity getEntity() { return entity; }

    public DamageSource getSource() { return source; }

    @Override public boolean isCanceled() { return canceled; }

    @Override public void setCanceled(boolean cancel) { this.canceled = cancel; }
}
