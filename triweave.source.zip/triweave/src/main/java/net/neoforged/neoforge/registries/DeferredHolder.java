package net.neoforged.neoforge.registries;

import java.util.function.Supplier;

import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;

/**
 * 登録後に値を返すホルダー。
 * 注意: 本物は net.minecraft.core.Holder も実装するが、Triweave版は未実装(Supplier のみ)。
 */
public class DeferredHolder<R, T extends R> implements Supplier<T> {
    private final ResourceKey<R> key;
    private final Identifier id;
    private volatile T value;

    public DeferredHolder(ResourceKey<R> key, Identifier id) {
        this.key = key;
        this.id = id;
    }

    public Identifier getId() { return id; }

    public ResourceKey<R> getKey() { return key; }

    public boolean isBound() { return value != null; }

    @Override
    public T get() {
        T v = value;
        if (v == null) throw new IllegalStateException("Trying to access unbound value: " + id);
        return v;
    }

    @SuppressWarnings("unchecked")
    void bind(Object v) { this.value = (T) v; }
}
