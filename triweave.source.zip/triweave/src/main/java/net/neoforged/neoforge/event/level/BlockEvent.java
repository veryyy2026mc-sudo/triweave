package net.neoforged.neoforge.event.level;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.bus.api.ICancellableEvent;
import net.neoforged.bus.api.Event;

/** NeoForge互換shim(Triweave提供)。ブロック破壊イベント(Fabric APIのPlayerBlockBreakEventsに橋渡し)。 */
public abstract class BlockEvent extends Event {
    private final Level level;
    private final BlockPos pos;
    private final BlockState state;

    protected BlockEvent(Level level, BlockPos pos, BlockState state) {
        this.level = level; this.pos = pos; this.state = state;
    }

    public Level getLevel() { return level; }

    public BlockPos getPos() { return pos; }

    public BlockState getState() { return state; }

    /**
     * ブロックが壊される前。{@link #setCanceled} すると破壊を取り消せる
     * (Fabricの {@code beforeBlockBreak} の戻り値に反映される)。
     */
    public static final class BreakEvent extends BlockEvent implements ICancellableEvent {
        private final net.minecraft.world.entity.player.Player player;
        private boolean canceled;

        public BreakEvent(Level level, BlockPos pos, BlockState state, net.minecraft.world.entity.player.Player player) {
            super(level, pos, state);
            this.player = player;
        }

        public net.minecraft.world.entity.player.Player getPlayer() { return player; }

        @Override public boolean isCanceled() { return canceled; }

        @Override public void setCanceled(boolean cancel) { this.canceled = cancel; }
    }
}
