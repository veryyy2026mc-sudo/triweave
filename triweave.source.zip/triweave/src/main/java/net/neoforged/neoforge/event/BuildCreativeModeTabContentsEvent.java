package net.neoforged.neoforge.event;

import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ItemLike;
import net.neoforged.bus.api.Event;
import net.neoforged.fml.event.IModBusEvent;

import dev.triweave.neoforge.Mc;

/** クリエイティブタブの中身を作るイベント。Fabric API の出力オブジェクトに橋渡しする。 */
public class BuildCreativeModeTabContentsEvent extends Event implements IModBusEvent {
    private final ResourceKey<?> tabKey;
    private final Object output;

    public BuildCreativeModeTabContentsEvent(ResourceKey<?> tabKey, Object output) {
        this.tabKey = tabKey;
        this.output = output;
    }

    public ResourceKey getTabKey() { return tabKey; }

    public void accept(ItemLike item) { Mc.invoke(output, "accept", item); }

    public void accept(ItemStack stack) { Mc.invoke(output, "accept", stack); }
}
