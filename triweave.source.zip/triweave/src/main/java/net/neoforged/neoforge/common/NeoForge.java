package net.neoforged.neoforge.common;

import dev.triweave.neoforge.SimpleEventBus;
import net.neoforged.bus.api.IEventBus;

public final class NeoForge {
    public static final IEventBus EVENT_BUS = SimpleEventBus.GAME;

    private NeoForge() {}
}
