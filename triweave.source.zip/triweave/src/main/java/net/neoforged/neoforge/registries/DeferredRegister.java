package net.neoforged.neoforge.registries;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;
import java.util.function.Supplier;

import dev.triweave.neoforge.Mc;
import net.minecraft.core.Registry;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.neoforged.bus.api.IEventBus;

/** 遅延登録。bus に登録すると、対応する RegisterEvent で実際にレジストリへ登録される。 */
public class DeferredRegister<T> {
    private static final class Entry {
        final Identifier id;
        final DeferredHolder<?, ?> holder;
        final Function<Identifier, ?> factory;
        Entry(Identifier id, DeferredHolder<?, ?> holder, Function<Identifier, ?> factory) {
            this.id = id; this.holder = holder; this.factory = factory;
        }
    }

    protected final ResourceKey<? extends Registry<T>> registryKey;
    protected final String namespace;
    private final List<Entry> entries = new ArrayList<>();

    protected DeferredRegister(ResourceKey<? extends Registry<T>> registryKey, String namespace) {
        this.registryKey = registryKey;
        this.namespace = namespace;
    }

    public static <T> DeferredRegister<T> create(ResourceKey<? extends Registry<T>> registryKey, String namespace) {
        return new DeferredRegister<>(registryKey, namespace);
    }

    public static Items createItems(String namespace) {
        return new Items(namespace);
    }

    public static Blocks createBlocks(String namespace) {
        return new Blocks(namespace);
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    protected DeferredHolder<T, ?> createHolder(ResourceKey<T> key, Identifier id) {
        return new DeferredHolder(key, id);
    }

    @SuppressWarnings("unchecked")
    public <I extends T> DeferredHolder<T, I> register(String name, Function<Identifier, ? extends I> func) {
        Identifier id = Mc.identifier(namespace, name);
        ResourceKey<T> key = (ResourceKey<T>) Mc.resourceKey(registryKey, id);
        DeferredHolder<T, I> holder = (DeferredHolder<T, I>) createHolder(key, id);
        entries.add(new Entry(id, holder, func));
        return holder;
    }

    public <I extends T> DeferredHolder<T, I> register(String name, Supplier<? extends I> sup) {
        return register(name, (Function<Identifier, ? extends I>) id -> sup.get());
    }

    public void register(IEventBus bus) {
        bus.addListener(RegisterEvent.class, this::onRegister);
    }

    private void onRegister(RegisterEvent event) {
        if (!event.getRegistryKey().equals(registryKey)) return;
        for (Entry e : entries) {
            Object value = e.factory.apply(e.id);
            Mc.register(event.getRegistry(), e.id, value);
            e.holder.bind(value);
        }
    }

    // ------------------------------------------------------------------ Items

    public static class Items extends DeferredRegister<Item> {
        protected Items(String namespace) {
            super(Mc.registryKey("ITEM"), namespace);
        }

        @Override
        @SuppressWarnings({"unchecked", "rawtypes"})
        protected DeferredHolder<Item, ?> createHolder(ResourceKey<Item> key, Identifier id) {
            return new DeferredItem(key, id);
        }

        @SuppressWarnings("unchecked")
        public <I extends Item> DeferredItem<I> registerItem(String name,
                Function<Item.Properties, ? extends I> func, Supplier<Item.Properties> props) {
            return (DeferredItem<I>) register(name, (Function<Identifier, ? extends I>) id -> {
                Item.Properties p = (Item.Properties) Mc.withId(props.get(), "ITEM", id);
                return func.apply(p);
            });
        }

        public <I extends Item> DeferredItem<I> registerItem(String name, Function<Item.Properties, ? extends I> func) {
            return registerItem(name, func, () -> (Item.Properties) Mc.newInstance("net.minecraft.world.item.Item$Properties"));
        }

        public DeferredItem<Item> registerSimpleItem(String name, Supplier<Item.Properties> props) {
            return registerItem(name, p -> (Item) Mc.newInstance("net.minecraft.world.item.Item", p), props);
        }

        public DeferredItem<Item> registerSimpleItem(String name) {
            return registerItem(name, p -> (Item) Mc.newInstance("net.minecraft.world.item.Item", p));
        }
    }

    // ------------------------------------------------------------------ Blocks

    public static class Blocks extends DeferredRegister<Block> {
        protected Blocks(String namespace) {
            super(Mc.registryKey("BLOCK"), namespace);
        }

        @Override
        @SuppressWarnings({"unchecked", "rawtypes"})
        protected DeferredHolder<Block, ?> createHolder(ResourceKey<Block> key, Identifier id) {
            return new DeferredBlock(key, id);
        }

        @SuppressWarnings("unchecked")
        public <B extends Block> DeferredBlock<B> registerBlock(String name,
                Function<BlockBehaviour.Properties, ? extends B> func, Supplier<BlockBehaviour.Properties> props) {
            return (DeferredBlock<B>) register(name, (Function<Identifier, ? extends B>) id -> {
                BlockBehaviour.Properties p = (BlockBehaviour.Properties) Mc.withId(props.get(), "BLOCK", id);
                return func.apply(p);
            });
        }

        public <B extends Block> DeferredBlock<B> registerBlock(String name,
                Function<BlockBehaviour.Properties, ? extends B> func) {
            return registerBlock(name, func, () -> (BlockBehaviour.Properties)
                    Mc.invokeStatic("net.minecraft.world.level.block.state.BlockBehaviour$Properties", "of"));
        }

        public DeferredBlock<Block> registerSimpleBlock(String name, Supplier<BlockBehaviour.Properties> props) {
            return registerBlock(name, p -> (Block) Mc.newInstance("net.minecraft.world.level.block.Block", p), props);
        }
    }
}
