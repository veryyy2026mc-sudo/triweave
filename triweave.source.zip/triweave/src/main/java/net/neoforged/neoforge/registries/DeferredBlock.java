package net.neoforged.neoforge.registries;

import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.block.Block;

public class DeferredBlock<T extends Block> extends DeferredHolder<Block, T> {
    public DeferredBlock(ResourceKey<Block> key, Identifier id) { super(key, id); }
}
