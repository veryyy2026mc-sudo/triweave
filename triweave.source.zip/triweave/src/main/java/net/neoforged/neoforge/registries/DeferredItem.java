package net.neoforged.neoforge.registries;

import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.ItemLike;

public class DeferredItem<T extends Item> extends DeferredHolder<Item, T> implements ItemLike {
    public DeferredItem(ResourceKey<Item> key, Identifier id) { super(key, id); }

    @Override
    public Item asItem() { return get(); }
}
