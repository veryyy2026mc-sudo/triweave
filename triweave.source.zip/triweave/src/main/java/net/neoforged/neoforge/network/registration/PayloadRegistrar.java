package net.neoforged.neoforge.network.registration;

import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.neoforged.neoforge.network.handling.IPayloadHandler;

/** 通信は未対応。メッセージ登録を試みたら例外にする(通信MODは受け入れ判定で拒否される)。 */
public class PayloadRegistrar {
    public <T extends CustomPacketPayload> PayloadRegistrar playBidirectional(CustomPacketPayload.Type<T> type,
            StreamCodec codec, IPayloadHandler<T> clientHandler, IPayloadHandler<T> serverHandler) {
        throw new UnsupportedOperationException("Triweave: network payloads are not supported");
    }
}
