package net.neoforged.neoforge.network.handling;

/** 通信は未対応(Triweave)。MCreatorの定型コードをリンクさせるためだけに存在する。 */
public interface IPayloadContext {}
