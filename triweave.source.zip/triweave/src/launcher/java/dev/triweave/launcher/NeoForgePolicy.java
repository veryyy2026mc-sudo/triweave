package dev.triweave.launcher;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.TreeSet;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/**
 * NeoForge MOD を「Triweave の互換層で動かせるか」判定する。
 *
 * <p>拒否する条件:
 * Kotlin(KotlinForForge) / ネットワーク通信 / Mixin・AccessTransformer /
 * 互換層が提供していない NeoForge API の使用 / @Mod クラスなし。
 */
final class NeoForgePolicy {
    record Decision(boolean accepted, List<String> reasons, List<String> modClasses) {}

    private NeoForgePolicy() {}

    static Decision evaluate(Path jar, ApiList api) {
        List<String> reasons = new ArrayList<>();
        List<String> modClasses = new ArrayList<>();
        try (ZipFile zf = new ZipFile(jar.toFile())) {
            ZipEntry te = zf.getEntry("META-INF/neoforge.mods.toml");
            if (te == null) return new Decision(false, List.of("neoforge.mods.toml がありません"), modClasses);
            NeoForgeToml.Result toml;
            try (InputStream in = zf.getInputStream(te)) {
                toml = NeoForgeToml.parse(new String(in.readAllBytes(), StandardCharsets.UTF_8), null);
            }

            if (api.isEmpty()) reasons.add("互換層のAPI一覧が見つかりません(ビルドの問題)");
            if ("klf".equals(toml.modLoader()) || toml.kotlinDependency()) reasons.add("Kotlin(KotlinForForge)は未対応");
            if (toml.mixins()) reasons.add("NeoForge用Mixin設定は未対応");
            if (toml.accessTransformers()) reasons.add("AccessTransformerは未対応");

            TreeSet<String> missing = new TreeSet<>();
            TreeSet<String> payloadClasses = new TreeSet<>();
            boolean kotlin = false;
            for (Enumeration<? extends ZipEntry> en = zf.entries(); en.hasMoreElements();) {
                ZipEntry e = en.nextElement();
                String n = e.getName();
                if (e.isDirectory() || !n.endsWith(".class") || n.startsWith("META-INF/")) continue;
                ClassFileScan.Refs r;
                try (InputStream in = zf.getInputStream(e)) {
                    r = ClassFileScan.scan(in.readAllBytes(), "net/neoforged/");
                } catch (IOException | RuntimeException ex) {
                    continue;
                }
                String cname = n.substring(0, n.length() - ".class".length());
                if (r.sawModAnnotation()) modClasses.add(cname.replace('/', '.'));
                if (r.sawKotlin()) kotlin = true;
                if (r.sawPayload() && !isMcreatorNetworkBoilerplate(cname)) payloadClasses.add(simple(cname));
                for (String c : r.classes()) if (c.startsWith("net/neoforged/") && !api.hasClass(c)) missing.add(simple(c));
                for (String m : r.membersByPrefix()[0]) if (!api.hasMember(m)) missing.add(shortMember(m));
            }
            if (kotlin && reasons.stream().noneMatch(s -> s.startsWith("Kotlin"))) reasons.add("Kotlinのコードを含むため未対応");
            if (!payloadClasses.isEmpty()) {
                reasons.add("ネットワーク通信(" + limit(payloadClasses, 3) + ")は未対応");
            }
            if (!missing.isEmpty()) {
                reasons.add("未対応のNeoForge API: " + limit(missing, 5));
            }
            if (modClasses.isEmpty()) reasons.add("@Modクラスが見つかりません");
        } catch (IOException e) {
            reasons.add("読み取りエラー: " + e.getMessage());
        }
        return new Decision(reasons.isEmpty(), reasons, modClasses);
    }

    /** MCreatorがネットワーク未使用でも必ず生成する定型コード(メインクラスと NetworkMessage レコード)。 */
    private static boolean isMcreatorNetworkBoilerplate(String internalName) {
        String s = simple(internalName);
        return s.endsWith("Mod") || s.endsWith("Mod$NetworkMessage");
    }

    private static String simple(String internal) {
        int i = internal.lastIndexOf('/');
        return i < 0 ? internal : internal.substring(i + 1);
    }

    private static String shortMember(String m) {
        int colon = m.indexOf(':');
        String ownerName = m.substring(0, colon);
        int dot = ownerName.lastIndexOf('.');
        return simple(ownerName.substring(0, dot)) + "." + ownerName.substring(dot + 1);
    }

    private static String limit(java.util.Collection<String> items, int max) {
        List<String> l = new ArrayList<>(items);
        String head = String.join(", ", l.subList(0, Math.min(max, l.size())));
        return l.size() > max ? head + " ほか" + (l.size() - max) + "件" : head;
    }

    private static boolean hasEntry(Path jar, String name) {
        try (java.util.zip.ZipFile zf = new java.util.zip.ZipFile(jar.toFile())) {
            return zf.getEntry(name) != null;
        } catch (IOException e) {
            return false;
        }
    }

    /** java -jar triweave.jar check <jar...> */
    static void cli(String[] args) {
        ApiList api = ApiList.load("neoforge-api.txt");
        for (String a : args) {
            Path jar = java.nio.file.Paths.get(a);
            if (BukkitPolicy.isPlugin(jar)) {
                BukkitPolicy.print(jar, BukkitPolicy.evaluate(jar, ApiList.load("bukkit-api.txt")));
                continue;
            }
            if (hasEntry(jar, "paper-plugin.yml") && !hasEntry(jar, "META-INF/neoforge.mods.toml")
                    && !hasEntry(jar, "fabric.mod.json")) {
                System.out.println("[REJECT] " + a);
                System.out.println("    - paper-plugin.yml(Paperの新プラグイン形式)は今回未対応。plugin.yml形式のみ対応");
                continue;
            }
            Decision d = evaluate(jar, api);
            System.out.println((d.accepted() ? "[ACCEPT] " : "[REJECT] ") + a);
            for (String r : d.reasons()) System.out.println("    - " + r);
            if (d.accepted()) System.out.println("    @Mod: " + d.modClasses());
        }
    }
}
