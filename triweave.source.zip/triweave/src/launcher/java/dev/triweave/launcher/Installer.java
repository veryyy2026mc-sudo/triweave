package dev.triweave.launcher;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.net.URISyntaxException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.time.Instant;
import java.util.Comparator;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Stream;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

/**
 * 公式ランチャー用の簡易インストーラ。
 * 先にFabric Loader(26.3用)をFabric公式インストーラで入れておき、その上にTriweaveを重ねる。
 *
 * <pre>java -jar triweave-0.1.0.jar install [--mc &lt;.minecraftのパス&gt;] [--base &lt;Fabricのバージョン名&gt;]</pre>
 */
final class Installer {
    private static final Pattern FABRIC_ID = Pattern.compile("fabric-loader-(.+)-([^-]+)");

    private Installer() {}

    static void run(String[] args) throws IOException {
        Path mc = defaultMinecraftDir();
        String base = null;
        for (int i = 0; i < args.length - 1; i++) {
            if (args[i].equals("--mc")) mc = Paths.get(args[i + 1]);
            if (args[i].equals("--base")) base = args[i + 1];
        }

        Path versions = mc.resolve("versions");
        if (!Files.isDirectory(versions)) throw new IOException("versions folder not found: " + versions);

        if (base == null) {
            try (Stream<Path> s = Files.list(versions)) {
                base = s.filter(Files::isDirectory)
                        .filter(p -> FABRIC_ID.matcher(p.getFileName().toString()).matches())
                        .max(Comparator.comparingLong(p -> p.toFile().lastModified()))
                        .map(p -> p.getFileName().toString())
                        .orElseThrow(() -> new IOException(
                                "No Fabric profile found. Install Fabric Loader for Minecraft 26.3 first."));
            }
        }
        Matcher m = FABRIC_ID.matcher(base);
        if (!m.matches()) throw new IOException("Not a Fabric version id: " + base);
        String mcVersion = m.group(2);
        String twVersion = Bootstrap.version();
        String id = "triweave-" + mcVersion;

        // 1) 自分自身を libraries/ にコピー
        Path self;
        try {
            self = Paths.get(Installer.class.getProtectionDomain().getCodeSource().getLocation().toURI());
        } catch (URISyntaxException e) {
            throw new IOException(e);
        }
        if (!Files.isRegularFile(self)) throw new IOException("Run the installer from the built jar, not from a class folder.");
        Path lib = mc.resolve("libraries/dev/triweave/triweave/" + twVersion + "/triweave-" + twVersion + ".jar");
        Files.createDirectories(lib.getParent());
        Files.copy(self, lib, StandardCopyOption.REPLACE_EXISTING);

        // 2) バージョンJSON(Fabricを継承し、mainClassだけ差し替える)
        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        JsonObject v = new JsonObject();
        v.addProperty("id", id);
        v.addProperty("inheritsFrom", base);
        v.addProperty("type", "release");
        v.addProperty("time", Instant.now().toString());
        v.addProperty("releaseTime", Instant.now().toString());
        v.addProperty("mainClass", "dev.triweave.launcher.TriweaveMain");
        JsonArray libs = new JsonArray();
        JsonObject l = new JsonObject();
        l.addProperty("name", "dev.triweave:triweave:" + twVersion);
        libs.add(l);
        v.add("libraries", libs);

        Path vdir = versions.resolve(id);
        Files.createDirectories(vdir);
        try (Writer w = Files.newBufferedWriter(vdir.resolve(id + ".json"), StandardCharsets.UTF_8)) {
            gson.toJson(v, w);
        }

        // 3) ランチャープロファイル(あれば)
        Path profiles = mc.resolve("launcher_profiles.json");
        if (Files.isRegularFile(profiles)) {
            JsonObject root;
            try (Reader r = Files.newBufferedReader(profiles, StandardCharsets.UTF_8)) {
                root = JsonParser.parseReader(r).getAsJsonObject();
            }
            JsonObject ps = root.has("profiles") ? root.getAsJsonObject("profiles") : new JsonObject();
            JsonObject p = new JsonObject();
            p.addProperty("name", "Triweave " + mcVersion);
            p.addProperty("type", "custom");
            p.addProperty("created", Instant.now().toString());
            p.addProperty("lastUsed", Instant.now().toString());
            p.addProperty("lastVersionId", id);
            ps.add("triweave-" + mcVersion, p);
            root.add("profiles", ps);
            try (Writer w = Files.newBufferedWriter(profiles, StandardCharsets.UTF_8)) {
                gson.toJson(root, w);
            }
        }

        Log.info("Installed '" + id + "' (base: " + base + ") into " + mc);
        Log.info("Launch the 'Triweave " + mcVersion + "' profile in the Minecraft Launcher.");
    }

    private static Path defaultMinecraftDir() {
        String os = System.getProperty("os.name", "").toLowerCase(Locale.ROOT);
        String home = System.getProperty("user.home");
        if (os.contains("win")) {
            String appdata = System.getenv("APPDATA");
            return Paths.get(appdata != null ? appdata : home, ".minecraft");
        }
        if (os.contains("mac")) return Paths.get(home, "Library", "Application Support", "minecraft");
        return Paths.get(home, ".minecraft");
    }
}
