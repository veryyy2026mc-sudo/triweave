package dev.triweave.launcher;

import java.io.IOException;
import java.net.URISyntaxException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

/**
 * 専用サーバー用の簡易インストーラ。
 * 先にFabric公式インストーラで「server」をインストールしておき(fabric-server-launch.jar ができる)、
 * その上に Triweave を重ねる: triweave jar をコピーして、起動スクリプト(-javaagent 付き)を作る。
 *
 * <pre>java -jar triweave-0.1.0.jar install-server [--dir &lt;サーバーのフォルダ&gt;] [--launch &lt;jar&gt;] [--mem 4G]</pre>
 */
final class ServerInstaller {
    private ServerInstaller() {}

    static void run(String[] args) throws IOException {
        Path dir = Paths.get(System.getProperty("user.dir"));
        String launch = "fabric-server-launch.jar", mem = "4G";
        for (int i = 0; i < args.length - 1; i++) {
            if (args[i].equals("--dir")) dir = Paths.get(args[i + 1]);
            if (args[i].equals("--launch")) launch = args[i + 1];
            if (args[i].equals("--mem")) mem = args[i + 1];
        }
        dir = dir.toAbsolutePath();
        if (!Files.isDirectory(dir)) throw new IOException("server folder not found: " + dir);

        Path self;
        try {
            self = Paths.get(ServerInstaller.class.getProtectionDomain().getCodeSource().getLocation().toURI());
        } catch (URISyntaxException e) {
            throw new IOException(e);
        }
        if (!Files.isRegularFile(self)) throw new IOException("Run the installer from the built jar.");
        String ver = Bootstrap.version();
        String jarName = "triweave-" + ver + ".jar";
        Files.copy(self, dir.resolve(jarName), StandardCopyOption.REPLACE_EXISTING);
        Files.createDirectories(dir.resolve("mods"));

        String cmd = "java -Xmx" + mem + " -javaagent:" + jarName + " -jar " + launch + " nogui";
        String bat = "@echo off\r\nchcp 65001 >nul\r\ncd /d \"%~dp0\"\r\n" + cmd + "\r\npause\r\n";
        String sh = "#!/bin/sh\ncd \"$(dirname \"$0\")\"\nexec " + cmd + "\n";
        Path batFile = dir.resolve(Files.exists(dir.resolve("start.bat")) ? "start-triweave.bat" : "start.bat");
        Path shFile = dir.resolve(Files.exists(dir.resolve("start.sh")) ? "start-triweave.sh" : "start.sh");
        Files.writeString(batFile, bat, StandardCharsets.UTF_8);
        Files.writeString(shFile, sh, StandardCharsets.UTF_8);
        shFile.toFile().setExecutable(true);

        Log.info("Installed Triweave " + ver + " into " + dir);
        Log.info("Start scripts: " + batFile.getFileName() + " / " + shFile.getFileName() + "  ->  " + cmd);
        if (!Files.exists(dir.resolve(launch))) {
            Log.warn(launch + " not found in " + dir + ". Run the Fabric installer first:"
                    + "  java -jar fabric-installer.jar server -mcversion 26.3 -downloadMinecraft");
        }
        Log.info("Note: Minecraft 26.3 needs Java 25. Put Fabric/Quilt/NeoForge mods in mods/.");
    }
}
