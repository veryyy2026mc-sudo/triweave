package dev.triweave.launcher;

import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.util.HashSet;
import java.util.Set;

/**
 * .class ファイルの定数プールだけを読んで、参照されているクラス名・メンバー(フィールド/メソッド)名を
 * 取り出す最小パーサ。NeoForge判定とBukkit判定の両方が、このひとつの実装を共有する(以前は2本あった)。
 */
final class ClassFileScan {
    /** @param classes 参照されている全クラス名(内部名)。prefixesで絞っていない全件
     *  @param membersByPrefix prefixes の各接頭辞ごとに集めた "owner.name:descriptor" の集合(呼び出し順に対応) */
    record Refs(Set<String> classes, Set<String>[] membersByPrefix, boolean sawKotlin, boolean sawPayload,
               boolean sawModAnnotation) {}

    private ClassFileScan() {}

    /**
     * @param memberPrefixes 戻り値の membersByPrefix を集計するクラス名接頭辞(例: {"net/neoforged/"})。
     *                       空なら全メンバー参照を集めない(軽量化)。
     */
    @SuppressWarnings("unchecked")
    static Refs scan(byte[] bytes, String... memberPrefixes) throws IOException {
        DataInputStream in = new DataInputStream(new ByteArrayInputStream(bytes));
        if (in.readInt() != 0xCAFEBABE) throw new IOException("not a class file");
        in.readUnsignedShort();
        in.readUnsignedShort();
        int n = in.readUnsignedShort();
        String[] utf = new String[n];
        int[] classIdx = new int[n];
        int[][] member = new int[n][];
        int[][] nat = new int[n][];
        byte[] tag = new byte[n];

        for (int i = 1; i < n; i++) {
            int t = in.readUnsignedByte();
            tag[i] = (byte) t;
            switch (t) {
                case 1 -> utf[i] = in.readUTF();
                case 3, 4 -> in.skipBytes(4);
                case 5, 6 -> { in.skipBytes(8); i++; }
                case 7 -> classIdx[i] = in.readUnsignedShort();
                case 8, 16, 19, 20 -> in.skipBytes(2);
                case 9, 10, 11 -> member[i] = new int[] {in.readUnsignedShort(), in.readUnsignedShort()};
                case 12 -> nat[i] = new int[] {in.readUnsignedShort(), in.readUnsignedShort()};
                case 15 -> in.skipBytes(3);
                case 17, 18 -> in.skipBytes(4);
                default -> throw new IOException("bad constant pool tag " + t);
            }
        }

        Set<String> classes = new HashSet<>();
        Set<String>[] byPrefix = new Set[memberPrefixes.length];
        for (int i = 0; i < byPrefix.length; i++) byPrefix[i] = new HashSet<>();
        boolean kotlin = false, payload = false, modAnn = false;

        for (int i = 1; i < n; i++) {
            if (tag[i] == 7) {
                String name = utf[classIdx[i]];
                if (name == null) continue;
                classes.add(name);
                if (name.startsWith("kotlin/")) kotlin = true;
                if (name.equals("net/minecraft/network/protocol/common/custom/CustomPacketPayload")) payload = true;
            } else if (member[i] != null) {
                String owner = utf[classIdx[member[i][0]]];
                int[] nt = nat[member[i][1]];
                if (owner == null || nt == null) continue;
                for (int p = 0; p < memberPrefixes.length; p++) {
                    if (owner.startsWith(memberPrefixes[p])) {
                        byPrefix[p].add(owner + "." + utf[nt[0]] + ":" + utf[nt[1]]);
                    }
                }
            } else if (tag[i] == 1 && "Lnet/neoforged/fml/common/Mod;".equals(utf[i])) {
                modAnn = true;
            }
        }
        return new Refs(classes, byPrefix, kotlin, payload, modAnn);
    }
}
