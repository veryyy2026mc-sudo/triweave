package dev.triweave.launcher;

/** MODのローダー種別。宣言順がそのまま優先順位(TRIWEAVE > FABRIC > QUILT > NEOFORGE > FORGE)。 */
enum Kind {
    TRIWEAVE, FABRIC, QUILT, NEOFORGE, FORGE, UNKNOWN
}
