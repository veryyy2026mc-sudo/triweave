package dev.triweave.launcher;

import java.lang.instrument.Instrumentation;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * JVM引数 {@code -javaagent:triweave-x.y.z.jar} で呼ばれる入口。
 * Fabric(Knot)がmods/を読む前に、翻訳済みjarの書き出しとFabric API設置を済ませる。
 * 起動クラスを差し替えられないランチャー(Modrinth App等)向けで、毎回自動で実行される。
 */
public final class TriweaveAgent {
    private static final Pattern GAME_DIR = Pattern.compile("--gameDir\\s+(\"[^\"]+\"|\\S+)");

    private TriweaveAgent() {}

    public static void premain(String agentArgs, Instrumentation inst) {
        try {
            // -Dtriweave.mode=addmods : mods/ に何も書き出さず、fabric.addMods でFabricに渡す(既定は inplace)
            boolean inPlace = !"addmods".equalsIgnoreCase(System.getProperty("triweave.mode", "inplace"));
            Bootstrap.prepare(resolveGameDir(), inPlace);
        } catch (Throwable t) {
            // 失敗してもゲームは止めない
            Log.error("agent preparation failed", t);
        }
    }

    private static Path resolveGameDir() {
        String cmd = System.getProperty("sun.java.command", "");
        Matcher m = GAME_DIR.matcher(cmd);
        if (m.find()) {
            Path p = Paths.get(m.group(1).replace("\"", "")).toAbsolutePath();
            if (Files.isDirectory(p)) return p;
        }
        return Paths.get(System.getProperty("user.dir")).toAbsolutePath();
    }
}
