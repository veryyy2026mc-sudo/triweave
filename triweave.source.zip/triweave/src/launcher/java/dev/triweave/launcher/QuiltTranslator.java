package dev.triweave.launcher;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonPrimitive;

/**
 * quilt.mod.json を fabric.mod.json に変換し、Fabric Loader が読める jar を作る。
 * 元のjarは変更せず、キャッシュ先に変換済みjarを書き出す。
 */
final class QuiltTranslator {
    static final String ADAPTER = "triweave-quilt";
    private static final int MAX_NEST_DEPTH = 3;

    private QuiltTranslator() {}

    /** @return 変換済みjar(キャッシュ済みならそれを再利用) */
    static Path translate(Path jar, Path cacheDir, String twVersion) throws IOException {
        Files.createDirectories(cacheDir);
        String stem = jar.getFileName().toString().replaceAll("(?i)\\.jar$", "");
        Path out = cacheDir.resolve(stem + "-" + sha1(jar).substring(0, 12) + "-tw" + twVersion + ".jar");
        if (Files.isRegularFile(out)) return out;

        Path tmp = Files.createTempFile(cacheDir, "tw-", ".tmp");
        try {
            try (OutputStream os = Files.newOutputStream(tmp)) {
                rewrite(jar, os, 0, stem);
            }
            Files.move(tmp, out, StandardCopyOption.REPLACE_EXISTING);
        } finally {
            Files.deleteIfExists(tmp);
        }
        return out;
    }

    // ------------------------------------------------------------------ jar rewrite

    private static void rewrite(Path jar, OutputStream os, int depth, String label) throws IOException {
        try (ZipFile zf = new ZipFile(jar.toFile()); ZipOutputStream zos = new ZipOutputStream(os)) {
            ZipEntry qe = zf.getEntry("quilt.mod.json");
            if (qe == null) throw new IOException("quilt.mod.json not found in " + label);

            JsonObject quilt;
            try (Reader r = new InputStreamReader(zf.getInputStream(qe), StandardCharsets.UTF_8)) {
                quilt = JsonParser.parseReader(r).getAsJsonObject();
            }
            Converted c = convert(quilt, label);
            for (String w : c.warnings) Log.warn(label + ": " + w);

            Set<String> written = new HashSet<>();
            for (Enumeration<? extends ZipEntry> en = zf.entries(); en.hasMoreElements();) {
                ZipEntry e = en.nextElement();
                String n = e.getName();
                if (n.equals("fabric.mod.json") || isSignature(n) || !written.add(n)) continue;

                ZipEntry ne = new ZipEntry(n);
                if (e.getTime() > 0) ne.setTime(e.getTime());
                zos.putNextEntry(ne);
                if (!e.isDirectory()) {
                    if (c.nestedJars.contains(n) && depth < MAX_NEST_DEPTH) {
                        copyNested(zf, e, zos, depth + 1, n);
                    } else {
                        try (InputStream in = zf.getInputStream(e)) { in.transferTo(zos); }
                    }
                }
                zos.closeEntry();
            }

            zos.putNextEntry(new ZipEntry("fabric.mod.json"));
            zos.write(c.fabric.toString().getBytes(StandardCharsets.UTF_8));
            zos.closeEntry();
        }
    }

    /** JiJ内のjarがQuilt専用なら、それも再帰的に変換して書き込む。 */
    private static void copyNested(ZipFile outer, ZipEntry entry, ZipOutputStream zos, int depth, String name)
            throws IOException {
        Path tmp = Files.createTempFile("triweave-nested-", ".jar");
        try {
            try (InputStream in = outer.getInputStream(entry)) {
                Files.copy(in, tmp, StandardCopyOption.REPLACE_EXISTING);
            }
            boolean quiltOnly;
            try (ZipFile nz = new ZipFile(tmp.toFile())) {
                quiltOnly = nz.getEntry("quilt.mod.json") != null && nz.getEntry("fabric.mod.json") == null;
            } catch (IOException notAZip) {
                quiltOnly = false;
            }
            if (quiltOnly) {
                ByteArrayOutputStream bos = new ByteArrayOutputStream();
                rewrite(tmp, bos, depth, name);
                zos.write(bos.toByteArray());
            } else {
                Files.copy(tmp, zos);
            }
        } finally {
            Files.deleteIfExists(tmp);
        }
    }

    private static boolean isSignature(String n) {
        String u = n.toUpperCase(Locale.ROOT);
        return u.startsWith("META-INF/") && !u.substring(9).contains("/")
                && (u.endsWith(".SF") || u.endsWith(".RSA") || u.endsWith(".DSA") || u.endsWith(".EC")
                    || u.startsWith("META-INF/SIG-"));
    }

    // ------------------------------------------------------------------ json conversion

    record Converted(JsonObject fabric, Set<String> nestedJars, List<String> warnings) {}

    static Converted convert(JsonObject quilt, String label) throws IOException {
        List<String> warnings = new ArrayList<>();
        Set<String> nested = new HashSet<>();
        JsonObject f = new JsonObject();

        JsonObject ql = obj(quilt, "quilt_loader");
        if (ql == null) throw new IOException("quilt_loader is missing in " + label);
        String id = str(ql, "id");
        String version = str(ql, "version");
        if (id == null || version == null) throw new IOException("quilt_loader.id/version missing in " + label);

        f.addProperty("schemaVersion", 1);
        f.addProperty("id", id);
        f.addProperty("version", version);

        // --- metadata
        JsonObject md = obj(ql, "metadata");
        if (md != null) {
            copyStr(md, "name", f, "name");
            copyStr(md, "description", f, "description");
            JsonElement icon = md.get("icon");
            if (icon != null && (icon.isJsonPrimitive() || icon.isJsonObject())) f.add("icon", icon);

            JsonElement lic = md.get("license");
            if (lic != null) {
                JsonArray la = new JsonArray();
                for (JsonElement l : list(lic)) {
                    if (l.isJsonPrimitive()) la.add(l.getAsString());
                    else if (l.isJsonObject()) {
                        String s = str(l.getAsJsonObject(), "id");
                        if (s == null) s = str(l.getAsJsonObject(), "name");
                        if (s != null) la.add(s);
                    }
                }
                if (la.size() == 1) f.add("license", la.get(0));
                else if (la.size() > 1) f.add("license", la);
            }

            JsonObject contrib = obj(md, "contributors");
            if (contrib != null) {
                JsonArray authors = new JsonArray(), others = new JsonArray();
                for (Map.Entry<String, JsonElement> e : contrib.entrySet()) {
                    String role = e.getValue().isJsonPrimitive() ? e.getValue().getAsString() : "";
                    if (role.equalsIgnoreCase("Owner") || role.equalsIgnoreCase("Author")
                            || role.equalsIgnoreCase("Developer")) authors.add(e.getKey());
                    else others.add(e.getKey());
                }
                if (authors.size() > 0) f.add("authors", authors);
                if (others.size() > 0) f.add("contributors", others);
            }

            JsonObject contact = obj(md, "contact");
            if (contact != null) {
                JsonObject c = new JsonObject();
                for (Map.Entry<String, JsonElement> e : contact.entrySet()) {
                    if (e.getValue().isJsonPrimitive()) c.add(e.getKey(), e.getValue());
                }
                if (c.size() > 0) f.add("contact", c);
            }
        }

        // --- environment
        JsonObject mc = obj(quilt, "minecraft");
        String env = mc == null ? null : str(mc, "environment");
        f.addProperty("environment", "dedicated_server".equals(env) ? "server" : env == null ? "*" : env);

        // --- provides
        JsonArray provides = new JsonArray();
        for (JsonElement p : list(ql.get("provides"))) {
            if (p.isJsonPrimitive()) provides.add(p.getAsString());
            else if (p.isJsonObject() && str(p.getAsJsonObject(), "id") != null)
                provides.add(str(p.getAsJsonObject(), "id"));
        }
        if (provides.size() > 0) f.add("provides", provides);

        // --- entrypoints
        JsonObject eps = obj(ql, "entrypoints");
        if (eps != null) {
            JsonObject outEps = new JsonObject();
            for (Map.Entry<String, JsonElement> en : eps.entrySet()) {
                String key = switch (en.getKey()) {
                    case "init" -> "main";
                    case "client_init" -> "client";
                    case "server_init" -> "server";
                    case "pre_launch" -> "preLaunch";
                    default -> en.getKey();
                };
                JsonArray target = outEps.has(key) ? outEps.getAsJsonArray(key) : new JsonArray();
                for (JsonElement v : list(en.getValue())) {
                    String value, adapter = "default";
                    if (v.isJsonPrimitive()) {
                        value = v.getAsString();
                    } else if (v.isJsonObject()) {
                        value = str(v.getAsJsonObject(), "value");
                        String a = str(v.getAsJsonObject(), "adapter");
                        if (a != null) adapter = a;
                    } else continue;
                    if (value == null) continue;
                    if (adapter.equals("default")) adapter = ADAPTER;
                    JsonObject o = new JsonObject();
                    o.addProperty("adapter", adapter);
                    o.addProperty("value", value);
                    target.add(o);
                }
                if (target.size() > 0) outEps.add(key, target);
            }
            if (outEps.size() > 0) f.add("entrypoints", outEps);
        }

        // --- dependencies
        JsonObject depends = new JsonObject(), suggests = new JsonObject(), breaks = new JsonObject();
        for (JsonElement d : list(ql.get("depends"))) {
            if (d.isJsonArray()) { warnings.add("alternative-dependency group ignored: " + d); continue; }
            String did = null; JsonElement ver = null; boolean optional = false;
            if (d.isJsonPrimitive()) did = d.getAsString();
            else if (d.isJsonObject()) {
                JsonObject o = d.getAsJsonObject();
                did = str(o, "id");
                ver = o.get("versions");
                optional = o.has("optional") && o.get("optional").isJsonPrimitive() && o.get("optional").getAsBoolean();
            }
            if (did == null) continue;
            switch (did) {
                case "quilt_loader" -> depends.addProperty("fabricloader", "*"); // バージョン体系が別物
                case "quilted_fabric_api", "quilted-fabric-api" ->
                        (optional ? suggests : depends).addProperty("fabric-api", "*");
                case "qsl", "quilt_base" -> warnings.add("QSL dependency '" + did + "' dropped (partially shimmed)");
                default -> {
                    if (did.startsWith("quilt_")) {
                        warnings.add("QSL module dependency '" + did + "' dropped (partially shimmed)");
                    } else {
                        (optional ? suggests : depends).add(did, versions(ver));
                    }
                }
            }
        }
        for (JsonElement b : list(ql.get("breaks"))) {
            if (b.isJsonPrimitive()) breaks.addProperty(b.getAsString(), "*");
            else if (b.isJsonObject() && str(b.getAsJsonObject(), "id") != null)
                breaks.add(str(b.getAsJsonObject(), "id"), versions(b.getAsJsonObject().get("versions")));
        }
        depends.addProperty("triweave", ">=0.1.0"); // 言語アダプタを提供するMOD
        f.add("depends", depends);
        if (suggests.size() > 0) f.add("suggests", suggests);
        if (breaks.size() > 0) f.add("breaks", breaks);

        // --- mixins / access widener
        JsonArray mixins = new JsonArray();
        for (JsonElement m : list(quilt.get("mixin"))) mixins.add(m);
        if (mixins.size() > 0) f.add("mixins", mixins);

        List<JsonElement> aws = list(quilt.get("access_widener"));
        if (!aws.isEmpty()) {
            f.add("accessWidener", aws.get(0));
            if (aws.size() > 1) warnings.add("Fabric supports one access widener; only the first is used");
        }

        // --- nested jars
        JsonArray jars = new JsonArray();
        for (JsonElement j : list(ql.get("jars"))) {
            if (!j.isJsonPrimitive()) continue;
            JsonObject o = new JsonObject();
            o.addProperty("file", j.getAsString());
            jars.add(o);
            nested.add(j.getAsString());
        }
        if (jars.size() > 0) f.add("jars", jars);

        JsonObject custom = new JsonObject();
        custom.addProperty("triweave:translated_from", "quilt");
        f.add("custom", custom);

        return new Converted(f, nested, warnings);
    }

    /** Quilt の versions(文字列 / 配列 / {any}{all})を Fabric の範囲指定に直す。 */
    private static JsonElement versions(JsonElement v) {
        if (v == null || v.isJsonNull()) return new JsonPrimitive("*");
        if (v.isJsonPrimitive()) return v;
        if (v.isJsonArray()) {
            JsonArray a = new JsonArray();
            for (JsonElement e : v.getAsJsonArray()) {
                JsonElement c = versions(e);
                if (c.isJsonPrimitive()) a.add(c);
                else if (c.isJsonArray()) a.addAll(c.getAsJsonArray());
            }
            return a.size() == 0 ? new JsonPrimitive("*") : a;
        }
        JsonObject o = v.getAsJsonObject();
        if (o.has("any")) return versions(o.get("any"));
        if (o.has("all")) {
            List<String> parts = new ArrayList<>();
            for (JsonElement e : list(o.get("all"))) if (e.isJsonPrimitive()) parts.add(e.getAsString());
            return new JsonPrimitive(parts.isEmpty() ? "*" : String.join(" ", parts));
        }
        return new JsonPrimitive("*");
    }

    // ------------------------------------------------------------------ json helpers

    private static JsonObject obj(JsonObject o, String k) {
        JsonElement e = o.get(k);
        return e != null && e.isJsonObject() ? e.getAsJsonObject() : null;
    }

    private static String str(JsonObject o, String k) {
        JsonElement e = o.get(k);
        return e != null && e.isJsonPrimitive() ? e.getAsString() : null;
    }

    private static void copyStr(JsonObject from, String fk, JsonObject to, String tk) {
        String s = str(from, fk);
        if (s != null) to.addProperty(tk, s);
    }

    /** null→空、単体→1要素、配列→その要素。 */
    private static List<JsonElement> list(JsonElement e) {
        List<JsonElement> out = new ArrayList<>();
        if (e == null || e.isJsonNull()) return out;
        if (e.isJsonArray()) e.getAsJsonArray().forEach(out::add);
        else out.add(e);
        return out;
    }

    private static String sha1(Path p) throws IOException {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-1");
            try (InputStream in = Files.newInputStream(p)) {
                byte[] buf = new byte[8192];
                for (int n; (n = in.read(buf)) > 0;) md.update(buf, 0, n);
            }
            StringBuilder sb = new StringBuilder();
            for (byte b : md.digest()) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new IOException(e);
        }
    }
}
