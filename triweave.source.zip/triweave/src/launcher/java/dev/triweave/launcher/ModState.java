package dev.triweave.launcher;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashSet;
import java.util.Properties;
import java.util.Set;

/** ゲーム内コマンド /mod <名前> off が書く「OFFにするMOD」の一覧。次回起動時に適用される。 */
final class ModState {
    private ModState() {}

    static Set<String> loadOff(Path work) {
        Set<String> off = new HashSet<>();
        Path f = work.resolve("mod-state.properties");
        if (!Files.isRegularFile(f)) return off;
        Properties p = new Properties();
        try (InputStream in = Files.newInputStream(f)) {
            p.load(in);
        } catch (IOException e) {
            Log.warn("could not read mod-state.properties: " + e);
            return off;
        }
        for (String id : p.stringPropertyNames()) {
            if ("off".equalsIgnoreCase(p.getProperty(id).trim())) off.add(id);
        }
        return off;
    }

    /** 無効化してはいけないid。 */
    static boolean isProtected(String id) {
        return id.equals("triweave") || id.equals("fabric-api") || id.equals("fabricloader")
                || id.equals("minecraft") || id.equals("java");
    }
}
