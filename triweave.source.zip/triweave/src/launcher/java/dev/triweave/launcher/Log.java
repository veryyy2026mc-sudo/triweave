package dev.triweave.launcher;

final class Log {
    private Log() {}

    static void info(String msg) { System.out.println("[Triweave] " + msg); }

    static void warn(String msg) { System.out.println("[Triweave] WARN: " + msg); }

    static void error(String msg, Throwable t) {
        System.err.println("[Triweave] ERROR: " + msg);
        if (t != null) t.printStackTrace();
    }
}
