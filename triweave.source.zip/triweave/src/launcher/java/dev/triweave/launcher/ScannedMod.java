package dev.triweave.launcher;

import java.nio.file.Path;
import java.util.EnumSet;
import java.util.Set;

/**
 * @param kinds    jarが対応を宣言している全ローダー
 * @param chosen   実際に使うローダー(優先順位: FABRIC > QUILT > NEOFORGE)
 * @param disabled Triweave がOFFにしたjar(拡張子 .jar.triweave-off)
 * @param depends  fabric.mod.json の depends に書かれたMOD id(Fabricのみ)
 */
record ScannedMod(Path path, String id, String name, String version, EnumSet<Kind> kinds, Kind chosen,
                  boolean disabled, Set<String> depends) {}
