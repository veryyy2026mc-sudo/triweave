package dev.triweave.launcher;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import java.util.jar.Manifest;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

/**
 * 受け入れ判定を通った NeoForge MOD を、Fabric が読める jar にする。
 * 元のコードは一切変えず、fabric.mod.json を足して、@Mod クラスを main エントリポイントにするだけ
 * (26.x は Fabric も NeoForge も Mojang名なので、クラスの変換は不要)。
 */
final class NeoForgeTranslator {
    private NeoForgeTranslator() {}

    static Path translate(Path jar, Path cacheDir, String twVersion, NeoForgePolicy.Decision decision) throws IOException {
        Files.createDirectories(cacheDir);
        String stem = jar.getFileName().toString().replaceAll("(?i)\\.jar$", "");
        Path out = cacheDir.resolve(stem + "-" + sha1(jar).substring(0, 12) + "-nfrun-tw" + twVersion + ".jar");
        if (Files.isRegularFile(out)) return out;

        Path tmp = Files.createTempFile(cacheDir, "tw-", ".tmp");
        try {
            try (ZipFile zf = new ZipFile(jar.toFile()); OutputStream os = Files.newOutputStream(tmp);
                 ZipOutputStream zos = new ZipOutputStream(os)) {
                JsonObject fabric = buildJson(zf, decision);
                Set<String> written = new HashSet<>();
                for (Enumeration<? extends ZipEntry> en = zf.entries(); en.hasMoreElements();) {
                    ZipEntry e = en.nextElement();
                    String n = e.getName();
                    if (n.equals("fabric.mod.json") || isSignature(n) || !written.add(n)) continue;
                    ZipEntry ne = new ZipEntry(n);
                    if (e.getTime() > 0) ne.setTime(e.getTime());
                    zos.putNextEntry(ne);
                    if (!e.isDirectory()) {
                        try (InputStream in = zf.getInputStream(e)) { in.transferTo(zos); }
                    }
                    zos.closeEntry();
                }
                zos.putNextEntry(new ZipEntry("fabric.mod.json"));
                zos.write(fabric.toString().getBytes(StandardCharsets.UTF_8));
                zos.closeEntry();
            }
            Files.move(tmp, out, StandardCopyOption.REPLACE_EXISTING);
        } finally {
            Files.deleteIfExists(tmp);
        }
        return out;
    }

    private static JsonObject buildJson(ZipFile zf, NeoForgePolicy.Decision decision) throws IOException {
        ZipEntry te = zf.getEntry("META-INF/neoforge.mods.toml");
        String manifestVersion = null;
        ZipEntry me = zf.getEntry("META-INF/MANIFEST.MF");
        if (me != null) {
            try (InputStream in = zf.getInputStream(me)) {
                manifestVersion = new Manifest(in).getMainAttributes().getValue("Implementation-Version");
            }
        }
        NeoForgeToml.Result toml;
        try (InputStream in = zf.getInputStream(te)) {
            toml = NeoForgeToml.parse(new String(in.readAllBytes(), StandardCharsets.UTF_8), manifestVersion);
        }
        if (toml.mods().isEmpty()) throw new IOException("no [[mods]] in neoforge.mods.toml");
        NeoForgeToml.Mod mod = toml.mods().get(0);

        JsonObject f = new JsonObject();
        f.addProperty("schemaVersion", 1);
        f.addProperty("id", fabricId(mod.id()));
        f.addProperty("version", NeoForgeStub.safeVersion(mod.version()));
        f.addProperty("name", mod.name());
        String desc = "[Triweave] NeoForge互換層で実行中";
        f.addProperty("description", mod.description().isBlank() ? desc : desc + "\n" + mod.description());
        if (mod.authors() != null && !mod.authors().isBlank()) {
            JsonArray a = new JsonArray();
            for (String s : mod.authors().split(",")) if (!s.isBlank()) a.add(s.trim());
            f.add("authors", a);
        }
        JsonObject contact = new JsonObject();
        if (mod.url() != null && mod.url().startsWith("http")) contact.addProperty("homepage", mod.url());
        if (toml.issueTracker() != null && toml.issueTracker().startsWith("http"))
            contact.addProperty("issues", toml.issueTracker());
        if (contact.size() > 0) f.add("contact", contact);
        if (toml.license() != null) f.addProperty("license", toml.license());
        if (mod.icon() != null && zf.getEntry(mod.icon()) != null) f.addProperty("icon", mod.icon());
        f.addProperty("environment", "*");

        JsonArray mains = new JsonArray();
        for (String c : decision.modClasses()) {
            JsonObject o = new JsonObject();
            o.addProperty("adapter", "triweave-neoforge");
            o.addProperty("value", c);
            mains.add(o);
        }
        JsonObject eps = new JsonObject();
        eps.add("main", mains);
        f.add("entrypoints", eps);

        JsonObject depends = new JsonObject();
        depends.addProperty("triweave", ">=0.1.0");
        f.add("depends", depends);

        JsonObject custom = new JsonObject();
        custom.addProperty("triweave:translated_from", "neoforge");
        f.add("custom", custom);
        return f;
    }

    private static String fabricId(String modId) {
        String s = modId.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9_-]", "_");
        if (s.isEmpty() || !Character.isLetter(s.charAt(0))) s = "m" + s;
        if (s.length() < 2) s = s + "_";
        return s.length() > 64 ? s.substring(0, 64) : s;
    }

    private static boolean isSignature(String n) {
        String u = n.toUpperCase(Locale.ROOT);
        return u.startsWith("META-INF/") && !u.substring(9).contains("/")
                && (u.endsWith(".SF") || u.endsWith(".RSA") || u.endsWith(".DSA") || u.endsWith(".EC")
                    || u.startsWith("META-INF/SIG-"));
    }

    private static String sha1(Path p) throws IOException {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-1");
            try (InputStream in = Files.newInputStream(p)) {
                byte[] buf = new byte[8192];
                for (int n; (n = in.read(buf)) > 0;) md.update(buf, 0, n);
            }
            StringBuilder sb = new StringBuilder();
            for (byte b : md.digest()) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new IOException(e);
        }
    }
}
