package dev.triweave.launcher;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.URISyntaxException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;

/**
 * 単体実行({@code java -jar})ではGsonが無いので、同梱のgson.jarを付けて自分自身を起動し直す。
 * (ゲーム内ではMinecraftがGsonを持っているので、この仕組みは使わない)
 */
final class InstallerLauncher {
    private InstallerLauncher() {}

    private static void dispatch(String command, String[] args) throws Exception {
        switch (command) {
            case "install" -> Installer.run(args);
            case "prepare" -> {
                Path gameDir = Paths.get(System.getProperty("user.dir")).toAbsolutePath();
                for (int i = 0; i < args.length - 1; i++) {
                    if (args[i].equals("--gameDir")) gameDir = Paths.get(args[i + 1]).toAbsolutePath();
                }
                Bootstrap.prepare(gameDir, true);
            }
            case "check" -> NeoForgePolicy.cli(args);
            case "install-server" -> ServerInstaller.run(args);
            default -> throw new IllegalArgumentException("unknown command: " + command);
        }
    }

    static void run(String command, String[] args) throws Exception {
        boolean hasGson;
        try {
            Class.forName("com.google.gson.JsonParser");
            hasGson = true;
        } catch (ClassNotFoundException e) {
            hasGson = false;
        }
        if (hasGson) {
            dispatch(command, args);
            return;
        }

        Path self;
        try {
            self = Paths.get(InstallerLauncher.class.getProtectionDomain().getCodeSource().getLocation().toURI());
        } catch (URISyntaxException e) {
            throw new IOException(e);
        }
        Path gson = Files.createTempFile("triweave-gson-", ".jar");
        try {
            try (InputStream in = InstallerLauncher.class.getResourceAsStream("/triweave/gson.jar")) {
                if (in == null) throw new IOException("embedded gson.jar not found; add Gson to the classpath");
                Files.copy(in, gson, StandardCopyOption.REPLACE_EXISTING);
            }
            List<String> cmd = new ArrayList<>();
            cmd.add(Paths.get(System.getProperty("java.home"), "bin", "java").toString());
            cmd.add("-cp");
            cmd.add(self + File.pathSeparator + gson);
            cmd.add("dev.triweave.launcher.TriweaveMain");
            cmd.add(command);
            for (String a : args) cmd.add(a);
            int rc = new ProcessBuilder(cmd).inheritIO().start().waitFor();
            if (rc != 0) System.exit(rc);
        } finally {
            Files.deleteIfExists(gson);
        }
    }
}
