package dev.triweave.launcher;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.TreeSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipInputStream;

/**
 * Bukkit / Spigot / Paper プラグインを「Triweaveの互換層(org.bukkit.*)で動かせるか」判定する。
 * 判定の考え方・コードの形はNeoForge用の {@link NeoForgePolicy} と同じ(互換層API一覧との突き合わせ)。
 *
 * <p>互換層が提供するのは設定・ログ・ライフサイクル・簡単なイベント/コマンド/スケジューラのみで、
 * プレイヤー・ワールド・ブロック等の本体とは連動しない(README参照)。そのためアップロード実績のある
 * 本格的なプラグイン(WorldEdit等)は、未対応APIが多数検出されて拒否される。
 */
final class BukkitPolicy {
    record Decision(boolean accepted, List<String> reasons, String mainClass, String pluginYml) {}

    private static final Pattern MAIN = Pattern.compile("(?m)^main:\\s*['\"]?([^'\"\\s]+)['\"]?\\s*$");

    private BukkitPolicy() {}

    static boolean isPlugin(Path jar) {
        try (ZipFile zf = new ZipFile(jar.toFile())) {
            return zf.getEntry("plugin.yml") != null;        // paper-plugin.ymlは別形式のため今回は対象外
        } catch (IOException e) {
            return false;
        }
    }

    static Decision evaluate(Path jar, ApiList api) {
        List<String> reasons = new ArrayList<>();
        String mainClass = null, yml = null;
        try (ZipFile zf = new ZipFile(jar.toFile())) {
            ZipEntry y = zf.getEntry("plugin.yml");
            if (y == null) return new Decision(false, List.of("plugin.yml がありません"), null, null);
            try (InputStream in = zf.getInputStream(y)) { yml = new String(in.readAllBytes(), StandardCharsets.UTF_8); }
            Matcher m = MAIN.matcher(yml);
            if (!m.find()) return new Decision(false, List.of("plugin.yml に main: がありません"), null, yml);
            mainClass = m.group(1);

            if (api.isEmpty()) reasons.add("互換層のAPI一覧が見つかりません(ビルドの問題)");

            TreeSet<String> missing = new TreeSet<>();
            boolean kotlin = false;
            String mainInternal = mainClass.replace('.', '/') + ".class";
            for (ZipEntry e : allClassEntries(zf)) {
                ClassFileScan.Refs r;
                try (InputStream in = zf.getInputStream(e)) {
                    r = ClassFileScan.scan(in.readAllBytes(), "org/bukkit/");
                } catch (IOException | RuntimeException ex) {
                    continue;
                }
                if (r.sawKotlin()) kotlin = true;
                for (String c : r.classes()) if (c.startsWith("org/bukkit/") && !api.hasClass(c)) missing.add(simple(c));
                for (String mem : r.membersByPrefix()[0]) if (!api.hasMember(mem)) missing.add(shortMember(mem));
            }
            if (!classExists(zf, mainInternal)) reasons.add("mainクラス(" + mainClass + ")がjar内に見つかりません");
            if (hasNestedJar(zf)) {
                reasons.add("本体が内部jar(jarinjar等)に格納されており、静的なAPI判定では安全を確認できません");
            }
            if (kotlin) reasons.add("Kotlinのコードを含むため未対応");
            if (!missing.isEmpty()) reasons.add("未対応のBukkit API: " + limit(missing, 6));
        } catch (IOException e) {
            reasons.add("読み取りエラー: " + e.getMessage());
        }
        return new Decision(reasons.isEmpty(), reasons, mainClass, yml);
    }

    /** "loader" + 内部jar(jarinjar/shadow)のパターンは、静的スキャンでは本体の安全性を確認できないため拒否する。 */
    private static boolean hasNestedJar(ZipFile zf) {
        for (var en = zf.entries(); en.hasMoreElements();) {
            String n = en.nextElement().getName();
            if (n.endsWith(".jarinjar") || (n.endsWith(".jar") && !n.startsWith("META-INF/"))) return true;
        }
        return false;
    }

    private static boolean classExists(ZipFile zf, String internalPath) {
        if (zf.getEntry(internalPath) != null) return true;
        for (ZipEntry e : allNestedCandidates(zf)) if (e.getName().equals(internalPath)) return true;
        return false;                                         // ネストjar(shadow化)の中は確認していない
    }

    private static List<ZipEntry> allClassEntries(ZipFile zf) {
        List<ZipEntry> out = new ArrayList<>();
        for (var en = zf.entries(); en.hasMoreElements();) {
            ZipEntry e = en.nextElement();
            if (!e.isDirectory() && e.getName().endsWith(".class") && !e.getName().startsWith("META-INF/")) out.add(e);
        }
        return out;
    }

    private static List<ZipEntry> allNestedCandidates(ZipFile zf) { return List.of(); }

    private static String simple(String internal) {
        int i = internal.lastIndexOf('/');
        return i < 0 ? internal : internal.substring(i + 1);
    }

    private static String shortMember(String m) {
        int colon = m.indexOf(':');
        String ownerName = m.substring(0, colon);
        int dot = ownerName.lastIndexOf('.');
        return simple(ownerName.substring(0, dot)) + "." + ownerName.substring(dot + 1);
    }

    private static String limit(java.util.Collection<String> items, int max) {
        List<String> l = new ArrayList<>(items);
        String head = String.join(", ", l.subList(0, Math.min(max, l.size())));
        return l.size() > max ? head + " ほか" + (l.size() - max) + "件" : head;
    }

    static void print(Path jar, Decision d) {
        System.out.println((d.accepted() ? "[ACCEPT] " : "[REJECT] ") + jar);
        if (d.mainClass() != null) System.out.println("    main: " + d.mainClass());
        for (String r : d.reasons()) System.out.println("    - " + r);
    }
}
