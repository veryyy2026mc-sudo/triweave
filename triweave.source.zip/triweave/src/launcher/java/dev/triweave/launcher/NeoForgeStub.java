package dev.triweave.launcher;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Locale;
import java.util.Set;
import java.util.jar.Manifest;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

/**
 * NeoForge専用MODを、Mod Menu の一覧に表示するための「Fabric形式のスタブ」にする。
 *
 * <p>スタブは fabric.mod.json(と、あればアイコン)だけで、コードもmixinも含まない。
 * つまり <b>MODの機能は動かない</b>。idは {@code nf_} を前置するので、
 * 本物のFabric MODの依存関係を満たしてしまうことはなく、同名のFabric版とも衝突しない。
 */
final class NeoForgeStub {
    private NeoForgeStub() {}

    /** @return 生成したスタブjar。対象なし/同名のFabric・Quilt MODがある場合は null */
    static Path generate(Path jar, Path cacheDir, String twVersion, Set<String> takenIds, String reason) throws IOException {
        NeoForgeToml.Result toml;
        byte[] icon = null;
        String iconPath = null;
        try (ZipFile zf = new ZipFile(jar.toFile())) {
            ZipEntry te = zf.getEntry("META-INF/neoforge.mods.toml");
            if (te == null) return null;
            String manifestVersion = null;
            ZipEntry me = zf.getEntry("META-INF/MANIFEST.MF");
            if (me != null) {
                try (InputStream in = zf.getInputStream(me)) {
                    manifestVersion = new Manifest(in).getMainAttributes().getValue("Implementation-Version");
                }
            }
            try (InputStream in = zf.getInputStream(te)) {
                toml = NeoForgeToml.parse(new String(in.readAllBytes(), StandardCharsets.UTF_8), manifestVersion);
            }
            if (toml.mods().isEmpty()) return null;
            NeoForgeToml.Mod mod = toml.mods().get(0);
            if (takenIds.contains(mod.id())) {
                Log.info(jar.getFileName() + ": '" + mod.id() + "' already exists as a Fabric/Quilt mod; no ModMenu stub");
                return null;
            }
            if (mod.icon() != null) {
                ZipEntry ie = zf.getEntry(mod.icon());
                if (ie != null && !ie.isDirectory() && ie.getSize() < 2_000_000) {
                    try (InputStream in = zf.getInputStream(ie)) { icon = in.readAllBytes(); }
                    iconPath = mod.icon();
                }
            }

            String stubId = stubId(mod.id());
            if (!takenIds.add(stubId)) return null;

            Files.createDirectories(cacheDir);
            String stem = jar.getFileName().toString().replaceAll("(?i)\\.jar$", "");
            Path out = cacheDir.resolve(stem + "-" + sha1(jar).substring(0, 12) + "-nfstub-" + Integer.toHexString(String.valueOf(reason).hashCode()) + "-tw" + twVersion + ".jar");
            if (Files.isRegularFile(out)) return out;

            JsonObject f = new JsonObject();
            f.addProperty("schemaVersion", 1);
            f.addProperty("id", stubId);
            f.addProperty("version", safeVersion(mod.version()));
            f.addProperty("name", mod.name() + " [NeoForge]");
            String desc = "[Triweave] NeoForge用のMODです。動作せず、一覧表示のみです。" + (reason == null || reason.isBlank() ? "" : "\n理由: " + reason);
            f.addProperty("description", mod.description().isBlank() ? desc : desc + "\n" + mod.description());
            if (mod.authors() != null && !mod.authors().isBlank()) {
                JsonArray a = new JsonArray();
                for (String s : mod.authors().split(",")) if (!s.isBlank()) a.add(s.trim());
                f.add("authors", a);
            }
            JsonObject contact = new JsonObject();
            if (mod.url() != null && mod.url().startsWith("http")) contact.addProperty("homepage", mod.url());
            if (toml.issueTracker() != null && toml.issueTracker().startsWith("http"))
                contact.addProperty("issues", toml.issueTracker());
            if (contact.size() > 0) f.add("contact", contact);
            if (toml.license() != null) f.addProperty("license", toml.license());
            if (iconPath != null) f.addProperty("icon", iconPath);
            f.addProperty("environment", "*");
            JsonObject custom = new JsonObject();
            custom.addProperty("triweave:stub_for", "neoforge:" + mod.id());
            f.add("custom", custom);

            Path tmp = Files.createTempFile(cacheDir, "tw-", ".tmp");
            try {
                try (ZipOutputStream zos = new ZipOutputStream(Files.newOutputStream(tmp))) {
                    zos.putNextEntry(new ZipEntry("fabric.mod.json"));
                    zos.write(f.toString().getBytes(StandardCharsets.UTF_8));
                    zos.closeEntry();
                    if (icon != null) {
                        zos.putNextEntry(new ZipEntry(iconPath));
                        zos.write(icon);
                        zos.closeEntry();
                    }
                }
                Files.move(tmp, out, StandardCopyOption.REPLACE_EXISTING);
            } finally {
                Files.deleteIfExists(tmp);
            }
            return out;
        }
    }

    static String stubId(String modId) {
        String s = modId.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9_-]", "_");
        String id = "nf_" + s;
        return id.length() > 64 ? id.substring(0, 64) : id;
    }

    /** Fabricが解釈できる版表記にする(通常のsemver風ならそのまま)。 */
    static String safeVersion(String v) {
        if (v == null || v.isBlank()) return "0.0.0";
        if (v.matches("^\\d+(\\.\\d+){0,2}([-+][0-9A-Za-z.\\-+]*)?$")) return v;
        return "0.0.0+" + v.replaceAll("[^0-9A-Za-z.\\-]", "-");
    }

    private static String sha1(Path p) throws IOException {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-1");
            try (InputStream in = Files.newInputStream(p)) {
                byte[] buf = new byte[8192];
                for (int n; (n = in.read(buf)) > 0;) md.update(buf, 0, n);
            }
            StringBuilder sb = new StringBuilder();
            for (byte b : md.digest()) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new IOException(e);
        }
    }
}
