package dev.triweave.launcher;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.HashSet;
import java.util.Set;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Stream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

/** mods/ 内のjarを走査し、どのローダー向けかを判定する。展開はせずメタデータだけ読む(軽量)。 */
final class ModScanner {
    /** Triweave がOFFにしたjarの末尾(Modrinth等の .disabled とは区別する)。 */
    static final String OFF_SUFFIX = ".jar.triweave-off";

    private ModScanner() {}

    static List<ScannedMod> scan(Path modsDir) throws IOException {
        List<Path> jars;
        try (Stream<Path> s = Files.list(modsDir)) {
            jars = s.filter(Files::isRegularFile)
                    .filter(p -> { String n = p.getFileName().toString().toLowerCase(Locale.ROOT); return n.endsWith(".jar") || n.endsWith(OFF_SUFFIX); })
                    .sorted()
                    .toList();
        }
        List<ScannedMod> out = new ArrayList<>();
        for (Path jar : jars) {
            try {
                out.add(inspect(jar));
            } catch (IOException | RuntimeException e) {
                Log.warn("could not read " + jar.getFileName() + ": " + e);
            }
        }
        return out;
    }

    static ScannedMod inspect(Path jar) throws IOException {
        EnumSet<Kind> kinds = EnumSet.noneOf(Kind.class);
        String id = null, name = null, version = null;
        Set<String> depends = new HashSet<>();
        try (ZipFile zf = new ZipFile(jar.toFile())) {
            ZipEntry t = zf.getEntry("triweave.mod.json");          // 最優先
            if (t != null) {
                kinds.add(Kind.TRIWEAVE);
                JsonObject o = readJson(zf, t);
                if (o != null) {
                    id = str(o, "id");
                    name = str(o, "name");
                    version = str(o, "version");
                    JsonObject dep = obj(o, "depends");
                    if (dep != null) depends.addAll(dep.keySet());
                }
            }
            ZipEntry f = zf.getEntry("fabric.mod.json");
            if (f != null) {
                kinds.add(Kind.FABRIC);
                JsonObject o = readJson(zf, f);
                if (o != null) {
                    if (id == null) id = str(o, "id");
                    if (name == null) name = str(o, "name");
                    if (version == null) version = str(o, "version");
                    JsonObject dep = obj(o, "depends");
                    if (dep != null) depends.addAll(dep.keySet());
                }
            }
            ZipEntry q = zf.getEntry("quilt.mod.json");
            if (q != null) {
                kinds.add(Kind.QUILT);
                JsonObject o = readJson(zf, q);
                JsonObject ql = o == null ? null : obj(o, "quilt_loader");
                if (ql != null) {
                    if (id == null) id = str(ql, "id");
                    if (version == null) version = str(ql, "version");
                    JsonObject md = obj(ql, "metadata");
                    if (name == null && md != null) name = str(md, "name");
                }
            }
            ZipEntry n = zf.getEntry("META-INF/neoforge.mods.toml");
            if (n != null) {
                kinds.add(Kind.NEOFORGE);
                if (id == null) id = firstTomlValue(zf, n, "modId");
                if (name == null) name = firstTomlValue(zf, n, "displayName");
                if (version == null) version = firstTomlValue(zf, n, "version");
            }
            if (zf.getEntry("META-INF/mods.toml") != null) kinds.add(Kind.FORGE);
        }
        Kind chosen = Kind.UNKNOWN;
        for (Kind k : Kind.values()) {            // 宣言順 = 優先順位
            if (k != Kind.UNKNOWN && kinds.contains(k)) { chosen = k; break; }
        }
        // fabric.mod.json 併記の jar は Fabric が直接読み込むため、翻訳せず FABRIC として扱う
        // (triweave.mod.json は表示名・版などの情報として優先して使う)
        if (chosen == Kind.TRIWEAVE && kinds.contains(Kind.FABRIC)) chosen = Kind.FABRIC;
        boolean disabled = jar.getFileName().toString().toLowerCase(Locale.ROOT).endsWith(OFF_SUFFIX);
        return new ScannedMod(jar, id, name, version, kinds, chosen, disabled, depends);
    }

    private static JsonObject readJson(ZipFile zf, ZipEntry e) {
        try (Reader r = new InputStreamReader(zf.getInputStream(e), StandardCharsets.UTF_8)) {
            JsonElement el = JsonParser.parseReader(r);
            return el.isJsonObject() ? el.getAsJsonObject() : null;
        } catch (IOException | RuntimeException ex) {
            return null;
        }
    }

    private static JsonObject obj(JsonObject o, String k) {
        JsonElement e = o.get(k);
        return e != null && e.isJsonObject() ? e.getAsJsonObject() : null;
    }

    private static String str(JsonObject o, String k) {
        JsonElement e = o.get(k);
        return e != null && e.isJsonPrimitive() ? e.getAsString() : null;
    }

    private static String firstTomlValue(ZipFile zf, ZipEntry e, String key) {
        try (InputStream in = zf.getInputStream(e)) {
            String toml = new String(in.readAllBytes(), StandardCharsets.UTF_8);
            Matcher m = Pattern.compile("(?m)^\\s*" + key + "\\s*=\\s*\"([^\"]*)\"").matcher(toml);
            return m.find() ? m.group(1) : null;
        } catch (IOException | RuntimeException ex) {
            return null;
        }
    }
}
