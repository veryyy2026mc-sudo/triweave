package dev.triweave.launcher;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.HashSet;
import java.util.Set;

/**
 * Triweave の互換層(NeoForge / Bukkit)が提供するクラス・メンバーの一覧(ビルド時に自動生成)。
 * リソース名が違うだけで、NeoForge・Bukkitどちらの判定にも同じ実装を使う。
 */
final class ApiList {
    private final Set<String> classes = new HashSet<>();
    private final Set<String> members = new HashSet<>();

    private static final Set<String> OBJECT_METHODS =
            Set.of("equals", "hashCode", "toString", "getClass", "wait", "notify", "notifyAll");

    static ApiList load(String resourceName) {
        ApiList a = new ApiList();
        try (InputStream in = ApiList.class.getResourceAsStream("/triweave/" + resourceName)) {
            if (in == null) return a;
            try (BufferedReader r = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
                for (String l; (l = r.readLine()) != null;) {
                    if (l.startsWith("C ")) a.classes.add(l.substring(2));
                    else if (l.startsWith("M ")) a.members.add(l.substring(2));
                }
            }
        } catch (IOException e) {
            Log.warn("could not read " + resourceName + ": " + e);
        }
        return a;
    }

    boolean isEmpty() { return classes.isEmpty(); }

    boolean hasClass(String internalName) { return classes.contains(internalName); }

    boolean hasMember(String ownerDotNameColonDesc) {
        if (members.contains(ownerDotNameColonDesc)) return true;
        int dot = ownerDotNameColonDesc.lastIndexOf('.', ownerDotNameColonDesc.indexOf(':'));
        String name = ownerDotNameColonDesc.substring(dot + 1, ownerDotNameColonDesc.indexOf(':'));
        return OBJECT_METHODS.contains(name);
    }
}
