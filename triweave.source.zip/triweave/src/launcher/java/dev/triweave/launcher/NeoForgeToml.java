package dev.triweave.launcher;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** neoforge.mods.toml から、表示に必要な項目だけを取り出す最小パーサ(完全なTOMLではない)。 */
final class NeoForgeToml {
    record Mod(String id, String name, String version, String description, String authors,
               String icon, String url) {}

    record Result(String license, String issueTracker, List<Mod> mods, String modLoader,
                  boolean mixins, boolean accessTransformers, boolean kotlinDependency) {}

    private static final Pattern KV = Pattern.compile("^([A-Za-z0-9_.\\-]+)\\s*=\\s*(.*)$");

    private NeoForgeToml() {}

    static Result parse(String toml, String manifestVersion) {
        String[] lines = toml.replace("\r\n", "\n").replace('\r', '\n').split("\n", -1);
        Map<String, String> top = new HashMap<>();
        List<Map<String, String>> mods = new ArrayList<>();
        Map<String, String> current = top;   // null = 無関係なセクション
        boolean mixins = false, ats = false;

        for (int i = 0; i < lines.length; i++) {
            String line = lines[i].trim();
            if (line.isEmpty() || line.startsWith("#")) continue;
            if (line.startsWith("[")) {
                if (line.startsWith("[[mixins]]")) mixins = true;
                if (line.startsWith("[[accessTransformers]]")) ats = true;
                if (line.startsWith("[[mods]]")) {
                    current = new HashMap<>();
                    mods.add(current);
                } else {
                    current = null;
                }
                continue;
            }
            Matcher m = KV.matcher(line);
            if (!m.matches()) continue;
            String key = m.group(1);
            String rest = m.group(2).trim();

            String value;
            if (rest.startsWith("'''") || rest.startsWith("\"\"\"")) {
                String delim = rest.substring(0, 3);
                StringBuilder sb = new StringBuilder(rest.substring(3));
                int end = sb.indexOf(delim);
                while (end < 0 && i + 1 < lines.length) {
                    sb.append('\n').append(lines[++i]);
                    end = sb.indexOf(delim);
                }
                value = (end >= 0 ? sb.substring(0, end) : sb.toString()).trim();
            } else if (rest.startsWith("\"") || rest.startsWith("'")) {
                char q = rest.charAt(0);
                int end = rest.indexOf(q, 1);
                while (end > 0 && q == '"' && rest.charAt(end - 1) == '\\') end = rest.indexOf(q, end + 1);
                value = end > 0 ? rest.substring(1, end) : rest.substring(1);
            } else {
                int hash = rest.indexOf('#');
                value = (hash >= 0 ? rest.substring(0, hash) : rest).trim();
            }
            if (current != null) current.putIfAbsent(key, value);
        }

        List<Mod> out = new ArrayList<>();
        for (Map<String, String> mm : mods) {
            String id = mm.get("modId");
            if (id == null || id.isBlank()) continue;
            String version = mm.getOrDefault("version", "");
            if (version.startsWith("${")) version = manifestVersion == null ? "" : manifestVersion;
            String icon = mm.getOrDefault("logoFile", mm.get("iconFile"));
            out.add(new Mod(id, mm.getOrDefault("displayName", id), version,
                    mm.getOrDefault("description", ""), mm.get("authors"), icon, mm.get("displayURL")));
        }
        boolean kotlinDep = Pattern.compile("(?m)^\\s*modId\\s*=\\s*\"(kotlinforforge|kff)\"").matcher(toml).find();
        return new Result(top.get("license"), top.get("issueTrackerURL"), out, top.get("modLoader"),
                mixins, ats, kotlinDep);
    }
}
