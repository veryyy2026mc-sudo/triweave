package dev.triweave.launcher;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;

import com.google.gson.JsonObject;

/**
 * 受け入れ判定を通ったBukkitプラグインを、Fabricが読める jar にする(元のコードは一切変えない)。
 * fabric.mod.json を足し、main エントリポイントを {@code triweave-bukkit} アダプタに向ける。
 */
final class BukkitTranslator {
    private static final Pattern VERSION = Pattern.compile("(?m)^version:\\s*['\"]?([^'\"\\s]+)['\"]?\\s*$");
    private static final Pattern DESCRIPTION = Pattern.compile("(?m)^description:\\s*['\"]?(.*?)['\"]?\\s*$");

    private BukkitTranslator() {}

    static Path translate(Path jar, Path cacheDir, String twVersion, BukkitPolicy.Decision decision)
            throws IOException {
        Files.createDirectories(cacheDir);
        String stem = jar.getFileName().toString().replaceAll("(?i)\\.jar$", "");
        Path out = cacheDir.resolve(stem + "-" + sha1(jar).substring(0, 12) + "-tw" + twVersion + "-bkrun.jar");
        if (Files.isRegularFile(out)) return out;

        Path tmp = Files.createTempFile(cacheDir, "tw-", ".tmp");
        try {
            try (ZipFile zf = new ZipFile(jar.toFile()); OutputStream os = Files.newOutputStream(tmp);
                 ZipOutputStream zos = new ZipOutputStream(os)) {
                JsonObject fabric = buildJson(decision);
                Set<String> written = new HashSet<>();
                for (Enumeration<? extends ZipEntry> en = zf.entries(); en.hasMoreElements();) {
                    ZipEntry e = en.nextElement();
                    String n = e.getName();
                    if (n.equals("fabric.mod.json") || isSignature(n) || !written.add(n)) continue;
                    ZipEntry ne = new ZipEntry(n);
                    if (e.getTime() > 0) ne.setTime(e.getTime());
                    zos.putNextEntry(ne);
                    if (!e.isDirectory()) {
                        try (InputStream in = zf.getInputStream(e)) { in.transferTo(zos); }
                    }
                    zos.closeEntry();
                }
                zos.putNextEntry(new ZipEntry("fabric.mod.json"));
                zos.write(fabric.toString().getBytes(StandardCharsets.UTF_8));
                zos.closeEntry();
            }
            Files.move(tmp, out, StandardCopyOption.REPLACE_EXISTING);
        } finally {
            Files.deleteIfExists(tmp);
        }
        return out;
    }

    private static JsonObject buildJson(BukkitPolicy.Decision d) {
        String yml = d.pluginYml();
        String name = find(Pattern.compile("(?m)^name:\\s*['\"]?([^'\"\\s]+)['\"]?\\s*$"), yml, "plugin");
        String version = find(VERSION, yml, "0.0.0");
        String desc = find(DESCRIPTION, yml, "");

        JsonObject f = new JsonObject();
        f.addProperty("schemaVersion", 1);
        f.addProperty("id", fabricId(name));
        f.addProperty("version", NeoForgeStub.safeVersion(version));
        f.addProperty("name", name);
        String note = "[Triweave] Bukkit互換層で実行中(対応範囲は限定的。READMEを参照)";
        f.addProperty("description", desc.isBlank() ? note : note + "\n" + desc);
        f.addProperty("environment", "server");

        JsonObject eps = new JsonObject();
        com.google.gson.JsonArray mains = new com.google.gson.JsonArray();
        JsonObject ep = new JsonObject();
        ep.addProperty("adapter", "triweave-bukkit");
        ep.addProperty("value", d.mainClass());
        mains.add(ep);
        eps.add("main", mains);
        f.add("entrypoints", eps);

        JsonObject depends = new JsonObject();
        depends.addProperty("triweave", ">=0.1.0");
        f.add("depends", depends);

        JsonObject custom = new JsonObject();
        custom.addProperty("triweave:translated_from", "bukkit");
        f.add("custom", custom);
        return f;
    }

    private static String find(Pattern p, String text, String def) {
        Matcher m = p.matcher(text);
        return m.find() ? m.group(1) : def;
    }

    private static String fabricId(String name) {
        String s = "bk_" + name.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9_-]", "_");
        return s.length() > 64 ? s.substring(0, 64) : s;
    }

    private static boolean isSignature(String n) {
        String u = n.toUpperCase(Locale.ROOT);
        return u.startsWith("META-INF/") && !u.substring(9).contains("/")
                && (u.endsWith(".SF") || u.endsWith(".RSA") || u.endsWith(".DSA") || u.endsWith(".EC")
                    || u.startsWith("META-INF/SIG-"));
    }

    private static String sha1(Path p) throws IOException {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-1");
            try (InputStream in = Files.newInputStream(p)) {
                byte[] buf = new byte[8192];
                for (int n; (n = in.read(buf)) > 0;) md.update(buf, 0, n);
            }
            StringBuilder sb = new StringBuilder();
            for (byte b : md.digest()) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new IOException(e);
        }
    }
}
