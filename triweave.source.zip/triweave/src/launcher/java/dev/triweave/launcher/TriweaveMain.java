package dev.triweave.launcher;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;

/**
 * Triweave の入口。Minecraftのメインクラスとして指定される。
 * 準備(Bootstrap)が終わったら、通常のFabric(Knot)をそのまま起動する。
 *
 * <p>{@code java -jar triweave-x.y.z.jar install ...} のときはインストーラとして動く。
 */
public final class TriweaveMain {
    private static final String KNOT_CLIENT = "net.fabricmc.loader.impl.launch.knot.KnotClient";

    private TriweaveMain() {}

    public static void main(String[] args) throws Throwable {
        if (args.length > 0 && (args[0].equals("install") || args[0].equals("install-server") || args[0].equals("prepare") || args[0].equals("check"))) {
            InstallerLauncher.run(args[0], Arrays.copyOfRange(args, 1, args.length));
            return;
        }

        Path gameDir = resolveGameDir(args);
        try {
            Bootstrap.prepare(gameDir);
        } catch (Throwable t) {
            // 準備に失敗してもFabricとしては起動する(ゲームを止めない)
            Log.error("preparation failed; launching plain Fabric", t);
        }

        Method knotMain = Class.forName(KNOT_CLIENT).getMethod("main", String[].class);
        try {
            knotMain.invoke(null, (Object) args);
        } catch (InvocationTargetException e) {
            throw e.getCause() != null ? e.getCause() : e;
        }
    }

    private static Path resolveGameDir(String[] args) {
        for (int i = 0; i < args.length - 1; i++) {
            if (args[i].equals("--gameDir")) return Paths.get(args[i + 1]).toAbsolutePath();
        }
        return Paths.get(System.getProperty("user.dir")).toAbsolutePath();
    }
}
