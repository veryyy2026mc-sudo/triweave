package dev.triweave.launcher;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.List;
import java.util.Properties;

/**
 * 起動時に、mods/ に Fabric API と Mod Menu(MOD版)が無ければ、同梱jarを直接設置する。
 * 既に同じidのMODがあれば何もしない。
 */
final class FabricApiInstaller {
    private static final String RES_PROPS = "/triweave/bundled.properties";

    /** {id, 同梱リソース, propertiesのキー, ファイル名の前半} */
    private static final String[][] BUNDLED = {
            {"fabric-api", "/triweave/fabric-api.jar", "fabric_api_version", "fabric-api-"},
            {"modmenu", "/triweave/modmenu.jar", "modmenu_version", "modmenu-"},
    };

    private FabricApiInstaller() {}

    /** @return 1つでも新しく設置したら true(呼び出し側で再走査する) */
    static boolean ensure(Path modsDir, List<ScannedMod> scanned, java.util.Set<String> off, boolean server) throws IOException {
        Properties props = new Properties();
        try (InputStream ps = FabricApiInstaller.class.getResourceAsStream(RES_PROPS)) {
            if (ps != null) props.load(ps);
        }

        boolean installed = false;
        for (String[] b : BUNDLED) {
            String id = b[0];
            if (off.contains(id)) continue;                  // ユーザーがOFFにした
            if (server && id.equals("modmenu")) continue;    // Mod Menu はクライアント用
            boolean present = scanned.stream()
                    .anyMatch(m -> id.equals(m.id()) && m.kinds().contains(Kind.FABRIC));
            if (present) {
                Log.info(id + " found; bundled copy not needed");
                continue;
            }
            String version = props.getProperty(b[2], "bundled");
            Path target = modsDir.resolve(b[3] + version + ".jar");
            try (InputStream in = FabricApiInstaller.class.getResourceAsStream(b[1])) {
                if (in == null) {
                    Log.warn(id + " is missing and no bundled copy was found in this build.");
                    continue;
                }
                Path tmp = Files.createTempFile(modsDir, b[3], ".tmp");
                try {
                    Files.copy(in, tmp, StandardCopyOption.REPLACE_EXISTING);
                    Files.move(tmp, target, StandardCopyOption.REPLACE_EXISTING);
                } finally {
                    Files.deleteIfExists(tmp);
                }
            }
            Log.info("Installed bundled " + id + " -> " + target.getFileName());
            installed = true;
        }
        return installed;
    }
}
