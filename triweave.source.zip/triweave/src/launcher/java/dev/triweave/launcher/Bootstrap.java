package dev.triweave.launcher;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Locale;
import java.nio.file.StandardCopyOption;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Stream;

/**
 * Fabric Loader(Knot)起動前の準備。
 *
 * <ol>
 *   <li>Fabric APIが無ければ同梱版を mods/ に設置</li>
 *   <li>mods/ を走査し、ローダー種別を判定(FABRIC &gt; QUILT &gt; NEOFORGE)</li>
 *   <li>Quilt専用MODを変換してキャッシュへ出力</li>
 *   <li>NeoForge専用MODを検出(現状はスキップして報告)</li>
 *   <li>変換済みjarとTriweave MOD本体を {@code fabric.addMods} でLoaderに渡す</li>
 * </ol>
 */
final class Bootstrap {
    private static final String ADD_MODS = "fabric.addMods";

    private Bootstrap() {}

    static String version() {
        String v = Bootstrap.class.getPackage().getImplementationVersion();
        return v == null ? "dev" : v;
    }

    /** 生成物(mods/内に書き出す変換済みjar)の目印。ユーザーのjarとは区別して扱う。 */
    static final String GENERATED_PREFIX = "__triweave_";

    static void prepare(Path gameDir) throws IOException {
        prepare(gameDir, false);
    }

    /**
     * @param inPlace true なら fabric.addMods を使わず、変換済みjarとTriweave本体を mods/ に書き出す
     *                (Modrinth App等、起動クラスを差し替えられないランチャー向け)
     */
    static void prepare(Path gameDir, boolean inPlace) throws IOException {
        Path mods = gameDir.resolve("mods");
        Path work = gameDir.resolve(".triweave");
        Path cache = work.resolve("cache");
        Files.createDirectories(mods);
        Files.createDirectories(cache);

        boolean server = Files.exists(gameDir.resolve("fabric-server-launcher.properties"))
                || Files.exists(gameDir.resolve("server.properties")) || Files.exists(gameDir.resolve("eula.txt"));
        if (server) Log.info("dedicated server detected");
        Set<String> off = ModState.loadOff(work);
        List<ScannedMod> disabledMods = new ArrayList<>();
        List<ScannedMod> scanned = applyState(mods, scanAll(mods), off, disabledMods);
        if (FabricApiInstaller.ensure(mods, scanned, off, server)) {
            scanned = applyState(mods, scanAll(mods), off, disabledMods); // 設置後に再走査
        }

        Set<String> fabricIds = new HashSet<>();
        java.util.Map<String, List<String>> byId = new java.util.TreeMap<>();
        for (ScannedMod m : scanned) {
            if (m.chosen() == Kind.FABRIC && m.id() != null) {
                fabricIds.add(m.id());
                byId.computeIfAbsent(m.id(), k -> new ArrayList<>()).add(m.path().getFileName().toString());
            }
        }
        for (var e : byId.entrySet()) {
            if (e.getValue().size() > 1) {
                Log.warn("DUPLICATE mod id '" + e.getKey() + "': " + e.getValue()
                        + " - Fabric will refuse to start. Remove all but one.");
            }
        }

        List<Path> extra = new ArrayList<>();
        Set<Path> usedCache = new HashSet<>();
        List<ScannedMod> neoOnly = new ArrayList<>();
        int nFabric = 0, nQuilt = 0, nQuiltFail = 0, nStub = 0, nNeoRun = 0, nTriweave = 0;
        Set<String> taken = new HashSet<>(fabricIds);

        // Triweave MOD本体(mods/ に既にあれば不要)
        if (!fabricIds.contains("triweave")) {
            extra.add(extractModJar(work));
        }

        for (ScannedMod m : scanned) {
            switch (m.chosen()) {
                case FABRIC -> {
                    nFabric++;
                    if (m.kinds().size() > 1) {
                        Log.info(m.path().getFileName() + ": multi-loader " + m.kinds() + " -> run as FABRIC");
                    }
                }
                case TRIWEAVE -> {
                    if (m.id() != null && fabricIds.contains(m.id())) {
                        Log.warn(m.path().getFileName() + ": id '" + m.id()
                                + "' is already provided by a Fabric mod; skipped");
                        continue;
                    }
                    if (m.kinds().size() > 1) {
                        Log.info(m.path().getFileName() + ": triweave.mod.json takes priority over " + m.kinds());
                    }
                    try {
                        Path out = TriweaveTranslator.translate(m.path(), cache, version());
                        extra.add(out);
                        usedCache.add(out);
                        if (m.id() != null) taken.add(m.id());
                        nTriweave++;
                    } catch (IOException | RuntimeException e) {
                        Log.error("failed to load Triweave mod " + m.path().getFileName(), e);
                    }
                }
                case QUILT -> {
                    if (m.id() != null && fabricIds.contains(m.id())) {
                        Log.warn(m.path().getFileName() + ": id '" + m.id()
                                + "' is already provided by a Fabric mod; skipped");
                        continue;
                    }
                    if (m.kinds().size() > 1) {
                        Log.info(m.path().getFileName() + ": multi-loader " + m.kinds() + " -> run as QUILT (translated)");
                    }
                    try {
                        Path out = QuiltTranslator.translate(m.path(), cache, version());
                        extra.add(out);
                        usedCache.add(out);
                        if (m.id() != null) taken.add(m.id());
                        nQuilt++;
                    } catch (IOException | RuntimeException e) {
                        nQuiltFail++;
                        Log.error("failed to translate " + m.path().getFileName(), e);
                    }
                }
                case NEOFORGE -> neoOnly.add(m);
                case FORGE -> Log.warn(m.path().getFileName() + ": legacy Forge mod is not supported");
                default -> { /* ライブラリ等。何もしない */ }
            }
        }

        java.util.Map<Path, String> neoNotes = new java.util.HashMap<>();
        ApiList api = ApiList.load("neoforge-api.txt");
        for (ScannedMod m : neoOnly) {
            NeoForgePolicy.Decision d = NeoForgePolicy.evaluate(m.path(), api);
            String file = m.path().getFileName().toString();
            String reason = String.join(" / ", d.reasons());
            if (d.accepted() && m.id() != null && taken.contains(m.id())) {
                d = new NeoForgePolicy.Decision(false, java.util.List.of("同じidのMODが既にあります"), d.modClasses());
                reason = "同じidのMODが既にあります";
            }
            if (d.accepted()) {
                try {
                    Path out = NeoForgeTranslator.translate(m.path(), cache, version(), d);
                    extra.add(out);
                    usedCache.add(out);
                    if (m.id() != null) taken.add(m.id());
                    nNeoRun++;
                    neoNotes.put(m.path(), "running via Triweave NeoForge compat layer");
                    Log.info("NeoForge mod accepted (compat layer): " + file + " " + d.modClasses());
                    continue;
                } catch (IOException | RuntimeException e) {
                    reason = "翻訳に失敗: " + e;
                    Log.error("failed to translate NeoForge mod " + file, e);
                }
            }
            Log.warn("NeoForge mod NOT running: " + file + " - " + reason);
            neoNotes.put(m.path(), "rejected: " + reason);
            if (server) continue;                      // サーバーには Mod Menu が無いのでスタブ不要
            try {                                      // Mod Menu 用の一覧スタブ(機能は動かない)
                Path stub = NeoForgeStub.generate(m.path(), cache, version(), taken, reason);
                if (stub != null) {
                    extra.add(stub);
                    usedCache.add(stub);
                    nStub++;
                }
            } catch (IOException | RuntimeException e) {
                Log.warn("could not create ModMenu stub for " + file + ": " + e);
            }
        }
        List<ScannedMod> listed = new ArrayList<>(scanned);
        listed.addAll(disabledMods);
        String plugins = scanPlugins(gameDir.resolve("plugins"), cache, extra, usedCache);
        writeModList(work, listed, neoNotes, plugins);
        pruneCache(cache, usedCache);

        if (inPlace) {
            Set<Path> keep = new HashSet<>();
            for (Path p : extra) {
                String name = p.getFileName().toString().equals("triweave-mod.jar")
                        ? GENERATED_PREFIX + "core.jar" : GENERATED_PREFIX + p.getFileName();
                Path dest = mods.resolve(name);
                Files.copy(p, dest, StandardCopyOption.REPLACE_EXISTING);
                keep.add(dest);
            }
            pruneGenerated(mods, keep);
        } else {
            pruneGenerated(mods, Set.of());
        }

        if (!inPlace && !extra.isEmpty()) {
            List<String> parts = new ArrayList<>();
            String prev = System.getProperty(ADD_MODS);
            if (prev != null && !prev.isBlank()) parts.add(prev);
            for (Path p : extra) parts.add(p.toAbsolutePath().toString());
            System.setProperty(ADD_MODS, String.join(File.pathSeparator, parts));
        }

        Log.info("Triweave " + version() + ": triweave=" + nTriweave + ", fabric=" + nFabric + ", quilt(translated)=" + nQuilt
                + (nQuiltFail > 0 ? " (failed=" + nQuiltFail + ")" : "")
                + ", neoforge(running)=" + nNeoRun + ", neoforge(rejected)=" + (neoOnly.size() - nNeoRun)
                + " (ModMenu stubs=" + nStub + ")");
    }

    /** 同梱のTriweave MOD jar を .triweave/ に展開(内容が同じなら書き換えない)。 */
    private static Path extractModJar(Path work) throws IOException {
        Path target = work.resolve("triweave-mod.jar");
        try (InputStream in = Bootstrap.class.getResourceAsStream("/triweave/triweave-mod.jar")) {
            if (in == null) {
                throw new IOException("embedded triweave-mod.jar not found; use the jar built by 'gradle build' (launcherJar)");
            }
            byte[] data = in.readAllBytes();
            if (!Files.isRegularFile(target) || !Arrays.equals(sha256(Files.readAllBytes(target)), sha256(data))) {
                Files.write(target, data);
            }
        }
        return target;
    }

    private static byte[] sha256(byte[] b) throws IOException {
        try {
            return MessageDigest.getInstance("SHA-256").digest(b);
        } catch (java.security.NoSuchAlgorithmException e) {
            throw new IOException(e);
        }
    }

    private static List<ScannedMod> scanAll(Path mods) throws IOException {
        List<ScannedMod> l = new ArrayList<>(ModScanner.scan(mods));
        l.removeIf(m -> m.path().getFileName().toString().startsWith(GENERATED_PREFIX));
        return l;
    }

    /**
     * /mod <名前> on|off の指定を、実際のファイルに反映する。
     * OFF = 拡張子を .jar.triweave-off にする / ON = 元に戻す。他のMODが必要としているMODはOFFにしない。
     *
     * @return 有効なMODの一覧(OFFにされたものは disabledMods に入る)
     */
    private static List<ScannedMod> applyState(Path mods, List<ScannedMod> all, Set<String> off,
            List<ScannedMod> disabledMods) {
        disabledMods.clear();
        List<ScannedMod> active = new ArrayList<>();
        for (ScannedMod m : all) {
            String id = m.id();
            boolean wantOff = id != null && off.contains(id) && !ModState.isProtected(id);
            if (wantOff && !m.disabled()) {
                String blocker = null;
                for (ScannedMod o : all) {
                    if (o != m && !o.disabled() && o.depends().contains(id)
                            && !(o.id() != null && off.contains(o.id()))) { blocker = o.id(); break; }
                }
                if (blocker != null) {
                    Log.warn("cannot disable '" + id + "': required by '" + blocker + "' (kept ON)");
                    active.add(m);
                    continue;
                }
                Path to = m.path().resolveSibling(m.path().getFileName().toString() + ".triweave-off");
                try {
                    Files.move(m.path(), to, StandardCopyOption.REPLACE_EXISTING);
                    Log.info("disabled (Triweave): " + m.path().getFileName());
                    disabledMods.add(new ScannedMod(to, m.id(), m.name(), m.version(), m.kinds(), m.chosen(), true, m.depends()));
                } catch (IOException e) {
                    Log.warn("could not disable " + m.path().getFileName() + ": " + e);
                    active.add(m);
                }
            } else if (!wantOff && m.disabled()) {
                String n = m.path().getFileName().toString();
                Path back = m.path().resolveSibling(n.substring(0, n.length() - ModScanner.OFF_SUFFIX.length()) + ".jar");
                try {
                    Files.move(m.path(), back, StandardCopyOption.REPLACE_EXISTING);
                    Log.info("re-enabled (Triweave): " + back.getFileName());
                    active.add(new ScannedMod(back, m.id(), m.name(), m.version(), m.kinds(), m.chosen(), false, m.depends()));
                } catch (IOException e) {
                    Log.warn("could not re-enable " + n + ": " + e);
                    disabledMods.add(m);
                }
            } else if (m.disabled()) {
                disabledMods.add(m);
            } else {
                active.add(m);
            }
        }
        return active;
    }

    /** ゲーム内の /mod コマンドが読む一覧(TSV: kind, id, name, version, file, note)。 */
    private static void writeModList(Path work, List<ScannedMod> scanned, java.util.Map<Path, String> neoNotes,
            String extraLines) {
        StringBuilder sb = new StringBuilder();
        for (ScannedMod m : scanned) {
            String kind;
            String note = "";
            if (m.disabled()) {
                switch (m.chosen()) {
                    case TRIWEAVE -> kind = "triweave";
                    case FABRIC -> kind = "fabric";
                    case QUILT -> kind = "quilt";
                    case NEOFORGE -> kind = "neoforge";
                    default -> { continue; }
                }
                String d = m.id() == null ? "" : m.id();
                String dn = m.name() == null || m.name().isBlank() ? (d.isEmpty() ? m.path().getFileName().toString() : d) : m.name();
                sb.append(kind).append('\t').append(tsv(d)).append('\t').append(tsv(dn)).append('\t')
                  .append(tsv(m.version())).append('\t').append(tsv(m.path().getFileName().toString()))
                  .append('\t').append("disabled by Triweave").append('\n');
                continue;
            }
            switch (m.chosen()) {
                case TRIWEAVE -> {
                    kind = "triweave";
                    note = m.kinds().size() > 1 ? "triweave.mod.json priority; also " + m.kinds() : "";
                }
                case FABRIC -> {
                    kind = "fabric";
                    if (m.kinds().size() > 1) note = "multi-loader " + m.kinds();
                }
                case QUILT -> {
                    kind = "quilt";
                    note = m.kinds().size() > 1 ? "translated; multi-loader " + m.kinds() : "translated";
                }
                case NEOFORGE -> {
                    kind = "neoforge";
                    note = neoNotes.getOrDefault(m.path(), "");
                }
                default -> { continue; }
            }
            String file = m.path().getFileName().toString();
            String id = m.id() == null ? "" : m.id();
            String name = m.name() == null || m.name().isBlank() ? (id.isEmpty() ? file : id) : m.name();
            sb.append(kind).append('\t').append(tsv(id)).append('\t').append(tsv(name)).append('\t')
              .append(tsv(m.version() != null && m.version().startsWith("${") ? "" : m.version())).append('\t').append(tsv(file)).append('\t').append(tsv(note)).append('\n');
        }
        sb.append(extraLines);
        try {
            Files.writeString(work.resolve("modlist.tsv"), sb.toString(), java.nio.charset.StandardCharsets.UTF_8);
        } catch (IOException e) {
            Log.warn("could not write modlist.tsv: " + e);
        }
    }

    /**
     * plugins/ の Bukkit/Spigot/Paper プラグインを判定する。受け入れたものは互換層用に翻訳して
     * extra(Fabricへ渡すjarの一覧)に加える。拒否したものは理由付きで modlist 用の行を返す。
     */
    private static String scanPlugins(Path pluginsDir, Path cache, List<Path> extra, Set<Path> usedCache) {
        if (!Files.isDirectory(pluginsDir)) return "";
        ApiList api = ApiList.load("bukkit-api.txt");
        StringBuilder sb = new StringBuilder();
        try (Stream<Path> st = Files.list(pluginsDir)) {
            for (Path jar : st.filter(p -> p.getFileName().toString().toLowerCase().endsWith(".jar")).sorted().toList()) {
                if (!BukkitPolicy.isPlugin(jar)) continue;
                BukkitPolicy.Decision d = BukkitPolicy.evaluate(jar, api);
                String id = "bk_" + jar.getFileName().toString().toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9_-]", "_");
                if (d.accepted()) {
                    try {
                        Path out = BukkitTranslator.translate(jar, cache, version(), d);
                        extra.add(out);
                        usedCache.add(out);
                        Log.info("Bukkit plugin accepted (compat layer, scope limited): " + jar.getFileName());
                        sb.append("bukkit\t").append(id).append('\t').append(jar.getFileName()).append("\t\t")
                          .append(jar.getFileName()).append("\trunning via Triweave Bukkit compat layer\n");
                        continue;
                    } catch (IOException | RuntimeException e) {
                        Log.error("failed to translate Bukkit plugin " + jar.getFileName(), e);
                        d = new BukkitPolicy.Decision(false, List.of("翻訳に失敗: " + e), d.mainClass(), d.pluginYml());
                    }
                }
                String reason = String.join(" / ", d.reasons());
                Log.warn("Bukkit/Paper plugin NOT running: " + jar.getFileName() + " - " + reason);
                sb.append("bukkit\t").append(id).append('\t').append(jar.getFileName()).append("\t\t")
                  .append(jar.getFileName()).append("\trejected: ").append(tsv(reason)).append('\n');
            }
        } catch (IOException e) {
            Log.warn("could not scan plugins/: " + e);
        }
        return sb.toString();
    }

    private static String tsv(String s) {
        return s == null ? "" : s.replace('\t', ' ').replace('\n', ' ').replace('\r', ' ');
    }

    private static void pruneGenerated(Path mods, Set<Path> keep) {
        try (Stream<Path> s = Files.list(mods)) {
            for (Path p : s.filter(x -> x.getFileName().toString().startsWith(GENERATED_PREFIX)).toList()) {
                if (!keep.contains(p)) Files.deleteIfExists(p);
            }
        } catch (IOException ignored) {
            // 掃除に失敗しても起動には影響しない
        }
    }

    private static void pruneCache(Path cache, Set<Path> keep) {
        try (Stream<Path> s = Files.list(cache)) {
            for (Path p : s.filter(x -> x.getFileName().toString().endsWith(".jar")).toList()) {
                if (!keep.contains(p)) Files.deleteIfExists(p);
            }
        } catch (IOException ignored) {
            // 掃除に失敗しても起動には影響しない
        }
    }
}
