package dev.triweave.launcher;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonPrimitive;

/**
 * triweave.mod.json を fabric.mod.json に変換して、Fabric が読める jar を作る。
 * jar 内の他のメタデータ(quilt.mod.json / neoforge.mods.toml)は無視される(= triweave.mod.json が優先)。
 */
final class TriweaveTranslator {
    static final String ADAPTER = "triweave";
    static final String NEOFORGE_ADAPTER = "triweave-neoforge";

    private TriweaveTranslator() {}

    static Path translate(Path jar, Path cacheDir, String twVersion) throws IOException {
        Files.createDirectories(cacheDir);
        String stem = jar.getFileName().toString().replaceAll("(?i)\\.jar$", "");
        Path out = cacheDir.resolve(stem + "-" + sha1(jar).substring(0, 12) + "-tw" + twVersion + "-tmj.jar");
        if (Files.isRegularFile(out)) return out;

        Path tmp = Files.createTempFile(cacheDir, "tw-", ".tmp");
        try {
            try (ZipFile zf = new ZipFile(jar.toFile()); OutputStream os = Files.newOutputStream(tmp);
                 ZipOutputStream zos = new ZipOutputStream(os)) {
                ZipEntry te = zf.getEntry("triweave.mod.json");
                if (te == null) throw new IOException("triweave.mod.json not found");
                JsonObject src;
                try (Reader r = new InputStreamReader(zf.getInputStream(te), StandardCharsets.UTF_8)) {
                    src = JsonParser.parseReader(r).getAsJsonObject();
                }
                JsonObject fabric = convert(src);

                Set<String> written = new HashSet<>();
                for (Enumeration<? extends ZipEntry> en = zf.entries(); en.hasMoreElements();) {
                    ZipEntry e = en.nextElement();
                    String n = e.getName();
                    if (n.equals("fabric.mod.json") || isSignature(n) || !written.add(n)) continue;
                    ZipEntry ne = new ZipEntry(n);
                    if (e.getTime() > 0) ne.setTime(e.getTime());
                    zos.putNextEntry(ne);
                    if (!e.isDirectory()) {
                        try (InputStream in = zf.getInputStream(e)) { in.transferTo(zos); }
                    }
                    zos.closeEntry();
                }
                zos.putNextEntry(new ZipEntry("fabric.mod.json"));
                zos.write(fabric.toString().getBytes(StandardCharsets.UTF_8));
                zos.closeEntry();
            }
            Files.move(tmp, out, StandardCopyOption.REPLACE_EXISTING);
        } finally {
            Files.deleteIfExists(tmp);
        }
        return out;
    }

    /** triweave.mod.json (schema_version 1) → fabric.mod.json */
    static JsonObject convert(JsonObject t) throws IOException {
        String id = str(t, "id"), version = str(t, "version");
        if (id == null || version == null) throw new IOException("triweave.mod.json needs \"id\" and \"version\"");

        JsonObject f = new JsonObject();
        f.addProperty("schemaVersion", 1);
        f.addProperty("id", id);
        f.addProperty("version", version);
        for (String k : new String[] {"name", "description", "environment", "license", "icon", "accessWidener"}) {
            JsonElement e = t.get(k.equals("accessWidener") ? "access_widener" : k);
            if (e != null && (e.isJsonPrimitive() || (k.equals("icon") && e.isJsonObject()) || k.equals("license"))) f.add(k, e);
        }
        if (!f.has("environment")) f.addProperty("environment", "*");
        for (String k : new String[] {"authors", "contributors", "contact", "provides", "jars", "mixins",
                                       "suggests", "recommends", "breaks", "conflicts"}) {
            JsonElement e = t.get(k);
            if (e != null && !e.isJsonNull()) f.add(k, e);
        }

        // entrypoints: neoforge は NeoForge 互換層、それ以外は triweave アダプタ(Fabric/Quilt形式のクラスも可)
        JsonObject eps = new JsonObject();
        JsonObject src = obj(t, "entrypoints");
        if (src != null) {
            for (Map.Entry<String, JsonElement> en : src.entrySet()) {
                boolean neo = en.getKey().equals("neoforge");
                String key = neo ? "main" : en.getKey();
                JsonArray target = eps.has(key) ? eps.getAsJsonArray(key) : new JsonArray();
                for (JsonElement v : list(en.getValue())) {
                    String value, adapter = neo ? NEOFORGE_ADAPTER : ADAPTER;
                    if (v.isJsonPrimitive()) value = v.getAsString();
                    else if (v.isJsonObject()) {
                        value = str(v.getAsJsonObject(), "value");
                        String a = str(v.getAsJsonObject(), "adapter");
                        if (a != null && !a.equals("default")) adapter = a;
                    } else continue;
                    if (value == null) continue;
                    JsonObject o = new JsonObject();
                    o.addProperty("adapter", adapter);
                    o.addProperty("value", value);
                    target.add(o);
                }
                if (target.size() > 0) eps.add(key, target);
            }
        }
        if (eps.size() > 0) f.add("entrypoints", eps);

        JsonObject depends = obj(t, "depends") != null ? obj(t, "depends").deepCopy() : new JsonObject();
        if (!depends.has("triweave")) depends.addProperty("triweave", ">=0.1.0");
        f.add("depends", depends);

        JsonElement acc = t.get("access_widener");
        if (acc != null && acc.isJsonPrimitive()) f.add("accessWidener", acc);

        JsonObject custom = new JsonObject();
        custom.addProperty("triweave:translated_from", "triweave");
        f.add("custom", custom);
        return f;
    }

    private static JsonObject obj(JsonObject o, String k) {
        JsonElement e = o.get(k);
        return e != null && e.isJsonObject() ? e.getAsJsonObject() : null;
    }

    private static String str(JsonObject o, String k) {
        JsonElement e = o.get(k);
        return e != null && e.isJsonPrimitive() ? e.getAsString() : null;
    }

    private static List<JsonElement> list(JsonElement e) {
        java.util.ArrayList<JsonElement> out = new java.util.ArrayList<>();
        if (e == null || e.isJsonNull()) return out;
        if (e.isJsonArray()) e.getAsJsonArray().forEach(out::add); else out.add(e);
        return out;
    }

    private static boolean isSignature(String n) {
        String u = n.toUpperCase(Locale.ROOT);
        return u.startsWith("META-INF/") && !u.substring(9).contains("/")
                && (u.endsWith(".SF") || u.endsWith(".RSA") || u.endsWith(".DSA") || u.endsWith(".EC")
                    || u.startsWith("META-INF/SIG-"));
    }

    private static String sha1(Path p) throws IOException {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-1");
            try (InputStream in = Files.newInputStream(p)) {
                byte[] buf = new byte[8192];
                for (int n; (n = in.read(buf)) > 0;) md.update(buf, 0, n);
            }
            StringBuilder sb = new StringBuilder();
            for (byte b : md.digest()) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new IOException(e);
        }
    }
}
