package com.mojang.brigadier.builder; public abstract class ArgumentBuilder<S,T extends ArgumentBuilder<S,T>> {
 public T executes(com.mojang.brigadier.Command<S> c){return null;} public T then(ArgumentBuilder<S,?> a){return null;}
 public T requires(java.util.function.Predicate<S> r){return null;} }
