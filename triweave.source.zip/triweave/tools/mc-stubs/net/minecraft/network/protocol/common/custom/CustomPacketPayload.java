package net.minecraft.network.protocol.common.custom; public interface CustomPacketPayload { class Type<T> {} }
