package net.minecraft.network.chat; public interface Component { static MutableComponent literal(String s){return null;} }
