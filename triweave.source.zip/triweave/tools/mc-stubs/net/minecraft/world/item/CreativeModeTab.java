package net.minecraft.world.item; public class CreativeModeTab {
  public interface Output { void accept(ItemStack s, TabVisibility v); }
  public static class ItemDisplayParameters {}
  public enum TabVisibility { PARENT_AND_SEARCH_TABS }
}
