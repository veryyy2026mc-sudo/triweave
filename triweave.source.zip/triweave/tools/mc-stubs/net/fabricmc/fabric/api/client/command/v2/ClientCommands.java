package net.fabricmc.fabric.api.client.command.v2; public final class ClientCommands {
 public static com.mojang.brigadier.builder.LiteralArgumentBuilder<FabricClientCommandSource> literal(String s){return null;}
 public static <T> com.mojang.brigadier.builder.RequiredArgumentBuilder<FabricClientCommandSource,T> argument(String n, com.mojang.brigadier.arguments.ArgumentType<T> t){return null;} }
