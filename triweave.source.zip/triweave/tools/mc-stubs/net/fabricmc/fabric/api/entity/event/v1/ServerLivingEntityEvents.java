package net.fabricmc.fabric.api.entity.event.v1;
import net.fabricmc.fabric.api.event.Event;
public final class ServerLivingEntityEvents {
  public static final Event<AllowDeath> ALLOW_DEATH = null;
  public static final Event<AfterDeath> AFTER_DEATH = null;
  public interface AllowDeath { boolean allowDeath(net.minecraft.world.entity.LivingEntity entity, net.minecraft.world.damagesource.DamageSource source, float amount); }
  public interface AfterDeath { void afterDeath(net.minecraft.world.entity.LivingEntity entity, net.minecraft.world.damagesource.DamageSource source); }
}
