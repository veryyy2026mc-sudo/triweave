package net.fabricmc.fabric.api.event.lifecycle.v1;
import net.fabricmc.fabric.api.event.Event;
public final class ServerTickEvents {
  public static final Event<StartTick> START_SERVER_TICK = null;
  public static final Event<EndTick> END_SERVER_TICK = null;
  public interface StartTick { void onStartTick(net.minecraft.server.MinecraftServer server); }
  public interface EndTick { void onEndTick(net.minecraft.server.MinecraftServer server); }
}
