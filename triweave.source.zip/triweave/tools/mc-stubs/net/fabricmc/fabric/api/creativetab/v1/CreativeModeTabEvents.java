package net.fabricmc.fabric.api.creativetab.v1;
import net.fabricmc.fabric.api.event.Event;
public final class CreativeModeTabEvents {
  public static final Event<ModifyOutputAll> MODIFY_OUTPUT_ALL = null;
  public interface ModifyOutputAll { void modifyOutput(net.minecraft.world.item.CreativeModeTab tab, FabricCreativeModeTabOutput output); }
}
