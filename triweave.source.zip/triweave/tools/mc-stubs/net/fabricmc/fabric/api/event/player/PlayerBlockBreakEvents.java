package net.fabricmc.fabric.api.event.player;
import net.fabricmc.fabric.api.event.Event;
public final class PlayerBlockBreakEvents {
  public static final Event<Before> BEFORE = null;
  public static final Event<After> AFTER = null;
  public interface Before { boolean beforeBlockBreak(net.minecraft.world.level.Level level, net.minecraft.world.entity.player.Player player, net.minecraft.core.BlockPos pos, net.minecraft.world.level.block.state.BlockState state, net.minecraft.world.level.block.entity.BlockEntity blockEntity); }
  public interface After { void afterBlockBreak(net.minecraft.world.level.Level level, net.minecraft.world.entity.player.Player player, net.minecraft.core.BlockPos pos, net.minecraft.world.level.block.state.BlockState state, net.minecraft.world.level.block.entity.BlockEntity blockEntity); }
}
