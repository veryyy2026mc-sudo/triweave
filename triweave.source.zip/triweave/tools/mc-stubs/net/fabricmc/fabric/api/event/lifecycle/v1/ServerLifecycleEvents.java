package net.fabricmc.fabric.api.event.lifecycle.v1;
import net.fabricmc.fabric.api.event.Event;
public final class ServerLifecycleEvents {
  public static final Event<ServerStarting> SERVER_STARTING = null;
  public static final Event<ServerStarted> SERVER_STARTED = null;
  public static final Event<ServerStopping> SERVER_STOPPING = null;
  public static final Event<ServerStopped> SERVER_STOPPED = null;
  public interface ServerStarting { void onServerStarting(net.minecraft.server.MinecraftServer s); }
  public interface ServerStarted { void onServerStarted(net.minecraft.server.MinecraftServer s); }
  public interface ServerStopping { void onServerStopping(net.minecraft.server.MinecraftServer s); }
  public interface ServerStopped { void onServerStopped(net.minecraft.server.MinecraftServer s); } }
