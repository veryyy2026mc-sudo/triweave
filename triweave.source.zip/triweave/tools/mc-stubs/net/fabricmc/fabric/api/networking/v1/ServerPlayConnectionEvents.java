package net.fabricmc.fabric.api.networking.v1;
import net.fabricmc.fabric.api.event.Event;
public final class ServerPlayConnectionEvents {
  public static final Event<Join> JOIN = null;
  public static final Event<Disconnect> DISCONNECT = null;
  public interface Join { void onPlayReady(net.minecraft.server.network.ServerGamePacketListenerImpl h, PacketSender s, net.minecraft.server.MinecraftServer srv); }
  public interface Disconnect { void onPlayDisconnect(net.minecraft.server.network.ServerGamePacketListenerImpl h, net.minecraft.server.MinecraftServer srv); } }
