package net.fabricmc.fabric.api.creativetab.v1;
public class FabricCreativeModeTabOutput implements net.minecraft.world.item.CreativeModeTab.Output {
  public void accept(net.minecraft.world.item.ItemStack s, net.minecraft.world.item.CreativeModeTab.TabVisibility v) {} }
