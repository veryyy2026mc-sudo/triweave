package net.fabricmc.fabric.api.client.event.lifecycle.v1;
import net.fabricmc.fabric.api.event.Event;
public final class ClientTickEvents {
  public static final Event<StartTick> START_CLIENT_TICK = null;
  public static final Event<EndTick> END_CLIENT_TICK = null;
  public interface StartTick { void onStartTick(net.minecraft.client.Minecraft c); }
  public interface EndTick { void onEndTick(net.minecraft.client.Minecraft c); } }
