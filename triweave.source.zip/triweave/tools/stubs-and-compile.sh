#!/bin/sh
# コンパイル専用スタブ(Minecraft型・Fabric Loader/API の最小形)をビルドしてから、main をコンパイルする。
# 使い方: tools/stubs-and-compile.sh <out_dir>   (JDK 21+)
set -e
OUT=${1:-/tmp/triweave-out}; STUBS="$OUT/stubs"; MAIN="$OUT/main"
rm -rf "$OUT" && mkdir -p "$STUBS" "$MAIN"
javac -d "$STUBS" $(find "$(dirname "$0")/mc-stubs" "$(dirname "$0")/loader-stubs" -name '*.java')
javac --release 21 -d "$MAIN" -cp "$STUBS" $(find "$(dirname "$0")/../src/main/java" -name '*.java')
echo "compiled: $(find "$MAIN" -name '*.class' | wc -l) classes -> $MAIN"
