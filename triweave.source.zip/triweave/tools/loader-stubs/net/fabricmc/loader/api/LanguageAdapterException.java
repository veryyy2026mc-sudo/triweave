package net.fabricmc.loader.api;
public class LanguageAdapterException extends Exception {
 public LanguageAdapterException(String m){super(m);} public LanguageAdapterException(Throwable t){super(t);} public LanguageAdapterException(String m, Throwable t){super(m,t);} }
