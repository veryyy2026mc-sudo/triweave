package net.fabricmc.loader.api;
import java.nio.file.Path; import java.util.List;
public interface ModContainer { net.fabricmc.loader.api.metadata.ModMetadata getMetadata(); List<Path> getRootPaths(); }
