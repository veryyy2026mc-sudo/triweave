package net.fabricmc.loader.api;
import java.nio.file.Path; import java.util.Optional;
public interface FabricLoader { static FabricLoader getInstance(){return null;} boolean isModLoaded(String id); boolean isDevelopmentEnvironment(); Path getConfigDir(); Path getGameDir(); Optional<ModContainer> getModContainer(String id); net.fabricmc.api.EnvType getEnvironmentType(); java.util.Collection<ModContainer> getAllMods(); }
