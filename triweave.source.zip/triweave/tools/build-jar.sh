#!/bin/sh
# Triweave の配布jar(triweave-<ver>.jar)をGradleなしで作る。JDK 21+ と Gson の jar が必要。
# 使い方: tools/build-jar.sh <gson.jar> <出力jar> [version] [side: both|client|server] [APIジャー出力] [コアMODのみ出力jar]
#
#   side=client : サーバー専用クラス(TriweaveServer / ServerRegistration)を除外し、ModMenuを同梱しない
#   side=server : クライアント専用クラス(TriweaveClient / ClientRegistration)を除外し、ModMenuを同梱しない
#   side=both   : 両方を同梱(既定。クライアント・サーバーどちらでも動く1本のjar)
#
# コアMODのみ出力jar を指定すると、ランチャーで包まない「素のFabric MOD」(両サイドのエントリ
# ポイントを両方含む)も同時に作る。
set -e
GSON=${1:?gson.jar}; OUTJAR=${2:?output jar}; VER=${3:-0.1.0}; SIDE=${4:-both}; APIJAR=${5:-}; COREJAR=${6:-}
ROOT=$(cd "$(dirname "$0")/.." && pwd); W=$(mktemp -d)
"$ROOT/tools/stubs-and-compile.sh" "$W/tw"                                  # スタブ + main
java "$ROOT/tools/GenApiList.java" "$W/tw/main" "$W/tw/stubs" "$ROOT/src/launcher/resources/triweave/neoforge-api.txt"
java "$ROOT/tools/GenApiList.java" "$W/tw/main" "$W/tw/stubs" "$ROOT/src/launcher/resources/triweave/bukkit-api.txt" org/bukkit
mkdir -p "$W/launcher-classes" "$W/pack/mod" "$W/pack/launcher/triweave"
javac --release 21 -d "$W/launcher-classes" -cp "$GSON" $(find "$ROOT/src/launcher/java" -name '*.java')

# --- コアMOD(両サイドのエントリポイントを両方含む、素のFabric MOD)を先に作る ---
cp -r "$W/tw/main/." "$W/pack/mod/"
cp -r "$ROOT/src/main/resources/." "$W/pack/mod/"
sed "s/\${version}/$VER/" "$ROOT/src/main/resources/fabric.mod.json" > "$W/pack/mod/fabric.mod.json"
if [ -n "$COREJAR" ]; then
  jar cf "$COREJAR" -C "$W/pack/mod" .
  echo "built: $COREJAR"
fi

# --- side に応じて、ランチャー同梱用の mod jar を絞り込む ---
case "$SIDE" in
  client)
    rm -f "$W/pack/mod/dev/triweave/TriweaveServer.class" "$W/pack/mod/dev/triweave/command/ServerRegistration.class" \
          "$W/pack/mod/dev/triweave/command/ServerRegistration\$ServerSink.class"
    python3 -c "
import json
p='$W/pack/mod/fabric.mod.json'; d=json.load(open(p))
d['entrypoints'].pop('server', None)
json.dump(d, open(p,'w'), indent=2, ensure_ascii=False)"
    ;;
  server)
    rm -f "$W/pack/mod/dev/triweave/TriweaveClient.class" "$W/pack/mod/dev/triweave/command/ClientRegistration.class" \
          "$W/pack/mod/dev/triweave/command/ClientRegistration\$ClientSink.class"
    python3 -c "
import json
p='$W/pack/mod/fabric.mod.json'; d=json.load(open(p))
d['entrypoints'].pop('client', None)
json.dump(d, open(p,'w'), indent=2, ensure_ascii=False)"
    ;;
  both) : ;;
  *) echo "unknown side: $SIDE (use client|server|both)" >&2; exit 1 ;;
esac
jar cf "$W/pack/launcher/triweave/triweave-mod.jar" -C "$W/pack/mod" .

cp "$ROOT/src/launcher/resources/triweave/"* "$W/pack/launcher/triweave/"
if [ "$SIDE" = "server" ]; then
  rm -f "$W/pack/launcher/triweave/modmenu.jar"               # サーバーにMod Menuは不要
  sed -i '/^modmenu_version=/d' "$W/pack/launcher/triweave/bundled.properties" 2>/dev/null || true
fi
cp "$GSON" "$W/pack/launcher/triweave/gson.jar"
cp -r "$W/launcher-classes/." "$W/pack/launcher/"
printf 'Main-Class: dev.triweave.launcher.TriweaveMain\nPremain-Class: dev.triweave.launcher.TriweaveAgent\nImplementation-Title: Triweave\nImplementation-Version: %s\nTriweave-Side: %s\n' "$VER" "$SIDE" > "$W/MANIFEST.MF"
jar cfm "$OUTJAR" "$W/MANIFEST.MF" -C "$W/pack/launcher" .

if [ -n "$APIJAR" ]; then     # 開発者向け: API だけのjar(クラス + ソース)
  mkdir -p "$W/apisrc/dev/triweave" && cp -r "$ROOT/src/main/java/dev/triweave/api" "$W/apisrc/dev/triweave/"
  jar cf "$APIJAR" -C "$W/tw/main" dev/triweave/api -C "$W/apisrc" dev/triweave/api
  echo "built: $APIJAR"
fi
echo "built: $OUTJAR ($SIDE)"; rm -rf "$W"
