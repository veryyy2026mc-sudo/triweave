import java.io.IOException;
import java.io.PrintWriter;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.TreeSet;
import java.util.stream.Stream;

/**
 * 互換層(net.neoforged.* または org.bukkit.*)が提供するクラス・メンバーの一覧を作る。
 * 出力: "C <class>" と "M <owner>.<name>:<descriptor>"(継承分も展開済み)。
 * 使い方: java GenApiList.java <classesDir> <stubsDir> <out.txt> [package-path(省略時 net/neoforged)]
 */
public class GenApiList {
    public static void main(String[] a) throws Exception {
        Path classes = Paths.get(a[0]);
        String packagePath = a.length > 3 ? a[3] : "net/neoforged";
        URLClassLoader cl = new URLClassLoader(new URL[] {classes.toUri().toURL(), Paths.get(a[1]).toUri().toURL()},
                GenApiList.class.getClassLoader());
        List<String> names = new ArrayList<>();
        try (Stream<Path> s = Files.walk(classes.resolve(packagePath))) {
            s.filter(p -> p.toString().endsWith(".class")).forEach(p -> {
                String rel = classes.relativize(p).toString().replace('\\', '/');
                names.add(rel.substring(0, rel.length() - 6));
            });
        }
        TreeSet<String> out = new TreeSet<>();
        for (String n : names) {
            Class<?> c = Class.forName(n.replace('/', '.'), false, cl);
            out.add("C " + n);
            TreeSet<Class<?>> chain = new TreeSet<>((x, y) -> x.getName().compareTo(y.getName()));
            collect(c, chain);
            for (Class<?> k : chain) {
                for (Method m : k.getDeclaredMethods()) out.add("M " + n + "." + m.getName() + ":" + desc(m.getParameterTypes(), m.getReturnType()));
                for (Constructor<?> m : k.getDeclaredConstructors()) if (k == c) out.add("M " + n + ".<init>:" + desc(m.getParameterTypes(), void.class));
                for (Field f : k.getDeclaredFields()) out.add("M " + n + "." + f.getName() + ":" + f.getType().descriptorString());
            }
            for (Method m : c.getMethods()) out.add("M " + n + "." + m.getName() + ":" + desc(m.getParameterTypes(), m.getReturnType()));
        }
        try (PrintWriter w = new PrintWriter(a[2], "UTF-8")) {
            for (String l : out) w.println(l);
        }
        System.out.println("classes=" + names.size() + " lines=" + out.size());
    }

    private static void collect(Class<?> c, TreeSet<Class<?>> acc) {
        if (c == null || c == Object.class || !acc.add(c)) return;
        collect(c.getSuperclass(), acc);
        for (Class<?> i : c.getInterfaces()) collect(i, acc);
    }

    private static String desc(Class<?>[] ps, Class<?> r) {
        StringBuilder sb = new StringBuilder("(");
        for (Class<?> p : ps) sb.append(p.descriptorString());
        return sb.append(')').append(r.descriptorString()).toString();
    }
}
